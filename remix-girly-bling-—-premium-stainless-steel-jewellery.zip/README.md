# Girly Bling — Everyday Luxury Stainless Steel Jewellery

A modern, high-conversion e-commerce web application for **Girly Bling**, a luxury waterproof and anti-tarnish stainless-steel jewellery brand based in Pakistan.

---

## 🌟 Key Features

1. **Editorial Luxury Aesthetic**: Curated warm editorial color palette (`#FAF8F5`, `#A57E78`, `#242424`), responsive layout, and typography.
2. **Interactive 3D Hero Showcase**: Real-time cursor-tracking 3D card tilt with specular shine, supporting both video reels and editorial photos with custom craft descriptions.
3. **Product Catalogue & Collections**: Rings, Necklaces, Earrings, Bracelets, Anklets, with real-time category filtering, price sorting, search modal, and quick view.
4. **Pakistan-Optimized Checkout**:
   - Cash on Delivery (COD) across Pakistan.
   - Bank Transfer / JazzCash / EasyPaisa checkout flow with receipt upload.
   - 1-Click WhatsApp Ordering direct to brand number (+92 321 8492001).
   - Real-time free shipping threshold calculation (Free shipping above Rs. 3,500).
5. **Interactive Customer Features**:
   - Shopping Cart Drawer with free shipping progress bar.
   - Wishlist Drawer.
   - Interactive Ring & Bracelet Size Guide with printable/caliper instructions.
   - Customer Reviews submission and approval system.
6. **Owner Admin Dashboard**:
   - Access via Owner Portal link in the footer or header (Default PIN: `1234`).
   - Manage Products (Add, Edit, Price, Stock, Category).
   - Order Management (Track COD, mark as Dispatched, Delivered, or Cancelled).
   - Hero Showcase Media Manager (Upload custom videos, photos, and descriptions).
   - Store Settings, Shipping Fees, Announcements, and Policies.

---

## 🚀 Quick Start (Local Development)

### Prerequisites
- Node.js (version 18 or higher recommended)
- npm or pnpm or yarn

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Local Development Server
```bash
npm run dev
```
Open your browser and navigate to `http://localhost:3000` (or the port displayed in your terminal).

### 3. Production Build
```bash
npm run build
```
The optimized production bundle will be generated in the `dist/` directory.

---

## 📦 100% Free Ways to Publish / Host This Website (No Vercel Needed)

### 🥇 Method 1: Netlify Drop (EASIEST — Zero Coding, Drag & Drop)
1. Download `girly-bling-dist.zip` (Pre-built package, ~210 KB) directly from the website header or owner dashboard.
2. Unzip it to a folder on your computer.
3. Open **[app.netlify.com/drop](https://app.netlify.com/drop)** in your web browser.
4. Drag and drop the unzipped folder onto the webpage box.
5. In ~5 seconds, your boutique is live with a free custom SSL URL (e.g., `https://girly-bling.netlify.app`).
6. Go to **Site settings > Domain management** to connect your free or custom domain (e.g., `girlybling.pk`) with automated SSL.

---

### 🥈 Method 2: Cloudflare Pages (100% Free, Unlimited Bandwidth)
1. Sign up for a free account at **[dash.cloudflare.com](https://dash.cloudflare.com)**.
2. Click **Workers & Pages** > **Create application** > **Pages** tab.
3. Select **"Upload assets"**.
4. Drag the unzipped `dist` folder into Cloudflare.
5. Click **Deploy site** — you get lightning-fast speeds worldwide and free DDoS protection.

---

### 🥉 Method 3: GitHub Pages (100% Free)
1. Create a free repository on [GitHub](https://github.com).
2. Upload the files or configure GitHub Actions to build automatically on push.
3. Go to **Settings > Pages > Build and deployment > Source** and choose your branch.
4. Live at `https://yourusername.github.io/girly-bling`.

---

### 🌐 Method 4: Traditional Shared Web Hosting (cPanel / Hostinger / Namecheap)
1. Download `girly-bling-dist.zip`.
2. Open your hosting cPanel > **File Manager**.
3. Navigate into `public_html/`.
4. Upload `girly-bling-dist.zip` and click **Extract**.
5. Your website is immediately live on your domain.

---

### 🚀 Method 5: Deploying to Wasmer.io (Wasmer Edge)
Wasmer.io is a WebAssembly Edge cloud platform. It **does not accept plain `.zip` web uploads** through a browser without Wasmer manifests.

To deploy on Wasmer:
1. Download `girly-bling-wasmer.zip` (it comes pre-packaged with `app.yaml` and `wasmer.toml`).
2. Unzip it to a folder on your computer.
3. Install Wasmer CLI (if not installed): `curl https://get.wasmer.io -sSfL | sh` (or `winget install wasmer` on Windows).
4. Run:
   ```bash
   wasmer login
   wasmer deploy
   ```
5. Wasmer will publish your site to Wasmer Edge with global CDN caching.

---

### ⚡ Method 6: Tiiny.host (Direct .ZIP Drag & Drop)
1. Go to **[tiiny.host](https://tiiny.host)**.
2. Drag `girly-bling-dist.zip` directly onto the upload field.
3. Enter your store name and click **Launch**. Live in seconds.
6. (Optional) For Apache servers, add this `.htaccess` in `public_html/` for clean single-page URLs:
   ```apache
   <IfModule mod_rewrite.c>
     RewriteEngine On
     RewriteBase /
     RewriteRule ^index\.html$ - [L]
     RewriteCond %{REQUEST_FILENAME} !-f
     RewriteCond %{REQUEST_FILENAME} !-d
     RewriteRule . /index.html [L]
   </IfModule>
   ```

---

### Method 5: Vercel (Optional)
If you ever want to use Vercel later:
1. Push to GitHub, import repo on Vercel, and click Deploy.

---

## 🛠️ Tech Stack
- **Framework**: React 19 + TypeScript
- **Bundler**: Vite
- **Styling**: Tailwind CSS 4
- **Icons**: Lucide React
- **Animations**: Motion (Framer Motion)
- **Local State & Persistence**: React Context API + LocalStorage fallback
