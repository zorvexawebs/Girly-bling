import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { formatPKR } from '../utils/formatters';
import {
  Heart,
  ShoppingBag,
  ShieldCheck,
  Droplets,
  Truck,
  RotateCcw,
  Sparkles,
  MessageSquare,
  ChevronDown,
  Ruler,
  Star,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import { ProductCard } from '../components/ProductCard';

export const ProductDetailView: React.FC<{ onOpenSizeGuide: () => void }> = ({ onOpenSizeGuide }) => {
  const {
    products,
    selectedProductId,
    addToCart,
    toggleWishlist,
    isInWishlist,
    setActivePage,
    generateWhatsAppOrderUrl,
    settings
  } = useStore();

  const product = products.find((p) => p.id === selectedProductId) || products[0];

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState(product?.sizes[0] || 'Standard');
  const [quantity, setQuantity] = useState(1);
  const [openAccordion, setOpenAccordion] = useState<string | null>('desc');

  if (!product) {
    return (
      <div className="py-24 text-center">
        <p className="font-serif text-2xl text-[#242424]">Product not found.</p>
        <button
          onClick={() => setActivePage('shop')}
          className="mt-4 px-6 py-2 bg-[#242424] text-white text-xs uppercase"
        >
          Return to Shop
        </button>
      </div>
    );
  }

  const isWishlisted = isInWishlist(product.id);

  const toggleAccordion = (name: string) => {
    setOpenAccordion(openAccordion === name ? null : name);
  };

  const handleAddToCart = () => {
    addToCart(product, selectedSize, quantity);
  };

  const handleBuyNow = () => {
    addToCart(product, selectedSize, quantity);
    setActivePage('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleWhatsAppOrder = () => {
    const url = generateWhatsAppOrderUrl(product, selectedSize, quantity);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const relatedProducts = products
    .filter((p) => p.id !== product.id && p.category === product.category)
    .slice(0, 4);

  return (
    <div className="bg-[#FAF8F5] pt-6 pb-20 sm:pb-28">
      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6">
        <div className="flex items-center gap-2 text-xs text-[#242424]/60 uppercase tracking-wider">
          <button onClick={() => setActivePage('home')} className="hover:text-[#242424]">
            Home
          </button>
          <span>/</span>
          <button onClick={() => setActivePage('shop')} className="hover:text-[#242424]">
            Shop
          </button>
          <span>/</span>
          <span className="text-[#242424] font-medium truncate">{product.name}</span>
        </div>
      </div>

      {/* Main PDP Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-start">
          
          {/* LEFT: Image Gallery (7 cols on lg) */}
          <div className="lg:col-span-7 space-y-4">
            {/* Primary Main Image with Subtle Hover Zoom */}
            <div className="relative aspect-[4/5] w-full bg-[#F4EFEB] overflow-hidden border border-[#D8CEC8]/50 shadow-xs group">
              <img
                src={product.images[activeImageIndex] || product.images[0]}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-105"
              />

              {/* Wishlist Button */}
              <button
                onClick={() => toggleWishlist(product.id)}
                aria-label="Wishlist"
                className="absolute top-4 right-4 p-2.5 bg-[#FAF8F5]/80 hover:bg-[#FAF8F5] rounded-full text-[#242424] shadow-xs transition-colors"
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-[#A57E78] text-[#A57E78]' : ''}`} />
              </button>

              {/* Tag indicator */}
              <div className="absolute top-4 left-4 bg-[#FAF8F5]/90 px-3 py-1 text-[11px] uppercase tracking-wider font-semibold text-[#242424]">
                {product.category}
              </div>
            </div>

            {/* Thumbnail Navigation */}
            {product.images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-2">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`w-20 h-24 flex-shrink-0 border transition-all cursor-pointer ${
                      activeImageIndex === idx
                        ? 'border-[#242424] opacity-100 ring-1 ring-[#242424]'
                        : 'border-[#D8CEC8] opacity-60 hover:opacity-90'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* RIGHT: Contiguous Purchase Module (5 cols on lg) */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
            
            {/* Category & Collection */}
            <div className="space-y-1">
              <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold flex items-center gap-2">
                <span>{product.category}</span>
                <span>·</span>
                <span>{product.collection}</span>
              </div>
              <h1 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight leading-tight">
                {product.name}
              </h1>
              {product.subtitle && (
                <p className="text-xs sm:text-sm text-[#242424]/70">
                  {product.subtitle}
                </p>
              )}
            </div>

            {/* Rating Stars & Stock */}
            <div className="flex items-center justify-between text-xs pb-3 border-b border-[#D8CEC8]/40">
              <div className="flex items-center gap-1.5">
                <div className="flex text-[#C5A880]">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-current" />
                  ))}
                </div>
                <span className="font-semibold text-[#242424] tabular-nums">
                  {product.rating.toFixed(1)}
                </span>
                <span className="text-[#242424]/50">
                  ({product.reviewCount} customer reviews)
                </span>
              </div>

              {/* Stock status indicator */}
              <div>
                {product.stockStatus === 'sold_out' ? (
                  <span className="text-rose-800 font-semibold uppercase tracking-wider text-[11px]">
                    Sold Out
                  </span>
                ) : product.stockStatus === 'low_stock' ? (
                  <span className="text-[#C5A880] font-semibold text-[11px]">
                    Only {product.stock} left in stock
                  </span>
                ) : (
                  <span className="text-emerald-800 font-medium text-[11px] flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> In Stock & Ready to Ship
                  </span>
                )}
              </div>
            </div>

            {/* Price in PKR */}
            <div className="flex items-baseline gap-3">
              <span className="font-serif text-3xl font-bold text-[#242424] tabular-nums">
                {formatPKR(product.price)}
              </span>
              {product.originalPrice && product.originalPrice > product.price && (
                <>
                  <span className="text-base text-[#242424]/40 line-through tabular-nums">
                    {formatPKR(product.originalPrice)}
                  </span>
                  <span className="text-xs uppercase font-semibold text-[#A57E78]">
                    Save {formatPKR(product.originalPrice - product.price)}
                  </span>
                </>
              )}
            </div>

            {/* Material & Durability Callouts */}
            <div className="p-4 bg-[#F4EFEB]/70 border border-[#D8CEC8]/50 space-y-2 text-xs text-[#242424]/80">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#A57E78] shrink-0" />
                <span className="font-semibold text-[#242424]">{product.material}</span>
              </div>
              <div className="flex items-center gap-2">
                <Droplets className="w-4 h-4 text-[#A57E78] shrink-0" />
                <span>100% Waterproof · Non-Tarnish · Hypoallergenic</span>
              </div>
            </div>

            {/* Size Selector */}
            {product.sizes.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-semibold uppercase tracking-wider text-[#242424]">
                    Select Size
                  </label>
                  <button
                    onClick={onOpenSizeGuide}
                    className="text-[#A57E78] hover:text-[#242424] underline flex items-center gap-1 cursor-pointer"
                  >
                    <Ruler className="w-3.5 h-3.5" />
                    <span>View Size Guide</span>
                  </button>
                </div>

                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((sz) => (
                    <button
                      key={sz}
                      onClick={() => setSelectedSize(sz)}
                      className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                        selectedSize === sz
                          ? 'border border-[#242424] bg-[#242424] text-white shadow-xs'
                          : 'border border-[#D8CEC8] bg-white text-[#242424] hover:border-[#242424]'
                      }`}
                    >
                      {sz}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity Stepper */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#242424]">
                Quantity
              </label>
              <div className="flex items-center border border-[#D8CEC8] bg-white w-32">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 flex items-center justify-center text-sm hover:bg-[#D8CEC8]/20 transition-colors"
                >
                  -
                </button>
                <span className="flex-1 text-center text-xs font-semibold tabular-nums">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 flex items-center justify-center text-sm hover:bg-[#D8CEC8]/20 transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="space-y-2.5 pt-2">
              <div className="flex gap-3">
                <button
                  onClick={handleAddToCart}
                  disabled={product.stockStatus === 'sold_out'}
                  className="flex-1 py-3.5 bg-[#242424] text-[#FAF8F5] text-xs uppercase tracking-widest font-semibold hover:bg-black transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-xs"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{product.stockStatus === 'sold_out' ? 'Sold Out' : 'Add to Bag'}</span>
                </button>

                <button
                  onClick={handleBuyNow}
                  disabled={product.stockStatus === 'sold_out'}
                  className="flex-1 py-3.5 bg-[#A57E78] text-white text-xs uppercase tracking-widest font-semibold hover:bg-[#8e6863] transition-all cursor-pointer disabled:opacity-50"
                >
                  Buy Now (Instant COD)
                </button>
              </div>

              {/* WhatsApp Order Button */}
              <button
                onClick={handleWhatsAppOrder}
                className="w-full py-3 bg-[#25D366]/10 border border-[#25D366]/40 text-[#128C7E] text-xs uppercase tracking-wider font-semibold hover:bg-[#25D366]/20 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Order on WhatsApp (Instant Response)</span>
              </button>
            </div>

            {/* Quick delivery promise */}
            <div className="pt-2 flex items-center gap-3 text-xs text-[#242424]/75">
              <Truck className="w-4 h-4 text-[#A57E78]" />
              <span>Complimentary nationwide delivery on orders over {formatPKR(settings.freeShippingThreshold)}</span>
            </div>

            {/* Product Accordion Information Tabs */}
            <div className="pt-6 border-t border-[#D8CEC8]/60 divide-y divide-[#D8CEC8]/40">
              
              {/* Accordion 1: Description */}
              <div className="py-3.5">
                <button
                  onClick={() => toggleAccordion('desc')}
                  className="w-full flex items-center justify-between text-left text-xs uppercase tracking-wider font-semibold text-[#242424] cursor-pointer"
                >
                  <span>Description & Narrative</span>
                  <ChevronDown
                    className={`w-4 h-4 transform transition-transform ${
                      openAccordion === 'desc' ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openAccordion === 'desc' && (
                  <div className="mt-2 text-xs sm:text-sm text-[#242424]/80 leading-relaxed space-y-2 animate-in fade-in duration-150">
                    <p>{product.description}</p>
                    {product.weight && <p><strong>Approx Weight:</strong> {product.weight}</p>}
                    <p><strong>SKU:</strong> {product.sku}</p>
                  </div>
                )}
              </div>

              {/* Accordion 2: Material & Finish */}
              <div className="py-3.5">
                <button
                  onClick={() => toggleAccordion('material')}
                  className="w-full flex items-center justify-between text-left text-xs uppercase tracking-wider font-semibold text-[#242424] cursor-pointer"
                >
                  <span>Material & Waterproof Details</span>
                  <ChevronDown
                    className={`w-4 h-4 transform transition-transform ${
                      openAccordion === 'material' ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openAccordion === 'material' && (
                  <div className="mt-2 text-xs text-[#242424]/80 leading-relaxed space-y-2 animate-in fade-in duration-150">
                    <p>
                      Crafted from surgical-grade 316L stainless steel, known for its superior anti-corrosive properties and hypoallergenic profile.
                    </p>
                    <p>
                      Plated with genuine 18K gold using high-temperature Physical Vapor Deposition (PVD) inside vacuum chambers. Will not react with sweat, perfumes, or water.
                    </p>
                  </div>
                )}
              </div>

              {/* Accordion 3: Care Instructions */}
              <div className="py-3.5">
                <button
                  onClick={() => toggleAccordion('care')}
                  className="w-full flex items-center justify-between text-left text-xs uppercase tracking-wider font-semibold text-[#242424] cursor-pointer"
                >
                  <span>Care Instructions</span>
                  <ChevronDown
                    className={`w-4 h-4 transform transition-transform ${
                      openAccordion === 'care' ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openAccordion === 'care' && (
                  <div className="mt-2 text-xs text-[#242424]/80 leading-relaxed space-y-2 animate-in fade-in duration-150">
                    <p>{product.careInstructions || 'Wipe gently with a soft microfibre cloth after wearing. Safe for showers and gym workouts. Store in your provided Girly Bling velvet keepsake pouch.'}</p>
                  </div>
                )}
              </div>

              {/* Accordion 4: Shipping & Returns */}
              <div className="py-3.5">
                <button
                  onClick={() => toggleAccordion('shipping')}
                  className="w-full flex items-center justify-between text-left text-xs uppercase tracking-wider font-semibold text-[#242424] cursor-pointer"
                >
                  <span>Nationwide Shipping & 7-Day Exchange</span>
                  <ChevronDown
                    className={`w-4 h-4 transform transition-transform ${
                      openAccordion === 'shipping' ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {openAccordion === 'shipping' && (
                  <div className="mt-2 text-xs text-[#242424]/80 leading-relaxed space-y-2 animate-in fade-in duration-150">
                    <p>
                      <strong>Delivery Time:</strong> 2 to 4 business days to Karachi, Lahore, Islamabad, and across Pakistan.
                    </p>
                    <p>
                      <strong>Returns & Exchanges:</strong> 7-day hassle-free exchange window. Unworn items in original velvet packaging are eligible.
                    </p>
                  </div>
                )}
              </div>

            </div>

          </div>

        </div>

        {/* Related Products Recommendation */}
        {relatedProducts.length > 0 && (
          <div className="mt-20 pt-12 border-t border-[#D8CEC8]/40">
            <div className="flex items-center justify-between mb-8">
              <div>
                <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold mb-1">
                  Complete The Look
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium">
                  Pairs Beautifully With
                </h3>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((rel) => (
                <ProductCard key={rel.id} product={rel} />
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
