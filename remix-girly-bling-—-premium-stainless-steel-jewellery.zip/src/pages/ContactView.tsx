import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { MessageSquare, Phone, Mail, MapPin, Clock, Send, Check } from 'lucide-react';

export const ContactView: React.FC = () => {
  const { settings, showToast } = useStore();

  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    subject: 'Order Enquiry',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.message) return;
    setSubmitted(true);
    showToast('Your message has been received. Our concierge will get back to you shortly.');
  };

  return (
    <div className="bg-[#FAF8F5] pt-8 pb-20 sm:pb-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto py-12 border-b border-[#D8CEC8]/40 mb-16">
          <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold mb-2">
            Client Concierge
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl text-[#242424] font-medium tracking-tight">
            Contact Girly Bling
          </h1>
          <p className="mt-3 text-sm text-[#242424]/70">
            Have a question regarding ring sizing, custom gifting, or your order delivery? We are here to assist.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* LEFT: Contact Channels (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 bg-white border border-[#D8CEC8] shadow-xs space-y-6">
              <h2 className="font-serif text-2xl text-[#242424] font-medium">
                Get In Touch
              </h2>

              <div className="space-y-4 text-xs">
                {/* WhatsApp */}
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#25D366]/10 text-[#128C7E] flex items-center justify-center shrink-0">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#242424]">WhatsApp Concierge</div>
                    <div className="text-[#242424]/70">{settings.whatsappNumber}</div>
                    <a
                      href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#128C7E] font-semibold hover:underline mt-0.5 inline-block"
                    >
                      Chat on WhatsApp &rarr;
                    </a>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#F4EFEB] text-[#A57E78] flex items-center justify-center shrink-0">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#242424]">Phone Concierge</div>
                    <div className="text-[#242424]/70">{settings.phone}</div>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#F4EFEB] text-[#A57E78] flex items-center justify-center shrink-0">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#242424]">Email Assistance</div>
                    <div className="text-[#242424]/70">{settings.email}</div>
                  </div>
                </div>

                {/* Studio Address */}
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#F4EFEB] text-[#A57E78] flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#242424]">Atelier Studio</div>
                    <div className="text-[#242424]/70">{settings.address}</div>
                  </div>
                </div>

                {/* Business Hours */}
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#F4EFEB] text-[#A57E78] flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-[#242424]">Operating Hours</div>
                    <div className="text-[#242424]/70">{settings.businessHours}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: Contact Form (7 cols) */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 bg-white border border-[#D8CEC8] shadow-xs">
              <h2 className="font-serif text-2xl text-[#242424] font-medium mb-1">
                Send a Message
              </h2>
              <p className="text-xs text-[#242424]/60 mb-6">
                Our team responds to all inquiries within 2 to 4 business hours.
              </p>

              {submitted ? (
                <div className="p-8 text-center space-y-3 bg-[#FAF8F5] border border-[#D8CEC8]">
                  <Check className="w-8 h-8 text-emerald-700 mx-auto" />
                  <h3 className="font-serif text-xl text-[#242424]">Thank you for reaching out.</h3>
                  <p className="text-xs text-[#242424]/70">
                    We have received your message and will contact you via WhatsApp or Email shortly.
                  </p>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setForm({ name: '', phone: '', email: '', subject: 'Order Enquiry', message: '' });
                    }}
                    className="mt-4 px-6 py-2 bg-[#242424] text-white text-xs uppercase"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                        Phone / WhatsApp *
                      </label>
                      <input
                        type="tel"
                        required
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                        Subject
                      </label>
                      <select
                        value={form.subject}
                        onChange={(e) => setForm({ ...form, subject: e.target.value })}
                        className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                      >
                        <option value="Order Enquiry">Order Status / Tracking</option>
                        <option value="Ring Sizing">Ring / Bracelet Sizing Help</option>
                        <option value="Exchange">Return / Exchange Request</option>
                        <option value="Wholesale">Corporate / Bulk Gifting</option>
                        <option value="Other">General Question</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                      Message *
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      placeholder="How can we assist you today?"
                      className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Message to Concierge</span>
                  </button>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
