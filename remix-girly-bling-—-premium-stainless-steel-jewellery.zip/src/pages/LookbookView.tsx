import React from 'react';
import { useStore } from '../context/StoreContext';
import { Instagram, ArrowUpRight, Sparkles } from 'lucide-react';
import { formatPKR } from '../utils/formatters';

export const LookbookView: React.FC = () => {
  const { settings, products, openProductDetail } = useStore();

  const looks = [
    {
      title: 'The Golden Hour Layer',
      subtitle: 'Effortless daytime elegance with warm sunlight',
      image: '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg',
      featuredProduct: products.find((p) => p.id === 'gb-001') || products[0]
    },
    {
      title: 'Parisian Minimalist Stack',
      subtitle: 'Croissant dome rings paired with architectural cuffs',
      image: '/src/assets/images/lookbook_lifestyle_portrait_1790183522124.jpg',
      featuredProduct: products.find((p) => p.id === 'gb-002') || products[1]
    },
    {
      title: 'Travertine Still Life',
      subtitle: 'Pure geometry and waterproof durability',
      image: '/src/assets/images/product_travertine_jewellery_1790183496193.jpg',
      featuredProduct: products.find((p) => p.id === 'gb-003') || products[2]
    },
    {
      title: 'Evening Velvet & Gold',
      subtitle: 'Hand-packed in luxury keepsake boxes for life’s grandest celebrations',
      image: '/src/assets/images/brand_craftsmanship_story_1790183510549.jpg',
      featuredProduct: products.find((p) => p.id === 'gb-004') || products[3]
    }
  ];

  return (
    <div className="bg-[#FAF8F5] pt-8 pb-20 sm:pb-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto py-12 border-b border-[#D8CEC8]/40 mb-16">
          <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold mb-2">
            The Visual Journal
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl text-[#242424] font-medium tracking-tight">
            The Editorial Lookbook
          </h1>
          <p className="mt-3 text-sm text-[#242424]/70">
            A visual study of liquid gold 316L stainless steel jewellery in natural light and everyday silhouettes.
          </p>
        </div>

        {/* Editorial Grids */}
        <div className="space-y-20">
          {looks.map((look, idx) => (
            <div
              key={idx}
              className={`grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center ${
                idx % 2 === 1 ? 'lg:flex-row-reverse' : ''
              }`}
            >
              <div className={`lg:col-span-8 ${idx % 2 === 1 ? 'lg:order-2' : ''}`}>
                <div className="relative aspect-[16/10] bg-[#F4EFEB] border border-[#D8CEC8] overflow-hidden group">
                  <img
                    src={look.image}
                    alt={look.title}
                    className="w-full h-full object-cover transform transition-transform duration-700 ease-out group-hover:scale-102"
                  />
                </div>
              </div>

              <div className={`lg:col-span-4 space-y-4 ${idx % 2 === 1 ? 'lg:order-1' : ''}`}>
                <div className="text-[11px] uppercase tracking-widest text-[#A57E78] font-semibold">
                  Look #{idx + 1}
                </div>
                <h2 className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium">
                  {look.title}
                </h2>
                <p className="text-xs sm:text-sm text-[#242424]/75 leading-relaxed">
                  {look.subtitle}
                </p>

                {look.featuredProduct && (
                  <div
                    onClick={() => openProductDetail(look.featuredProduct.id)}
                    className="p-4 bg-white border border-[#D8CEC8] flex items-center justify-between cursor-pointer hover:border-[#242424] transition-colors"
                  >
                    <div>
                      <div className="text-[10px] uppercase text-[#A57E78] font-semibold">
                        Featured Piece
                      </div>
                      <div className="font-serif text-sm font-medium text-[#242424]">
                        {look.featuredProduct.name}
                      </div>
                      <div className="text-xs font-semibold text-[#242424] tabular-nums mt-0.5">
                        {formatPKR(look.featuredProduct.price)}
                      </div>
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-[#242424]" />
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Instagram Banner */}
        <div className="mt-24 p-8 sm:p-12 bg-[#F4EFEB] border border-[#D8CEC8] text-center space-y-4">
          <Instagram className="w-8 h-8 text-[#A57E78] mx-auto" />
          <h3 className="font-serif text-2xl text-[#242424]">
            Share Your Girly Bling Moments
          </h3>
          <p className="text-xs sm:text-sm text-[#242424]/70 max-w-md mx-auto">
            Tag {settings.instagramUsername || '@girlybling.pk'} on Instagram to be featured in our seasonal lookbook.
          </p>
          <a
            href={settings.instagramUrl || 'https://instagram.com/girlybling.pk'}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#242424] text-white text-xs uppercase tracking-wider font-semibold hover:bg-black transition-colors"
          >
            <span>Follow {settings.instagramUsername}</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>

      </div>
    </div>
  );
};
