import React from 'react';
import { useStore } from '../context/StoreContext';
import { ShieldCheck, Droplets, Sparkles, Package, ArrowRight } from 'lucide-react';

export const AboutView: React.FC = () => {
  const { settings, setActivePage } = useStore();

  return (
    <div className="bg-[#FAF8F5] pt-8 pb-20 sm:pb-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Header */}
        <div className="text-center max-w-3xl mx-auto py-12 border-b border-[#D8CEC8]/40 mb-16">
          <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold mb-2">
            Our Story & Craft
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl text-[#242424] font-medium tracking-tight">
            Designed To Be Remembered.
          </h1>
          <p className="mt-4 text-sm sm:text-base text-[#242424]/75 leading-relaxed">
            {settings.brandDescription ||
              'Girly Bling was born out of a collective frustration: why should beautiful jewellery turn green after a few wears or lose its luster with humidity? We envisioned a world where modern Pakistani women could wear radiant gold jewellery every day, carefree.'}
          </p>
        </div>

        {/* Story Section 1: Metallurgy & 316L Stainless Steel */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-20">
          <div className="relative aspect-[4/3] bg-[#F4EFEB] border border-[#D8CEC8] overflow-hidden shadow-md">
            <img
              src="/src/assets/images/brand_craftsmanship_story_1790183510549.jpg"
              alt="Girly Bling Craftsmanship"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-6">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#A57E78] font-semibold">
              <ShieldCheck className="w-4 h-4" />
              <span>The Foundation: Medical 316L Alloy</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
              Why We Forbid Ordinary Brass
            </h2>
            <p className="text-xs sm:text-sm text-[#242424]/80 leading-relaxed">
              Most fast-fashion jewellery in Pakistan is cast from low-cost zinc, brass, or copper alloys dipped in microscopic flash electroplating. When exposed to sweat, body chemistry, and perfume, these metals oxidize into copper carbonate — leaving that unsightly greenish-black ring around your collar and fingers.
            </p>
            <p className="text-xs sm:text-sm text-[#242424]/80 leading-relaxed">
              At Girly Bling, every single necklace chain, pendant, and ring is forged exclusively in medical-grade 316L stainless steel. It does not react to perspiration, fresh water, or seawater, ensuring zero discoloration and complete hypoallergenic peace of mind.
            </p>
          </div>
        </div>

        {/* Story Section 2: 18K Vacuum PVD Plating */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center mb-20 lg:flex-row-reverse">
          <div className="space-y-6 lg:order-1">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#A57E78] font-semibold">
              <Droplets className="w-4 h-4" />
              <span>The Finish: Vacuum PVD Plating</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
              18K Real Gold Vapor Deposition
            </h2>
            <p className="text-xs sm:text-sm text-[#242424]/80 leading-relaxed">
              Rather than traditional chemical dipping, our pieces undergo Physical Vapor Deposition (PVD). Inside high-vacuum chambers, real 18-karat gold is vaporized into an atomic plasma cloud that fuses directly into the molecular structure of the steel.
            </p>
            <p className="text-xs sm:text-sm text-[#242424]/80 leading-relaxed">
              This atomic bond creates a surface that is up to ten times thicker and far more scratch-resistant than conventional fashion plating. Shower in it, swim in it, live in it.
            </p>
          </div>

          <div className="relative aspect-[4/3] bg-[#F4EFEB] border border-[#D8CEC8] overflow-hidden shadow-md lg:order-2">
            <img
              src="/src/assets/images/product_travertine_jewellery_1790183496193.jpg"
              alt="18K PVD Gold Jewellery"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Story Section 3: The Keepsake Velvet Box */}
        <div className="bg-[#F4EFEB]/60 border border-[#D8CEC8] p-8 sm:p-12 mb-16">
          <div className="max-w-2xl mx-auto text-center space-y-4">
            <Package className="w-10 h-10 text-[#A57E78] mx-auto stroke-[1.5]" />
            <h3 className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium">
              The Girly Bling Gifting Experience
            </h3>
            <p className="text-xs sm:text-sm text-[#242424]/80 leading-relaxed">
              Unboxing jewellery should feel intimate and cherished. Every Girly Bling order arrives in our signature blush rose velvet keepsake box with custom gold foil embossing, accompanied by a microfibre polishing cloth and a certificate of authenticity.
            </p>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <button
            onClick={() => {
              setActivePage('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="px-8 py-3.5 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors cursor-pointer inline-flex items-center gap-2"
          >
            <span>Explore The Collection</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
