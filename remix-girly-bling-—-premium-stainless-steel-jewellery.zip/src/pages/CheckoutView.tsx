import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { formatPKR } from '../utils/formatters';
import {
  ShieldCheck,
  Truck,
  RotateCcw,
  CheckCircle2,
  Lock,
  MessageSquare,
  ArrowRight,
  ShoppingBag
} from 'lucide-react';
import { Order } from '../types';

export const CheckoutView: React.FC = () => {
  const {
    cart,
    cartSubtotal,
    settings,
    clearCart,
    addOrder,
    setActivePage,
    lastPlacedOrder,
    setLastPlacedOrder
  } = useStore();

  const freeThreshold = settings.freeShippingThreshold || 3500;
  const shippingFee = cartSubtotal >= freeThreshold ? 0 : settings.standardShippingFee;
  const grandTotal = cartSubtotal + shippingFee;

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    city: 'Lahore',
    postalCode: '',
    notes: ''
  });

  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bank_transfer' | 'easypaisa_jazzcash'>('cod');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // If order was already placed, show confirmation screen
  if (lastPlacedOrder) {
    const rawNumber = settings.whatsappNumber.replace(/[^0-9]/g, '');
    const whatsappMsg = encodeURIComponent(
      `Hi ${settings.businessName}, I just placed Order #${lastPlacedOrder.id} on your website for Rs. ${lastPlacedOrder.total.toLocaleString()} via ${lastPlacedOrder.paymentMethod.toUpperCase()}.\n\nCustomer: ${lastPlacedOrder.customer.name} (${lastPlacedOrder.customer.city}).\n\nPlease confirm my dispatch.`
    );

    return (
      <div className="bg-[#FAF8F5] py-20 px-4">
        <div className="max-w-xl mx-auto bg-white p-8 sm:p-10 border border-[#D8CEC8] shadow-lg text-center space-y-6">
          <div className="w-16 h-16 bg-[#F4EFEB] text-[#A57E78] rounded-full mx-auto flex items-center justify-center">
            <CheckCircle2 className="w-8 h-8 stroke-[1.5]" />
          </div>

          <div className="space-y-2">
            <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold">
              Thank You For Your Order
            </div>
            <h1 className="font-serif text-3xl text-[#242424] font-medium">
              Order #{lastPlacedOrder.id} Confirmed
            </h1>
            <p className="text-xs sm:text-sm text-[#242424]/75">
              We have received your order details. A confirmation message and courier tracking number will be dispatched to <strong>{lastPlacedOrder.customer.phone}</strong>.
            </p>
          </div>

          {/* Receipt Breakdown */}
          <div className="bg-[#FAF8F5] p-5 border border-[#D8CEC8]/50 text-left text-xs space-y-3">
            <div className="flex justify-between font-semibold border-b border-[#D8CEC8]/40 pb-2">
              <span>Delivery Details</span>
              <span className="uppercase text-[#A57E78]">{lastPlacedOrder.paymentMethod.replace('_', ' ')}</span>
            </div>
            <div>
              <strong>Recipient:</strong> {lastPlacedOrder.customer.name}
            </div>
            <div>
              <strong>Address:</strong> {lastPlacedOrder.customer.address}, {lastPlacedOrder.customer.city}
            </div>
            <div>
              <strong>Total Amount:</strong> <span className="font-bold text-[#242424]">{formatPKR(lastPlacedOrder.total)}</span>
            </div>
          </div>

          {/* Bank Transfer Instructions if selected */}
          {lastPlacedOrder.paymentMethod === 'bank_transfer' && (
            <div className="p-4 bg-amber-50 border border-amber-200 text-left text-xs space-y-1.5 text-amber-900">
              <div className="font-semibold">Meezan Bank Transfer Details:</div>
              <div>Bank: {settings.bankName}</div>
              <div>Account Title: {settings.bankTitle}</div>
              <div>IBAN: <span className="font-mono">{settings.bankIban}</span></div>
              <div className="text-[11px] text-amber-800 pt-1">
                Please share a screenshot of the payment receipt to our WhatsApp ({settings.whatsappNumber}).
              </div>
            </div>
          )}

          {/* WhatsApp Direct Confirmation Button */}
          <div className="space-y-3 pt-2">
            <a
              href={`https://wa.me/${rawNumber}?text=${whatsappMsg}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 bg-[#25D366] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#1ebc59] transition-colors flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Confirm Order Instantly on WhatsApp</span>
            </a>

            <button
              onClick={() => {
                setLastPlacedOrder(null);
                setActivePage('home');
              }}
              className="w-full py-2.5 border border-[#242424] text-[#242424] text-xs uppercase tracking-wider font-semibold hover:bg-[#242424] hover:text-white transition-colors"
            >
              Back to Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  // If cart is empty and no order placed
  if (cart.length === 0) {
    return (
      <div className="py-24 text-center space-y-4">
        <ShoppingBag className="w-12 h-12 text-[#D8CEC8] mx-auto" />
        <h2 className="font-serif text-2xl text-[#242424]">Your bag is empty.</h2>
        <p className="text-xs text-[#242424]/60">
          Add some beautiful pieces before proceeding to checkout.
        </p>
        <button
          onClick={() => setActivePage('shop')}
          className="px-6 py-2.5 bg-[#242424] text-white text-xs uppercase font-semibold"
        >
          Explore Shop
        </button>
      </div>
    );
  }

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.address) return;

    setIsSubmitting(true);

    const newOrder: Omit<Order, 'id' | 'createdAt'> = {
      customer: {
        ...formData
      },
      items: cart.map((i) => ({
        productId: i.productId,
        name: i.product.name,
        price: i.product.price,
        quantity: i.quantity,
        size: i.selectedSize,
        image: i.product.images[0]
      })),
      subtotal: cartSubtotal,
      shippingFee,
      total: grandTotal,
      paymentMethod,
      paymentStatus: paymentMethod === 'cod' ? 'pending' : 'verification_required',
      status: 'Pending'
    };

    setTimeout(() => {
      const placed = addOrder(newOrder);
      clearCart();
      setLastPlacedOrder(placed);
      setIsSubmitting(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 400);
  };

  const pakistanCities = [
    'Lahore',
    'Karachi',
    'Islamabad',
    'Rawalpindi',
    'Faisalabad',
    'Multan',
    'Peshawar',
    'Sialkot',
    'Gujranwala',
    'Quetta',
    'Hyderabad',
    'Abbottabad',
    'Bahawalpur',
    'Sargodha',
    'Other City / Town'
  ];

  return (
    <div className="bg-[#FAF8F5] pt-8 pb-20 sm:pb-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="mb-10 text-center">
          <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold mb-1">
            Express Checkout
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
            Delivery & Payment Information
          </h1>
        </div>

        <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* LEFT: Shipping Form & Payment Selection (7 cols) */}
          <div className="lg:col-span-7 space-y-8">
            
            {/* Contact Information */}
            <div className="bg-white p-6 sm:p-8 border border-[#D8CEC8] shadow-xs space-y-4">
              <h2 className="font-serif text-xl text-[#242424] font-medium border-b border-[#D8CEC8]/40 pb-3">
                1. Contact Information
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Fatima Zahra"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                  />
                </div>

                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    WhatsApp Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 0300 1234567"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Email Address (For receipt)
                  </label>
                  <input
                    type="email"
                    placeholder="e.g. fatima@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                  />
                </div>
              </div>
            </div>

            {/* Shipping Address */}
            <div className="bg-white p-6 sm:p-8 border border-[#D8CEC8] shadow-xs space-y-4">
              <h2 className="font-serif text-xl text-[#242424] font-medium border-b border-[#D8CEC8]/40 pb-3">
                2. Shipping Address in Pakistan
              </h2>

              <div className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Street Address, House #, Building, Sector *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. House 42-B, Street 5, Phase 5 DHA"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                      City *
                    </label>
                    <select
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                    >
                      {pakistanCities.map((city) => (
                        <option key={city} value={city}>
                          {city}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                      Postal Code (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. 54000"
                      value={formData.postalCode}
                      onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Delivery Instructions / Courier Note
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Call before delivery / deliver between 2 PM to 6 PM"
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                    className="w-full px-3 py-2.5 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                  />
                </div>
              </div>
            </div>

            {/* Payment Method Selection */}
            <div className="bg-white p-6 sm:p-8 border border-[#D8CEC8] shadow-xs space-y-4">
              <h2 className="font-serif text-xl text-[#242424] font-medium border-b border-[#D8CEC8]/40 pb-3">
                3. Payment Method
              </h2>

              <div className="space-y-3 text-xs">
                {/* Option 1: Cash on Delivery */}
                <label
                  className={`flex items-start gap-3 p-4 border cursor-pointer transition-colors ${
                    paymentMethod === 'cod'
                      ? 'border-[#242424] bg-[#FAF8F5]'
                      : 'border-[#D8CEC8] hover:border-[#242424]/40'
                  }`}
                >
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'cod'}
                    onChange={() => setPaymentMethod('cod')}
                    className="mt-0.5 accent-[#242424]"
                  />
                  <div className="space-y-1">
                    <div className="font-semibold text-[#242424]">
                      Cash on Delivery (COD) — Nationwide
                    </div>
                    <div className="text-[#242424]/70 leading-relaxed">
                      Pay cash directly to the courier rider upon parcel arrival at your doorstep.
                    </div>
                  </div>
                </label>

                {/* Option 2: Bank Transfer */}
                <label
                  className={`flex items-start gap-3 p-4 border cursor-pointer transition-colors ${
                    paymentMethod === 'bank_transfer'
                      ? 'border-[#242424] bg-[#FAF8F5]'
                      : 'border-[#D8CEC8] hover:border-[#242424]/40'
                  }`}
                >
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'bank_transfer'}
                    onChange={() => setPaymentMethod('bank_transfer')}
                    className="mt-0.5 accent-[#242424]"
                  />
                  <div className="space-y-1">
                    <div className="font-semibold text-[#242424]">
                      Advance Bank Transfer (Meezan Bank)
                    </div>
                    <div className="text-[#242424]/70 leading-relaxed">
                      Transfer via your mobile banking app. Account details and IBAN provided upon confirmation.
                    </div>
                  </div>
                </label>

                {/* Option 3: JazzCash / EasyPaisa */}
                <label
                  className={`flex items-start gap-3 p-4 border cursor-pointer transition-colors ${
                    paymentMethod === 'easypaisa_jazzcash'
                      ? 'border-[#242424] bg-[#FAF8F5]'
                      : 'border-[#D8CEC8] hover:border-[#242424]/40'
                  }`}
                >
                  <input
                    type="radio"
                    name="payment"
                    checked={paymentMethod === 'easypaisa_jazzcash'}
                    onChange={() => setPaymentMethod('easypaisa_jazzcash')}
                    className="mt-0.5 accent-[#242424]"
                  />
                  <div className="space-y-1">
                    <div className="font-semibold text-[#242424]">
                      EasyPaisa / JazzCash
                    </div>
                    <div className="text-[#242424]/70 leading-relaxed">
                      Direct mobile wallet transfer to {settings.easypaisaNumber}.
                    </div>
                  </div>
                </label>
              </div>
            </div>

          </div>

          {/* RIGHT: Order Summary (5 cols) */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-28">
            <div className="bg-white p-6 sm:p-8 border border-[#D8CEC8] shadow-xs space-y-6">
              <h2 className="font-serif text-xl text-[#242424] font-medium border-b border-[#D8CEC8]/40 pb-3">
                Order Summary ({cart.reduce((a, b) => a + b.quantity, 0)} Items)
              </h2>

              {/* Items List */}
              <div className="space-y-4 max-h-72 overflow-y-auto pr-1">
                {cart.map((item) => (
                  <div key={item.id} className="flex gap-3 text-xs pb-3 border-b border-[#D8CEC8]/30">
                    <img
                      src={item.product.images[0]}
                      alt=""
                      className="w-14 h-16 object-cover bg-[#F4EFEB] border border-[#D8CEC8]/40 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-[#242424] truncate">
                        {item.product.name}
                      </div>
                      <div className="text-[#242424]/60">
                        Size: {item.selectedSize} · Qty: {item.quantity}
                      </div>
                      <div className="font-medium text-[#242424] tabular-nums mt-1">
                        {formatPKR(item.product.price * item.quantity)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pricing Totals */}
              <div className="space-y-2 text-xs text-[#242424]/80 border-t border-[#D8CEC8]/50 pt-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-[#242424] tabular-nums">
                    {formatPKR(cartSubtotal)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Courier Delivery (Pakistan)</span>
                  <span>
                    {shippingFee === 0 ? (
                      <span className="text-emerald-800 font-medium">FREE</span>
                    ) : (
                      formatPKR(shippingFee)
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-base font-bold text-[#242424] border-t border-[#D8CEC8] pt-3">
                  <span>Total Amount</span>
                  <span className="tabular-nums">{formatPKR(grandTotal)}</span>
                </div>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 shadow-sm"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'Placing Order...' : 'Place Order (Cash on Delivery)'}</span>
              </button>

              {/* Trust Badges */}
              <div className="pt-2 border-t border-[#D8CEC8]/40 space-y-2 text-[11px] text-[#242424]/70">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#A57E78]" />
                  <span>316L Surgical Steel · 100% Non-Tarnish Guarantee</span>
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="w-3.5 h-3.5 text-[#A57E78]" />
                  <span>Dispatched via TCS / Leopards / Call Courier</span>
                </div>
                <div className="flex items-center gap-2">
                  <RotateCcw className="w-3.5 h-3.5 text-[#A57E78]" />
                  <span>7-Day Hassle-Free Exchange Privilege</span>
                </div>
              </div>
            </div>
          </div>

        </form>

      </div>
    </div>
  );
};
