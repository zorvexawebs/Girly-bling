import React from 'react';
import { useStore } from '../context/StoreContext';
import { CustomerReviews } from '../components/CustomerReviews';

interface PolicyViewProps {
  type: 'shipping' | 'returns' | 'privacy' | 'terms' | 'reviews';
}

export const PolicyView: React.FC<PolicyViewProps> = ({ type }) => {
  const { settings } = useStore();

  if (type === 'reviews') {
    return (
      <div className="bg-[#FAF8F5] pt-8">
        <CustomerReviews />
      </div>
    );
  }

  const titles = {
    shipping: 'Shipping & Delivery Across Pakistan',
    returns: 'Returns & 7-Day Exchange Policy',
    privacy: 'Privacy & Data Protection Policy',
    terms: 'Terms & Conditions of Service'
  };

  const contentMap = {
    shipping: settings.shippingPolicy,
    returns: settings.returnPolicy,
    privacy: settings.privacyPolicy,
    terms: settings.termsPolicy
  };

  return (
    <div className="bg-[#FAF8F5] pt-8 pb-20 sm:pb-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center py-12 border-b border-[#D8CEC8]/40 mb-12">
          <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold mb-2">
            Client Guidelines
          </div>
          <h1 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
            {titles[type]}
          </h1>
        </div>

        <div className="bg-white p-8 sm:p-12 border border-[#D8CEC8] shadow-xs text-xs sm:text-sm text-[#242424]/80 leading-relaxed whitespace-pre-line space-y-4">
          {contentMap[type]}
        </div>

      </div>
    </div>
  );
};
