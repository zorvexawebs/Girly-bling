import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCard } from '../components/ProductCard';
import { Product } from '../types';
import { Filter, SlidersHorizontal, ArrowUpDown, X } from 'lucide-react';
import { formatPKR } from '../utils/formatters';

export const ShopView: React.FC<{ onQuickView: (product: Product) => void }> = ({ onQuickView }) => {
  const { products } = useStore();

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedSort, setSelectedSort] = useState<'featured' | 'newest' | 'price-asc' | 'price-desc' | 'best-selling'>('featured');
  const [maxPrice, setMaxPrice] = useState<number>(6000);
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [isFilterDrawerOpen, setIsFilterDrawerOpen] = useState(false);

  const categories = ['All', 'Necklaces', 'Rings', 'Bracelets & Bangles', 'Earrings'];

  const filteredAndSortedProducts = useMemo(() => {
    return products
      .filter((product) => {
        if (selectedCategory !== 'All' && product.category !== selectedCategory) {
          return false;
        }
        if (product.price > maxPrice) {
          return false;
        }
        if (inStockOnly && product.stockStatus === 'sold_out') {
          return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (selectedSort === 'newest') {
          return (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0);
        }
        if (selectedSort === 'price-asc') {
          return a.price - b.price;
        }
        if (selectedSort === 'price-desc') {
          return b.price - a.price;
        }
        if (selectedSort === 'best-selling') {
          return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0);
        }
        return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
      });
  }, [products, selectedCategory, maxPrice, inStockOnly, selectedSort]);

  return (
    <div className="bg-[#FAF8F5] pt-8 pb-20 sm:pb-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Collection Hero Banner */}
        <div className="py-12 border-b border-[#D8CEC8]/40 mb-10 text-center">
          <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold mb-2">
            The Complete Atelier
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl text-[#242424] font-medium tracking-tight">
            Shop All Jewellery
          </h1>
          <p className="mt-3 text-sm sm:text-base text-[#242424]/70 max-w-xl mx-auto">
            100% waterproof, non-tarnish 316L stainless steel finished in 18K vacuum gold. Crafted for modern women across Pakistan.
          </p>
        </div>

        {/* Filter Bar & Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 mb-8 border-b border-[#D8CEC8]/40">
          
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-1 p-1 bg-[#F4EFEB] border border-[#D8CEC8]/50">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-[#242424] text-white shadow-xs'
                    : 'text-[#242424]/70 hover:text-[#242424]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Right controls: In-stock, price & sort */}
          <div className="flex items-center gap-4 text-xs">
            {/* In stock toggle */}
            <label className="flex items-center gap-2 cursor-pointer text-[#242424]/80">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="w-3.5 h-3.5 accent-[#242424]"
              />
              <span>In Stock Only</span>
            </label>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-1.5">
              <span className="text-[#242424]/60">Sort:</span>
              <select
                value={selectedSort}
                onChange={(e) => setSelectedSort(e.target.value as any)}
                className="px-2.5 py-1.5 bg-white border border-[#D8CEC8] text-xs text-[#242424] focus:outline-hidden"
              >
                <option value="featured">Featured</option>
                <option value="best-selling">Best Sellers</option>
                <option value="newest">New Arrivals</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>
          </div>

        </div>

        {/* Product Grid / Empty State */}
        {filteredAndSortedProducts.length === 0 ? (
          <div className="py-24 text-center space-y-4">
            <h3 className="font-serif text-2xl text-[#242424]">No jewellery found.</h3>
            <p className="text-xs text-[#242424]/60">
              Try adjusting your category selection or increasing the price filter.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setMaxPrice(6000);
                setInStockOnly(false);
              }}
              className="px-6 py-2 bg-[#242424] text-white text-xs uppercase tracking-wider font-semibold"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
            {filteredAndSortedProducts.map((product) => (
              <ProductCard key={product.id} product={product} onQuickView={onQuickView} />
            ))}
          </div>
        )}

      </div>
    </div>
  );
};
