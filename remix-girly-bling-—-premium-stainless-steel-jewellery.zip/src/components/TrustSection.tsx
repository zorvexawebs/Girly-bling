import React from 'react';
import { Truck, RotateCcw, ShieldCheck, Headphones } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { formatPKR } from '../utils/formatters';

export const TrustSection: React.FC = () => {
  const { settings } = useStore();

  const trustItems = [
    {
      icon: Truck,
      title: 'Nationwide Delivery',
      desc: `Free shipping across Pakistan on orders over ${formatPKR(settings.freeShippingThreshold)}. Standard COD flat fee Rs. ${settings.standardShippingFee}.`
    },
    {
      icon: RotateCcw,
      title: '7-Day Easy Exchange',
      desc: 'Hassle-free size or style exchanges within 7 days of delivery.'
    },
    {
      icon: ShieldCheck,
      title: 'Zero Tarnish Guarantee',
      desc: 'Precision 316L stainless steel engineered for water and sweat resistance.'
    },
    {
      icon: Headphones,
      title: 'WhatsApp Concierge',
      desc: 'Immediate, personalized assistance for orders, sizing, and delivery status.'
    }
  ];

  return (
    <section className="py-12 bg-[#FAF8F5] border-t border-[#D8CEC8]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {trustItems.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-[#F4EFEB] flex items-center justify-center text-[#A57E78] shrink-0">
                  <Icon className="w-5 h-5 stroke-[1.5]" />
                </div>
                <div>
                  <h4 className="font-serif text-base font-medium text-[#242424] mb-1">
                    {item.title}
                  </h4>
                  <p className="text-xs text-[#242424]/70 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
