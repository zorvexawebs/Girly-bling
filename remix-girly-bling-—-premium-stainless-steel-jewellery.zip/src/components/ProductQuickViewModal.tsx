import React, { useState } from 'react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';
import { X, Heart, ShoppingBag, ShieldCheck, Droplets, Check, MessageSquare } from 'lucide-react';
import { formatPKR } from '../utils/formatters';

interface ProductQuickViewModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductQuickViewModal: React.FC<ProductQuickViewModalProps> = ({ product, onClose }) => {
  const { addToCart, toggleWishlist, isInWishlist, generateWhatsAppOrderUrl, openProductDetail } = useStore();

  if (!product) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState(product.sizes[0] || 'Standard');
  const [quantity, setQuantity] = useState(1);
  const isWishlisted = isInWishlist(product.id);

  const handleAddToCart = () => {
    addToCart(product, selectedSize, quantity);
    onClose();
  };

  const handleWhatsAppOrder = () => {
    const url = generateWhatsAppOrderUrl(product, selectedSize, quantity);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242424]/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-[#FAF8F5] max-w-4xl w-full max-h-[90vh] overflow-y-auto border border-[#D8CEC8] shadow-2xl relative flex flex-col md:flex-row"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close modal"
          className="absolute top-4 right-4 z-20 p-2 text-[#242424]/70 hover:text-[#242424] bg-[#FAF8F5]/80 rounded-full hover:bg-[#FAF8F5] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left: Gallery */}
        <div className="md:w-1/2 p-6 flex flex-col">
          <div className="relative aspect-[4/5] w-full bg-[#F4EFEB] overflow-hidden mb-3">
            <img
              src={product.images[activeImageIndex] || product.images[0]}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-2 overflow-x-auto pb-1">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-16 h-16 flex-shrink-0 border transition-all ${
                    activeImageIndex === idx ? 'border-[#242424] opacity-100' : 'border-[#D8CEC8] opacity-60 hover:opacity-90'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Info & Purchase Controls */}
        <div className="md:w-1/2 p-6 md:p-8 flex flex-col justify-between border-t md:border-t-0 md:border-l border-[#D8CEC8]/40">
          <div className="space-y-4">
            <div className="text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold">
              {product.category} · {product.collection}
            </div>

            <h2 className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium leading-tight">
              {product.name}
            </h2>

            {/* Price */}
            <div className="flex items-baseline gap-3">
              <span className="text-2xl font-bold text-[#242424] tabular-nums">
                {formatPKR(product.price)}
              </span>
              {product.originalPrice && product.originalPrice > product.price && (
                <span className="text-sm text-[#242424]/40 line-through tabular-nums">
                  {formatPKR(product.originalPrice)}
                </span>
              )}
            </div>

            <p className="text-sm text-[#242424]/80 leading-relaxed">
              {product.description}
            </p>

            {/* Material summary */}
            <div className="p-3 bg-[#F4EFEB]/60 border border-[#D8CEC8]/40 text-xs space-y-1.5 text-[#242424]/80">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-3.5 h-3.5 text-[#C9A6A0]" />
                <span className="font-medium">{product.material}</span>
              </div>
              <div className="flex items-center gap-2">
                <Droplets className="w-3.5 h-3.5 text-[#C9A6A0]" />
                <span>100% Waterproof · Non-Tarnish · Hypoallergenic</span>
              </div>
            </div>

            {/* Size Selector */}
            {product.sizes.length > 0 && (
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#242424]/80 mb-2">
                  Select Size
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`px-3 py-1.5 text-xs font-medium border transition-colors ${
                        selectedSize === s
                          ? 'border-[#242424] bg-[#242424] text-white'
                          : 'border-[#D8CEC8] text-[#242424] hover:border-[#242424]'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity Stepper */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#242424]/80 mb-2">
                Quantity
              </label>
              <div className="flex items-center border border-[#D8CEC8] w-28">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 flex items-center justify-center text-sm hover:bg-[#D8CEC8]/20 transition-colors"
                >
                  -
                </button>
                <span className="flex-1 text-center text-xs font-semibold tabular-nums">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-8 h-8 flex items-center justify-center text-sm hover:bg-[#D8CEC8]/20 transition-colors"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="pt-6 space-y-2.5">
            <div className="flex gap-2">
              <button
                onClick={handleAddToCart}
                disabled={product.stockStatus === 'sold_out'}
                className="flex-1 py-3 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{product.stockStatus === 'sold_out' ? 'Sold Out' : 'Add to Bag'}</span>
              </button>

              <button
                onClick={() => toggleWishlist(product.id)}
                aria-label="Wishlist"
                className="p-3 border border-[#D8CEC8] text-[#242424] hover:text-[#C9A6A0] transition-colors"
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-[#C9A6A0] text-[#C9A6A0]' : ''}`} />
              </button>
            </div>

            <button
              onClick={handleWhatsAppOrder}
              className="w-full py-2.5 bg-[#25D366]/10 border border-[#25D366]/40 text-[#128C7E] text-xs uppercase tracking-wider font-semibold hover:bg-[#25D366]/20 transition-colors flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Order via WhatsApp</span>
            </button>

            <button
              onClick={() => {
                onClose();
                openProductDetail(product.id);
              }}
              className="w-full text-center text-xs text-[#242424]/60 hover:text-[#242424] underline pt-1"
            >
              View Full Product Details & Sizing Guide &rarr;
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
