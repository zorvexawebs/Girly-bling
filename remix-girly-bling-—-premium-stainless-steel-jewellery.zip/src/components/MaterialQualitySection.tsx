import React, { useState } from 'react';
import { ShieldCheck, Droplets, Sun, Sparkles, CheckCircle2 } from 'lucide-react';

export const MaterialQualitySection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'material' | 'plating' | 'care'>('material');

  return (
    <section className="py-20 sm:py-28 bg-[#FAF8F5] border-t border-[#D8CEC8]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold mb-2">
            Science & Craftsmanship
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
            Understanding 316L Stainless Steel
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#242424]/75">
            Why our jewellery remains radiant year after year without tarnishing, green staining, or irritating delicate skin.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex justify-center mb-10">
          <div className="inline-flex p-1 bg-[#F4EFEB] border border-[#D8CEC8]/60">
            <button
              onClick={() => setActiveTab('material')}
              className={`px-5 py-2 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                activeTab === 'material' ? 'bg-[#242424] text-white shadow-xs' : 'text-[#242424]/70 hover:text-[#242424]'
              }`}
            >
              The Alloy (316L)
            </button>
            <button
              onClick={() => setActiveTab('plating')}
              className={`px-5 py-2 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                activeTab === 'plating' ? 'bg-[#242424] text-white shadow-xs' : 'text-[#242424]/70 hover:text-[#242424]'
              }`}
            >
              18K PVD Gold Plating
            </button>
            <button
              onClick={() => setActiveTab('care')}
              className={`px-5 py-2 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
                activeTab === 'care' ? 'bg-[#242424] text-white shadow-xs' : 'text-[#242424]/70 hover:text-[#242424]'
              }`}
            >
              Care & Longevity
            </button>
          </div>
        </div>

        {/* Tab Content Cards */}
        <div className="bg-[#FAF8F5] border border-[#D8CEC8] p-8 sm:p-12 shadow-sm">
          {activeTab === 'material' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 text-xs uppercase tracking-wider text-[#C9A6A0] font-semibold">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Surgical-Grade Metallurgy</span>
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium">
                  Pure 316L Stainless Steel
                </h3>
                <p className="text-sm text-[#242424]/80 leading-relaxed">
                  Unlike conventional fashion jewellery made of brass, copper, or zinc alloys that react with skin moisture to produce copper carbonate (the notorious green mark), 316L contains low carbon and high chromium-nickel-molybdenum stability.
                </p>
                <div className="space-y-2 pt-2">
                  <div className="flex items-start gap-2.5 text-xs text-[#242424]/80">
                    <CheckCircle2 className="w-4 h-4 text-[#C9A6A0] shrink-0 mt-0.5" />
                    <span><strong>100% Hypoallergenic:</strong> Safe for sensitive lobes and eczema-prone skin.</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-[#242424]/80">
                    <CheckCircle2 className="w-4 h-4 text-[#C9A6A0] shrink-0 mt-0.5" />
                    <span><strong>Exceptional Tensile Strength:</strong> Chains and prongs will not warp, snap, or loosen easily.</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-[#242424]/80">
                    <CheckCircle2 className="w-4 h-4 text-[#C9A6A0] shrink-0 mt-0.5" />
                    <span><strong>Eco-Conscious Durability:</strong> Infinitely recyclable and engineered to last seasons, reducing fast-fashion waste.</span>
                  </div>
                </div>
              </div>

              {/* Comparison Box */}
              <div className="p-6 bg-[#F4EFEB]/70 border border-[#D8CEC8]/60 space-y-4">
                <h4 className="font-serif text-lg text-[#242424] font-medium">
                  Traditional Alloy vs. Girly Bling 316L
                </h4>
                <div className="space-y-3 text-xs">
                  <div className="pb-3 border-b border-[#D8CEC8]/50">
                    <div className="font-semibold text-rose-800 mb-0.5">Ordinary Brass / Zinc Alloy:</div>
                    <div className="text-[#242424]/70">Fades in 2-4 weeks, oxidizes green with body heat, contains allergic nickel residues.</div>
                  </div>
                  <div>
                    <div className="font-semibold text-[#242424] mb-0.5">Girly Bling 316L Surgical Steel:</div>
                    <div className="text-[#242424]/70">Withstands water, sweat, perfume, and heat without tarnishing or turning skin green.</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'plating' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 text-xs uppercase tracking-wider text-[#C9A6A0] font-semibold">
                  <Sun className="w-4 h-4" />
                  <span>Vacuum Chamber Metallurgy</span>
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium">
                  18K PVD Physical Vapor Deposition
                </h3>
                <p className="text-sm text-[#242424]/80 leading-relaxed">
                  Traditional gold plating relies on thin chemical dipping that peels off with minor friction. Girly Bling utilizes vacuum PVD (Physical Vapor Deposition) technology, vaporizing pure 18K gold at extreme temperatures into atomic ions that fuse directly into the steel surface.
                </p>
                <div className="space-y-2 pt-2">
                  <div className="flex items-start gap-2.5 text-xs text-[#242424]/80">
                    <CheckCircle2 className="w-4 h-4 text-[#C9A6A0] shrink-0 mt-0.5" />
                    <span><strong>10x Thicker Bond:</strong> Up to ten times more wear-resistant than standard flash electroplating.</span>
                  </div>
                  <div className="flex items-start gap-2.5 text-xs text-[#242424]/80">
                    <CheckCircle2 className="w-4 h-4 text-[#C9A6A0] shrink-0 mt-0.5" />
                    <span><strong>Authentic Warmth:</strong> Precision calibrated to genuine 18K champagne gold hue — neither brassy nor fake yellow.</span>
                  </div>
                </div>
              </div>

              <div className="p-6 bg-[#F4EFEB]/70 border border-[#D8CEC8]/60 space-y-3">
                <div className="flex items-center gap-2 text-[#C9A6A0]">
                  <Droplets className="w-5 h-5" />
                  <span className="font-serif text-lg font-medium text-[#242424]">Waterproof Guarantee</span>
                </div>
                <p className="text-xs text-[#242424]/80 leading-relaxed">
                  Because PVD does not flake or leach, your pieces remain resilient through everyday life: showering, washing hands, perfume spritzes, and beach outings.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'care' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 text-xs uppercase tracking-wider text-[#C9A6A0] font-semibold">
                  <Sparkles className="w-4 h-4" />
                  <span>Simple Maintenance</span>
                </div>
                <h3 className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium">
                  Effortless Jewellery Care
                </h3>
                <p className="text-sm text-[#242424]/80 leading-relaxed">
                  Caring for stainless steel is remarkably straightforward. Follow these simple tips to ensure your pieces maintain their liquid gold shine forever:
                </p>
                <ul className="space-y-2 text-xs text-[#242424]/80">
                  <li className="flex items-start gap-2">
                    <span className="text-[#C9A6A0] font-bold">1.</span>
                    <span><strong>Wipe Clean:</strong> Occasionally polish with a soft microfibre cloth to remove lotions or oils.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#C9A6A0] font-bold">2.</span>
                    <span><strong>Rinse After Salt / Pool:</strong> If swimming in chlorine or the Arabian Sea, rinse with tap water and pat dry.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#C9A6A0] font-bold">3.</span>
                    <span><strong>Velvet Storage:</strong> Store in your provided Girly Bling velvet box to prevent accidental surface scuffs from keys or coins.</span>
                  </li>
                </ul>
              </div>

              <div className="p-6 bg-[#F4EFEB]/70 border border-[#D8CEC8]/60 space-y-3">
                <h4 className="font-serif text-lg text-[#242424] font-medium">
                  What to Avoid
                </h4>
                <p className="text-xs text-[#242424]/80 leading-relaxed">
                  While our stainless steel is virtually impervious to daily water, we advise avoiding harsh industrial acids, abrasive scouring pads, or chlorine bleach, which can erode microscopic gold layers over prolonged contact.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>
    </section>
  );
};
