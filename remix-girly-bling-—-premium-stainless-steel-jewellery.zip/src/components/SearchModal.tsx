import React, { useRef, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { Search, X, ArrowRight } from 'lucide-react';
import { formatPKR } from '../utils/formatters';

export const SearchModal: React.FC = () => {
  const {
    isSearchOpen,
    setIsSearchOpen,
    searchQuery,
    setSearchQuery,
    products,
    openProductDetail
  } = useStore();

  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isSearchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isSearchOpen]);

  if (!isSearchOpen) return null;

  const trimmed = searchQuery.trim().toLowerCase();

  const filteredProducts = trimmed
    ? products.filter(
        (p) =>
          p.name.toLowerCase().includes(trimmed) ||
          p.category.toLowerCase().includes(trimmed) ||
          p.collection.toLowerCase().includes(trimmed) ||
          p.material.toLowerCase().includes(trimmed) ||
          p.tags.some((t) => t.toLowerCase().includes(trimmed))
      )
    : [];

  const handleSelectProduct = (id: string) => {
    setIsSearchOpen(false);
    openProductDetail(id);
  };

  const suggestedTags = ['Waterproof', 'Herringbone', 'Croissant', 'Gold Rings', 'Tennis Bracelet', 'Teardrop'];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16 sm:pt-24 bg-[#242424]/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-[#FAF8F5] max-w-2xl w-full border border-[#D8CEC8] shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 sm:p-6 border-b border-[#D8CEC8] flex items-center gap-3">
          <Search className="w-5 h-5 text-[#242424]/60 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by jewellery piece, style, material, or category..."
            className="flex-1 bg-transparent text-sm sm:text-base text-[#242424] placeholder:text-[#242424]/40 focus:outline-hidden"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-[#242424]/50 hover:text-[#242424]"
            >
              Clear
            </button>
          )}
          <button
            onClick={() => setIsSearchOpen(false)}
            aria-label="Close search"
            className="p-1 text-[#242424]/60 hover:text-[#242424]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Suggested Quick Tags */}
        <div className="px-6 py-3 bg-[#F4EFEB]/60 border-b border-[#D8CEC8]/40 flex items-center gap-2 overflow-x-auto text-xs text-[#242424]/70">
          <span className="shrink-0 uppercase tracking-wider font-semibold text-[10px]">Popular:</span>
          {suggestedTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSearchQuery(tag)}
              className="px-2.5 py-1 bg-[#FAF8F5] border border-[#D8CEC8] hover:border-[#242424] text-[11px] whitespace-nowrap transition-colors cursor-pointer"
            >
              {tag}
            </button>
          ))}
        </div>

        {/* Results Container */}
        <div className="max-h-[60vh] overflow-y-auto p-6">
          {searchQuery.trim() === '' ? (
            <div className="text-center py-10 text-xs text-[#242424]/60">
              Type to explore our stainless-steel necklaces, rings, bangles, and earrings.
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center py-12 space-y-2">
              <p className="font-serif text-lg text-[#242424]">
                We couldn't find anything matching your search.
              </p>
              <p className="text-xs text-[#242424]/60">
                Try searching for "gold", "waterproof", "necklace", or "ring".
              </p>
            </div>
          ) : (
            <div className="divide-y divide-[#D8CEC8]/40">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  onClick={() => handleSelectProduct(product.id)}
                  className="py-3 flex items-center gap-4 hover:bg-[#F4EFEB]/60 px-2 cursor-pointer transition-colors"
                >
                  <img
                    src={product.images[0] || '/src/assets/images/product_travertine_jewellery_1790183496193.jpg'}
                    alt={product.name}
                    className="w-14 h-16 object-cover bg-[#F4EFEB] border border-[#D8CEC8]/40 shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-[10px] uppercase tracking-wider text-[#A57E78] font-semibold">
                      {product.category} · {product.material}
                    </div>
                    <div className="font-serif text-sm text-[#242424] font-medium truncate">
                      {product.name}
                    </div>
                    <div className="text-xs font-semibold text-[#242424] mt-0.5 tabular-nums">
                      {formatPKR(product.price)}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#242424]/40" />
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
