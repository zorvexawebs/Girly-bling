import React from 'react';
import { useStore } from '../context/StoreContext';
import { Instagram, Facebook, MessageSquare, ShieldCheck, ArrowUpRight } from 'lucide-react';

export const Footer: React.FC<{ onOpenSizeGuide?: () => void }> = ({ onOpenSizeGuide }) => {
  const { settings, setActivePage, setIsDashboardOpen } = useStore();

  const handleNav = (page: any) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#242424] text-[#FAF8F5] pt-16 pb-12 border-t border-[#383838]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-[#383838]">
          
          {/* Brand Column (2 cols on lg) */}
          <div className="lg:col-span-2 space-y-4">
            <span className="font-serif text-3xl font-medium tracking-tight text-[#FAF8F5]">
              {settings.businessName}
            </span>
            <p className="text-xs sm:text-sm text-[#FAF8F5]/70 max-w-sm leading-relaxed">
              {settings.brandDescription ||
                'Pakistani stainless-steel jewellery brand crafting 100% waterproof, non-tarnish, and hypoallergenic everyday luxury pieces with nationwide Cash on Delivery.'}
            </p>

            <div className="pt-2 text-xs text-[#FAF8F5]/60 space-y-1">
              <div>{settings.address}</div>
              <div>Concierge: {settings.phone}</div>
              <div>Hours: {settings.businessHours}</div>
            </div>

            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-3">
              <a
                href={settings.instagramUrl || 'https://instagram.com/girlybling.pk'}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="w-8 h-8 rounded-full bg-[#383838] flex items-center justify-center text-[#FAF8F5]/80 hover:text-white hover:bg-[#C9A6A0] transition-colors"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={settings.facebookUrl || 'https://facebook.com/girlybling.pk'}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Facebook"
                className="w-8 h-8 rounded-full bg-[#383838] flex items-center justify-center text-[#FAF8F5]/80 hover:text-white hover:bg-[#C9A6A0] transition-colors"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp"
                className="w-8 h-8 rounded-full bg-[#383838] flex items-center justify-center text-[#FAF8F5]/80 hover:text-white hover:bg-[#25D366] transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-[#FAF8F5]/40 font-semibold">
              Explore
            </h4>
            <ul className="space-y-2 text-xs text-[#FAF8F5]/80">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-white transition-colors cursor-pointer">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('shop')} className="hover:text-white transition-colors cursor-pointer">
                  Shop Collection
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-white transition-colors cursor-pointer">
                  Our Story & Craft
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('lookbook')} className="hover:text-white transition-colors cursor-pointer">
                  Lookbook
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('reviews')} className="hover:text-white transition-colors cursor-pointer">
                  Customer Reviews
                </button>
              </li>
            </ul>
          </div>

          {/* Customer Care */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-[#FAF8F5]/40 font-semibold">
              Client Concierge
            </h4>
            <ul className="space-y-2 text-xs text-[#FAF8F5]/80">
              <li>
                <button onClick={() => handleNav('shipping')} className="hover:text-white transition-colors cursor-pointer">
                  Shipping in Pakistan
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('returns')} className="hover:text-white transition-colors cursor-pointer">
                  Returns & Exchanges
                </button>
              </li>
              {onOpenSizeGuide && (
                <li>
                  <button onClick={onOpenSizeGuide} className="hover:text-white transition-colors cursor-pointer">
                    Jewellery Size Guide
                  </button>
                </li>
              )}
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-white transition-colors cursor-pointer">
                  Contact Us
                </button>
              </li>
              <li>
                <a
                  href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[#C9A6A0] hover:text-white transition-colors"
                >
                  <span>Order via WhatsApp</span>
                  <ArrowUpRight className="w-3 h-3" />
                </a>
              </li>
            </ul>
          </div>

          {/* Legal & Payment */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-widest text-[#FAF8F5]/40 font-semibold">
              Trust & Security
            </h4>
            <ul className="space-y-2 text-xs text-[#FAF8F5]/80">
              <li>
                <button onClick={() => handleNav('privacy')} className="hover:text-white transition-colors cursor-pointer">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('terms')} className="hover:text-white transition-colors cursor-pointer">
                  Terms & Conditions
                </button>
              </li>
            </ul>

            <div className="pt-4">
              <div className="text-[11px] uppercase tracking-wider text-[#FAF8F5]/50 mb-2">
                Accepted Payment Methods
              </div>
              <div className="flex flex-wrap gap-1.5 text-[11px] text-[#FAF8F5]/70">
                <span className="px-2 py-1 bg-[#383838] border border-[#484848]">Cash on Delivery</span>
                <span className="px-2 py-1 bg-[#383838] border border-[#484848]">Bank Transfer</span>
                <span className="px-2 py-1 bg-[#383838] border border-[#484848]">JazzCash / EasyPaisa</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#FAF8F5]/50 gap-4">
          <div>
            &copy; {new Date().getFullYear()} {settings.businessName}. All rights reserved. Registered in Pakistan.
          </div>

          <div className="flex items-center gap-4">
            <span>Currency: PKR (₨)</span>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsDashboardOpen(true)}
              className="hover:text-[#C9A6A0] transition-colors flex items-center gap-1 cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Owner Portal</span>
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
