import React from 'react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';
import { Heart, Eye, ShoppingBag } from 'lucide-react';
import { formatPKR } from '../utils/formatters';

interface ProductCardProps {
  product: Product;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const { toggleWishlist, isInWishlist, addToCart, openProductDetail } = useStore();
  const isWishlisted = isInWishlist(product.id);

  const mainImage = product.images[0] || '/src/assets/images/product_travertine_jewellery_1790183496193.jpg';
  const secondaryImage = product.images[1] || mainImage;

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (product.stockStatus === 'sold_out') return;
    const defaultSize = product.sizes[0] || 'Standard';
    addToCart(product, defaultSize, 1);
  };

  const handleWishlistClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  const handleQuickViewClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onQuickView) {
      onQuickView(product);
    } else {
      openProductDetail(product.id);
    }
  };

  return (
    <div
      onClick={() => openProductDetail(product.id)}
      className="group cursor-pointer flex flex-col h-full bg-[#FAF8F5] transition-all duration-300 border border-[#D8CEC8]/40 hover:border-[#C9A6A0]/60 hover:-translate-y-1 hover:shadow-md"
    >
      {/* Product Image Area */}
      <div className="relative aspect-[4/5] w-full overflow-hidden bg-[#F4EFEB]">
        {/* Main Image */}
        <img
          src={mainImage}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center transition-all duration-700 ease-out group-hover:scale-105 group-hover:opacity-0"
          onError={(e) => {
            e.currentTarget.src = '/src/assets/images/product_travertine_jewellery_1790183496193.jpg';
          }}
        />

        {/* Secondary Hover Image */}
        <img
          src={secondaryImage}
          alt={`${product.name} alternate view`}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center absolute inset-0 opacity-0 transition-all duration-700 ease-out group-hover:scale-105 group-hover:opacity-100"
          onError={(e) => {
            e.currentTarget.src = '/src/assets/images/product_travertine_jewellery_1790183496193.jpg';
          }}
        />

        {/* Wishlist Button (Always accessible) */}
        <button
          onClick={handleWishlistClick}
          aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-colors cursor-pointer ${
            isWishlisted
              ? 'bg-[#FAF8F5] text-[#A57E78] shadow-sm'
              : 'bg-[#FAF8F5]/80 text-[#242424]/60 hover:text-[#A57E78] hover:bg-[#FAF8F5]'
          }`}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Quiet Editorial Tag (Top Left) - Clean unboxed text */}
        <div className="absolute top-3 left-3 text-[10px] tracking-wider uppercase font-semibold text-[#242424] bg-[#FAF8F5]/90 px-2 py-0.5">
          {product.isNewArrival
            ? 'New'
            : product.isBestSeller
            ? 'Best Seller'
            : product.stockStatus === 'low_stock'
            ? 'Only Few Left'
            : product.category}
        </div>

        {/* Hover Quick Action Tray */}
        <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-[#242424]/60 to-transparent flex items-center justify-between gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            onClick={handleQuickViewClick}
            className="flex-1 py-2 bg-[#FAF8F5] text-[#242424] text-xs font-semibold tracking-wider uppercase hover:bg-white transition-colors flex items-center justify-center gap-1.5 shadow-sm"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Quick View</span>
          </button>
          {product.stockStatus !== 'sold_out' && (
            <button
              onClick={handleQuickAdd}
              aria-label="Quick add to bag"
              className="p-2 bg-[#242424] text-white hover:bg-black transition-colors"
            >
              <ShoppingBag className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Product Content Details */}
      <div className="p-4 flex flex-col flex-1 justify-between space-y-2">
        <div>
          {/* Unboxed Material & Category text */}
          <div className="text-[11px] tracking-widest uppercase text-[#242424]/60 flex items-center gap-1.5">
            <span>{product.category}</span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{product.collection}</span>
          </div>

          {/* Product Name */}
          <h3 className="font-serif text-base sm:text-lg text-[#242424] font-medium leading-snug line-clamp-1 group-hover:text-[#A57E78] transition-colors mt-1">
            {product.name}
          </h3>
        </div>

        {/* Pricing and Stock Status */}
        <div className="pt-1 flex items-baseline justify-between border-t border-[#D8CEC8]/30">
          <div className="flex items-baseline gap-2">
            <span className="text-sm sm:text-base font-semibold text-[#242424] tabular-nums">
              {formatPKR(product.price)}
            </span>
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="text-xs text-[#242424]/40 line-through tabular-nums">
                {formatPKR(product.originalPrice)}
              </span>
            )}
          </div>

          {/* Stock state indicator */}
          <div className="text-[11px] font-medium">
            {product.stockStatus === 'sold_out' ? (
              <span className="text-[#A57E78]">Sold Out</span>
            ) : product.stockStatus === 'low_stock' ? (
              <span className="text-[#C5A880]">Low Stock ({product.stock})</span>
            ) : (
              <span className="text-emerald-700/80">In Stock</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
