import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCard } from './ProductCard';
import { Product } from '../types';
import { ArrowRight } from 'lucide-react';

interface CuratedCollectionProps {
  onQuickView: (product: Product) => void;
}

export const CuratedCollection: React.FC<CuratedCollectionProps> = ({ onQuickView }) => {
  const { products, setActivePage } = useStore();
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Necklaces', 'Rings', 'Bracelets & Bangles', 'Earrings'];

  const filteredProducts = products.filter((product) => {
    if (activeCategory === 'All') return true;
    return product.category === activeCategory;
  });

  return (
    <section className="py-16 sm:py-24 bg-[#FAF8F5]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 pb-4 border-b border-[#D8CEC8]/40 gap-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold mb-2">
              Curated For You
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
              Signature Essentials
            </h2>
          </div>

          {/* Interactive Category Filter Tabs */}
          <div className="flex flex-wrap gap-1 p-1 bg-[#F4EFEB] rounded-none border border-[#D8CEC8]/50">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 py-1.5 text-xs font-medium tracking-wide uppercase transition-all whitespace-nowrap cursor-pointer ${
                  activeCategory === cat
                    ? 'bg-[#242424] text-white shadow-xs'
                    : 'text-[#242424]/70 hover:text-[#242424]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {filteredProducts.slice(0, 8).map((product) => (
            <ProductCard key={product.id} product={product} onQuickView={onQuickView} />
          ))}
        </div>

        {/* Explore All CTA */}
        <div className="mt-12 text-center">
          <button
            onClick={() => {
              setActivePage('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#242424] border-b border-[#242424] pb-1 hover:text-[#C9A6A0] hover:border-[#C9A6A0] transition-colors cursor-pointer"
          >
            <span>Explore All Jewellery ({products.length} Designs)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </section>
  );
};
