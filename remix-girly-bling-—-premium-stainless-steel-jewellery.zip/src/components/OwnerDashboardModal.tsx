import React, { useState, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { Product, Order, Review } from '../types';
import { formatPKR, formatDate } from '../utils/formatters';
import {
  X,
  LayoutDashboard,
  Package,
  ShoppingBag,
  Users,
  Star,
  Settings,
  Palette,
  FileText,
  Lock,
  Plus,
  Edit2,
  Trash2,
  Copy,
  CheckCircle,
  ExternalLink,
  MessageSquare,
  Search,
  Filter,
  UploadCloud,
  Image as ImageIcon,
  FolderOpen,
  RefreshCw,
  Check,
  Film,
  Video,
  Play,
  Volume2,
  Download,
  Globe,
  Server,
  Terminal,
  FileCode
} from 'lucide-react';

export const OwnerDashboardModal: React.FC = () => {
  const {
    isDashboardOpen,
    setIsDashboardOpen,
    isOwnerLoggedIn,
    setIsOwnerLoggedIn,
    settings,
    updateSettings,
    resetSettings,
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    duplicateProduct,
    orders,
    updateOrderStatus,
    reviews,
    addReview,
    updateReview,
    deleteReview,
    toggleReviewApproval,
    customers,
    showToast
  } = useStore();

  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [activeTab, setActiveTab] = useState<
    'overview' | 'products' | 'orders' | 'customers' | 'reviews' | 'heroMedia' | 'settings' | 'theme' | 'policies'
  >('overview');

  // Product form modal state
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [productForm, setProductForm] = useState<Omit<Product, 'id'>>({
    name: '',
    subtitle: '',
    description: '',
    price: 2500,
    originalPrice: 3000,
    category: 'Necklaces',
    collection: 'Timeless Essentials',
    material: '316L Stainless Steel, 18K Gold Plated',
    images: ['/src/assets/images/product_travertine_jewellery_1790183496193.jpg'],
    stock: 15,
    stockStatus: 'in_stock',
    sku: 'GB-PROD-01',
    sizes: ['Standard'],
    tags: ['Waterproof', 'Gold'],
    isFeatured: true,
    isNewArrival: false,
    isBestSeller: false,
    rating: 5.0,
    reviewCount: 1
  });

  // Settings form local state
  const [settingsForm, setSettingsForm] = useState(settings);

  // Drag-and-drop & gallery image uploader state
  const [isDraggingImage, setIsDraggingImage] = useState(false);
  const [imageInputMode, setImageInputMode] = useState<'upload' | 'gallery' | 'url'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file (PNG, JPG, WEBP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setProductForm((prev) => ({
          ...prev,
          images: [result, ...prev.images.slice(1)]
        }));
        showToast('Product photo updated successfully!');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDropImage = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingImage(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImageFile(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingImage(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingImage(false);
  };

  // Gallery presets compiled from existing assets and product library
  const galleryPresets = [
    {
      id: 'g-editorial-1',
      title: 'Aurelia Snake Chain Editorial',
      category: 'Necklaces',
      url: '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg'
    },
    {
      id: 'g-travertine-2',
      title: 'Travertine Stone & 18K Gold',
      category: 'Necklaces & Rings',
      url: '/src/assets/images/product_travertine_jewellery_1790183496193.jpg'
    },
    {
      id: 'g-velvet-3',
      title: 'Velvet Keepsake Box Packaging',
      category: 'Gift Sets',
      url: '/src/assets/images/brand_craftsmanship_story_1790183510549.jpg'
    },
    {
      id: 'g-lookbook-4',
      title: 'Croissant Dome Cuffs & Rings',
      category: 'Rings & Bangles',
      url: '/src/assets/images/lookbook_lifestyle_portrait_1790183522124.jpg'
    },
    ...products.map((p) => ({
      id: `p-${p.id}`,
      title: p.name,
      category: p.category,
      url: p.images[0]
    }))
  ].filter((item, index, self) => index === self.findIndex((t) => t.url === item.url));

  // Hero Media Showcase Uploader State (Picture & Video)
  const [heroImageInputMode, setHeroImageInputMode] = useState<'upload' | 'gallery' | 'url'>('upload');
  const [heroVideoInputMode, setHeroVideoInputMode] = useState<'upload' | 'presets' | 'url'>('upload');
  const [isDraggingHeroImage, setIsDraggingHeroImage] = useState(false);
  const [isDraggingHeroVideo, setIsDraggingHeroVideo] = useState(false);
  const heroImageInputRef = useRef<HTMLInputElement>(null);
  const heroVideoInputRef = useRef<HTMLInputElement>(null);

  // Sync settingsForm whenever settings or modal changes
  React.useEffect(() => {
    setSettingsForm(settings);
  }, [settings, isDashboardOpen]);

  const handleHeroImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file (PNG, JPG, WEBP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setSettingsForm((prev) => ({
          ...prev,
          heroImage: result
        }));
        showToast('Hero showcase photo updated!');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleHeroVideoFile = (file: File) => {
    if (!file.type.startsWith('video/')) {
      showToast('Please select a valid video file (MP4, WEBM, MOV).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setSettingsForm((prev) => ({
          ...prev,
          heroVideoUrl: result,
          heroMediaType: 'video'
        }));
        showToast('Hero showcase video updated!');
      }
    };
    reader.readAsDataURL(file);
  };

  // Curated Luxury Video Loops for Hero Reel
  const videoPresets = [
    {
      id: 'v-mixkit-gold-1',
      title: '18K Gold Necklace Motion Loop',
      url: 'https://assets.mixkit.co/videos/preview/mixkit-close-up-of-a-woman-wearing-golden-necklaces-42407-large.mp4',
      badge: 'Signature Finish',
      heading: '18K PVD Liquid Gold',
      description: 'Pure 316L surgical stainless steel infused with 18K vacuum PVD liquid gold plating. Built to stay radiant through every splash.'
    },
    {
      id: 'v-reflections-2',
      title: 'Specular Light Reflections Reel',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      badge: 'Editorial Reel',
      heading: 'Mirror-Polished Radiance',
      description: 'Hand-buffed mirror finish casting crisp specular highlights under warm sunlight and evening candlelight.'
    }
  ];

  if (!isDashboardOpen) return null;

  // Handle PIN authentication
  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Default PIN: 7860 or 1234
    if (pinInput === '7860' || pinInput === '1234') {
      setIsOwnerLoggedIn(true);
      setPinError('');
    } else {
      setPinError('Incorrect PIN. (Default owner PIN is 7860 or 1234)');
    }
  };

  // Product CRUD helpers
  const handleOpenAddProduct = () => {
    setEditingProductId(null);
    setProductForm({
      name: '',
      subtitle: '',
      description: '',
      price: 2500,
      originalPrice: 3000,
      category: 'Necklaces',
      collection: 'Timeless Essentials',
      material: '316L Surgical Stainless Steel, 18K Gold Plated',
      images: ['/src/assets/images/product_travertine_jewellery_1790183496193.jpg'],
      stock: 20,
      stockStatus: 'in_stock',
      sku: `GB-NK-${Math.floor(100 + Math.random() * 900)}`,
      sizes: ['Standard'],
      tags: ['Waterproof', 'Gold'],
      isFeatured: false,
      isNewArrival: true,
      isBestSeller: false,
      rating: 5.0,
      reviewCount: 0
    });
    setIsProductModalOpen(true);
  };

  const handleOpenEditProduct = (prod: Product) => {
    setEditingProductId(prod.id);
    setProductForm({
      name: prod.name,
      subtitle: prod.subtitle,
      description: prod.description,
      price: prod.price,
      originalPrice: prod.originalPrice,
      category: prod.category,
      collection: prod.collection,
      material: prod.material,
      images: [...prod.images],
      stock: prod.stock,
      stockStatus: prod.stockStatus,
      sku: prod.sku,
      sizes: [...prod.sizes],
      tags: [...prod.tags],
      isFeatured: prod.isFeatured,
      isNewArrival: prod.isNewArrival,
      isBestSeller: prod.isBestSeller,
      rating: prod.rating,
      reviewCount: prod.reviewCount
    });
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name) return;

    const calculatedStockStatus: 'in_stock' | 'low_stock' | 'sold_out' =
      productForm.stock === 0 ? 'sold_out' : productForm.stock <= 5 ? 'low_stock' : 'in_stock';

    const payload = {
      ...productForm,
      stockStatus: calculatedStockStatus
    };

    if (editingProductId) {
      updateProduct(editingProductId, payload);
    } else {
      addProduct(payload);
    }
    setIsProductModalOpen(false);
  };

  // Metrics calculations
  const totalRevenue = orders.reduce((acc, o) => acc + (o.paymentStatus === 'paid' ? o.total : o.total), 0);
  const pendingOrders = orders.filter((o) => o.status === 'Pending' || o.status === 'Processing').length;
  const lowStockCount = products.filter((p) => p.stockStatus === 'low_stock').length;
  const soldOutCount = products.filter((p) => p.stockStatus === 'sold_out').length;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-[#242424]/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-6 animate-in fade-in duration-200">
      <div className="bg-[#FAF8F5] w-full max-w-6xl h-[92vh] border border-[#D8CEC8] shadow-2xl flex flex-col overflow-hidden relative">
        
        {/* Top Header */}
        <div className="bg-[#242424] text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-serif text-xl sm:text-2xl font-medium tracking-wide">
              {settings.businessName}
            </span>
            <span className="px-2 py-0.5 bg-[#383838] text-[#C9A6A0] text-[10px] uppercase tracking-widest font-semibold">
              Owner Management Suite
            </span>
          </div>

          <div className="flex items-center gap-3">
            {isOwnerLoggedIn && (
              <button
                onClick={() => setIsOwnerLoggedIn(false)}
                className="text-xs text-[#FAF8F5]/60 hover:text-white transition-colors"
              >
                Lock Portal
              </button>
            )}
            <button
              onClick={() => setIsDashboardOpen(false)}
              className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* PIN Security Gate if not logged in */}
        {!isOwnerLoggedIn ? (
          <div className="flex-1 flex items-center justify-center p-6 bg-[#F4EFEB]/40">
            <div className="max-w-sm w-full bg-[#FAF8F5] p-8 border border-[#D8CEC8] shadow-lg text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-[#242424] text-[#C9A6A0] mx-auto flex items-center justify-center">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="font-serif text-2xl text-[#242424] font-medium">
                Owner Access
              </h3>
              <p className="text-xs text-[#242424]/70">
                Please enter your private owner PIN to manage products, view incoming orders, and customize your brand settings.
              </p>

              <form onSubmit={handlePinSubmit} className="space-y-4 pt-2">
                <input
                  type="password"
                  maxLength={6}
                  placeholder="Enter 4-digit PIN"
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value)}
                  className="w-full text-center text-xl tracking-widest px-4 py-2.5 bg-white border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                />
                {pinError && <p className="text-xs text-red-600 font-medium">{pinError}</p>}

                <button
                  type="submit"
                  className="w-full py-2.5 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors"
                >
                  Enter Dashboard
                </button>
              </form>

              <div className="pt-2 text-[11px] text-[#242424]/50 border-t border-[#D8CEC8]/40">
                Default Owner Passcode: <span className="font-mono font-semibold text-[#242424]">7860</span>
              </div>
            </div>
          </div>
        ) : (
          /* Main Authenticated Dashboard Layout */
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            
            {/* Left Sidebar Navigation */}
            <aside className="w-full md:w-56 bg-[#F4EFEB] border-b md:border-b-0 md:border-r border-[#D8CEC8] p-3 flex md:flex-col overflow-x-auto md:overflow-y-auto gap-1 text-xs shrink-0">
              <button
                onClick={() => setActiveTab('overview')}
                className={`flex items-center gap-2.5 px-3 py-2.5 text-left font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'overview'
                    ? 'bg-[#242424] text-white'
                    : 'text-[#242424]/80 hover:bg-[#FAF8F5]'
                }`}
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Overview</span>
              </button>

              <button
                onClick={() => setActiveTab('products')}
                className={`flex items-center gap-2.5 px-3 py-2.5 text-left font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'products'
                    ? 'bg-[#242424] text-white'
                    : 'text-[#242424]/80 hover:bg-[#FAF8F5]'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>Products ({products.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('orders')}
                className={`flex items-center gap-2.5 px-3 py-2.5 text-left font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'orders'
                    ? 'bg-[#242424] text-white'
                    : 'text-[#242424]/80 hover:bg-[#FAF8F5]'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Orders ({orders.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('customers')}
                className={`flex items-center gap-2.5 px-3 py-2.5 text-left font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'customers'
                    ? 'bg-[#242424] text-white'
                    : 'text-[#242424]/80 hover:bg-[#FAF8F5]'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Customers</span>
              </button>

              <button
                onClick={() => setActiveTab('reviews')}
                className={`flex items-center gap-2.5 px-3 py-2.5 text-left font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'reviews'
                    ? 'bg-[#242424] text-white'
                    : 'text-[#242424]/80 hover:bg-[#FAF8F5]'
                }`}
              >
                <Star className="w-4 h-4" />
                <span>Reviews ({reviews.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('heroMedia')}
                className={`flex items-center gap-2.5 px-3 py-2.5 text-left font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'heroMedia'
                    ? 'bg-[#242424] text-white'
                    : 'text-[#242424]/80 hover:bg-[#FAF8F5]'
                }`}
              >
                <Film className="w-4 h-4" />
                <span>Hero Media (Video & Photo)</span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`flex items-center gap-2.5 px-3 py-2.5 text-left font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'settings'
                    ? 'bg-[#242424] text-white'
                    : 'text-[#242424]/80 hover:bg-[#FAF8F5]'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Website Profile</span>
              </button>

              <button
                onClick={() => setActiveTab('theme')}
                className={`flex items-center gap-2.5 px-3 py-2.5 text-left font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'theme'
                    ? 'bg-[#242424] text-white'
                    : 'text-[#242424]/80 hover:bg-[#FAF8F5]'
                }`}
              >
                <Palette className="w-4 h-4" />
                <span>Theme Colors</span>
              </button>

              <button
                onClick={() => setActiveTab('policies')}
                className={`flex items-center gap-2.5 px-3 py-2.5 text-left font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === 'policies'
                    ? 'bg-[#242424] text-white'
                    : 'text-[#242424]/80 hover:bg-[#FAF8F5]'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Policies & Shipping</span>
              </button>
            </aside>

            {/* Main Content Area */}
            <main className="flex-1 p-6 overflow-y-auto bg-[#FAF8F5]">
              
              {/* TAB 1: OVERVIEW */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="font-serif text-2xl font-medium text-[#242424]">
                      Business Performance Overview
                    </h2>
                    <p className="text-xs text-[#242424]/60">
                      Real-time store statistics, order fulfillments, and inventory levels.
                    </p>
                  </div>

                  {/* Metric Cards Grid */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="p-5 bg-white border border-[#D8CEC8] shadow-xs">
                      <div className="text-[11px] uppercase tracking-wider text-[#242424]/60 mb-1">
                        Total Revenue
                      </div>
                      <div className="font-serif text-2xl font-bold text-[#242424] tabular-nums">
                        {formatPKR(totalRevenue)}
                      </div>
                      <div className="text-[10px] text-emerald-700 mt-1">
                        Across {orders.length} orders
                      </div>
                    </div>

                    <div className="p-5 bg-white border border-[#D8CEC8] shadow-xs">
                      <div className="text-[11px] uppercase tracking-wider text-[#242424]/60 mb-1">
                        Active Products
                      </div>
                      <div className="font-serif text-2xl font-bold text-[#242424] tabular-nums">
                        {products.length}
                      </div>
                      <div className="text-[10px] text-[#242424]/60 mt-1">
                        In catalog
                      </div>
                    </div>

                    <div className="p-5 bg-white border border-[#D8CEC8] shadow-xs">
                      <div className="text-[11px] uppercase tracking-wider text-[#242424]/60 mb-1">
                        Pending Orders
                      </div>
                      <div className="font-serif text-2xl font-bold text-[#C5A880] tabular-nums">
                        {pendingOrders}
                      </div>
                      <div className="text-[10px] text-[#242424]/60 mt-1">
                        Awaiting dispatch
                      </div>
                    </div>

                    <div className="p-5 bg-white border border-[#D8CEC8] shadow-xs">
                      <div className="text-[11px] uppercase tracking-wider text-[#242424]/60 mb-1">
                        Inventory Alerts
                      </div>
                      <div className="font-serif text-2xl font-bold text-rose-800 tabular-nums">
                        {lowStockCount + soldOutCount}
                      </div>
                      <div className="text-[10px] text-rose-700 mt-1">
                        {lowStockCount} Low · {soldOutCount} Sold out
                      </div>
                    </div>
                  </div>

                  {/* Recent Orders Preview */}
                  <div className="bg-white border border-[#D8CEC8] p-5">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-serif text-lg font-medium text-[#242424]">
                        Recent Orders
                      </h3>
                      <button
                        onClick={() => setActiveTab('orders')}
                        className="text-xs text-[#C9A6A0] font-semibold hover:underline"
                      >
                        View All Orders &rarr;
                      </button>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-[#F4EFEB] text-[#242424]/70 uppercase tracking-wider">
                          <tr>
                            <th className="p-2.5">Order</th>
                            <th className="p-2.5">Customer</th>
                            <th className="p-2.5">City</th>
                            <th className="p-2.5">Items</th>
                            <th className="p-2.5">Total</th>
                            <th className="p-2.5">Payment</th>
                            <th className="p-2.5">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#D8CEC8]/40">
                          {orders.slice(0, 5).map((ord) => (
                            <tr key={ord.id} className="hover:bg-[#FAF8F5]">
                              <td className="p-2.5 font-semibold text-[#242424]">{ord.id}</td>
                              <td className="p-2.5">{ord.customer.name}</td>
                              <td className="p-2.5">{ord.customer.city}</td>
                              <td className="p-2.5">{ord.items.length} items</td>
                              <td className="p-2.5 font-semibold tabular-nums">{formatPKR(ord.total)}</td>
                              <td className="p-2.5 uppercase text-[10px]">{ord.paymentMethod}</td>
                              <td className="p-2.5">
                                <span className={`px-2 py-0.5 text-[10px] uppercase font-semibold ${
                                  ord.status === 'Delivered'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : ord.status === 'Shipped'
                                    ? 'bg-blue-100 text-blue-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}>
                                  {ord.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: PRODUCTS */}
              {activeTab === 'products' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h2 className="font-serif text-2xl font-medium text-[#242424]">
                        Product Management
                      </h2>
                      <p className="text-xs text-[#242424]/60">
                        Add new jewellery silhouettes, adjust PKR prices, and manage stock status.
                      </p>
                    </div>

                    <button
                      onClick={handleOpenAddProduct}
                      className="px-4 py-2.5 bg-[#242424] text-white text-xs uppercase tracking-wider font-semibold hover:bg-black transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Product</span>
                    </button>
                  </div>

                  {/* Products Table */}
                  <div className="bg-white border border-[#D8CEC8] overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#F4EFEB] text-[#242424]/70 uppercase tracking-wider">
                        <tr>
                          <th className="p-3">Product</th>
                          <th className="p-3">Category</th>
                          <th className="p-3">Price</th>
                          <th className="p-3">Stock</th>
                          <th className="p-3">Status</th>
                          <th className="p-3 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#D8CEC8]/40">
                        {products.map((prod) => (
                          <tr key={prod.id} className="hover:bg-[#FAF8F5]">
                            <td className="p-3 flex items-center gap-3">
                              <img
                                src={prod.images[0]}
                                alt=""
                                className="w-10 h-12 object-cover bg-[#F4EFEB] border border-[#D8CEC8]"
                              />
                              <div>
                                <div className="font-semibold text-[#242424]">{prod.name}</div>
                                <div className="text-[10px] text-[#242424]/50">{prod.sku}</div>
                              </div>
                            </td>
                            <td className="p-3">{prod.category}</td>
                            <td className="p-3 font-semibold tabular-nums">{formatPKR(prod.price)}</td>
                            <td className="p-3 tabular-nums">{prod.stock} units</td>
                            <td className="p-3">
                              <span
                                className={`px-2 py-0.5 text-[10px] uppercase font-semibold ${
                                  prod.stockStatus === 'in_stock'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : prod.stockStatus === 'low_stock'
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-rose-100 text-rose-800'
                                }`}
                              >
                                {prod.stockStatus.replace('_', ' ')}
                              </span>
                            </td>
                            <td className="p-3 text-right space-x-1">
                              <button
                                onClick={() => handleOpenEditProduct(prod)}
                                title="Edit Product"
                                className="p-1.5 text-[#242424]/70 hover:text-[#242424] hover:bg-[#D8CEC8]/30 rounded"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => duplicateProduct(prod.id)}
                                title="Duplicate Product"
                                className="p-1.5 text-[#242424]/70 hover:text-[#242424] hover:bg-[#D8CEC8]/30 rounded"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm(`Are you sure you want to delete "${prod.name}"?`)) {
                                    deleteProduct(prod.id);
                                  }
                                }}
                                title="Delete Product"
                                className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 3: ORDERS */}
              {activeTab === 'orders' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="font-serif text-2xl font-medium text-[#242424]">
                      Orders & Deliveries
                    </h2>
                    <p className="text-xs text-[#242424]/60">
                      Manage Cash on Delivery packages, customer addresses, and courier dispatch.
                    </p>
                  </div>

                  <div className="space-y-4">
                    {orders.map((ord) => (
                      <div
                        key={ord.id}
                        className="bg-white border border-[#D8CEC8] p-5 shadow-xs space-y-4"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#D8CEC8]/40 gap-2">
                          <div>
                            <span className="font-serif text-lg font-bold text-[#242424] mr-3">
                              Order {ord.id}
                            </span>
                            <span className="text-xs text-[#242424]/60">
                              Placed on {formatDate(ord.createdAt)}
                            </span>
                          </div>

                          {/* Order Status Select */}
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-[#242424]/70 font-medium">Status:</span>
                            <select
                              value={ord.status}
                              onChange={(e) =>
                                updateOrderStatus(ord.id, e.target.value as Order['status'])
                              }
                              className="px-2.5 py-1 text-xs bg-[#FAF8F5] border border-[#D8CEC8] font-semibold"
                            >
                              <option value="Pending">Pending</option>
                              <option value="Confirmed">Confirmed</option>
                              <option value="Processing">Processing</option>
                              <option value="Shipped">Shipped</option>
                              <option value="Delivered">Delivered</option>
                              <option value="Cancelled">Cancelled</option>
                            </select>
                          </div>
                        </div>

                        {/* Customer & Address Details */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                          <div>
                            <div className="text-[#242424]/60 uppercase tracking-wider text-[10px] mb-1 font-semibold">
                              Customer
                            </div>
                            <div className="font-semibold text-[#242424]">{ord.customer.name}</div>
                            <div>{ord.customer.phone}</div>
                            <div className="text-[#242424]/70">{ord.customer.email}</div>
                            <a
                              href={`https://wa.me/${ord.customer.phone.replace(/[^0-9]/g, '')}?text=Hi%20${encodeURIComponent(
                                ord.customer.name
                              )}%2C%20this%20is%20${encodeURIComponent(
                                settings.businessName
                              )}%20regarding%20your%20order%20${ord.id}.`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[#128C7E] font-semibold mt-1 hover:underline"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span>WhatsApp Customer</span>
                            </a>
                          </div>

                          <div>
                            <div className="text-[#242424]/60 uppercase tracking-wider text-[10px] mb-1 font-semibold">
                              Delivery Address
                            </div>
                            <div>{ord.customer.address}</div>
                            <div className="font-medium text-[#242424]">
                              {ord.customer.city} · {ord.customer.postalCode}
                            </div>
                            {ord.customer.notes && (
                              <div className="text-[#242424]/70 italic mt-1">
                                Note: {ord.customer.notes}
                              </div>
                            )}
                          </div>

                          <div>
                            <div className="text-[#242424]/60 uppercase tracking-wider text-[10px] mb-1 font-semibold">
                              Payment & Total
                            </div>
                            <div className="uppercase font-semibold text-[#242424]">
                              Method: {ord.paymentMethod.replace('_', ' ')}
                            </div>
                            <div className="font-serif text-lg font-bold text-[#242424] tabular-nums mt-0.5">
                              {formatPKR(ord.total)}
                            </div>
                            <div className="mt-1 flex items-center gap-2">
                              <span className="text-[10px] text-[#242424]/60">Payment:</span>
                              <select
                                value={ord.paymentStatus}
                                onChange={(e) =>
                                  updateOrderStatus(
                                    ord.id,
                                    ord.status,
                                    e.target.value as Order['paymentStatus']
                                  )
                                }
                                className="px-1.5 py-0.5 text-[10px] border border-[#D8CEC8]"
                              >
                                <option value="pending">Pending</option>
                                <option value="paid">Paid</option>
                                <option value="verification_required">Needs Verification</option>
                              </select>
                            </div>
                          </div>
                        </div>

                        {/* Order Items List */}
                        <div className="pt-2 border-t border-[#D8CEC8]/40">
                          <div className="text-[10px] uppercase font-semibold text-[#242424]/60 mb-2">
                            Order Items:
                          </div>
                          <div className="flex flex-wrap gap-4">
                            {ord.items.map((it, idx) => (
                              <div
                                key={idx}
                                className="flex items-center gap-2 bg-[#F4EFEB]/50 p-2 border border-[#D8CEC8]/40 text-xs"
                              >
                                <img src={it.image} alt="" className="w-8 h-8 object-cover" />
                                <div>
                                  <span className="font-medium">{it.name}</span>{' '}
                                  <span className="text-[#242424]/60">({it.size})</span> x {it.quantity}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: CUSTOMERS */}
              {activeTab === 'customers' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="font-serif text-2xl font-medium text-[#242424]">
                      Registered Customers
                    </h2>
                    <p className="text-xs text-[#242424]/60">
                      Buyer profiles, order history, and contact numbers.
                    </p>
                  </div>

                  <div className="bg-white border border-[#D8CEC8] overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#F4EFEB] text-[#242424]/70 uppercase tracking-wider">
                        <tr>
                          <th className="p-3">Customer</th>
                          <th className="p-3">City</th>
                          <th className="p-3">Contact</th>
                          <th className="p-3">Total Orders</th>
                          <th className="p-3">Total Spend</th>
                          <th className="p-3">Last Active</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#D8CEC8]/40">
                        {customers.map((c) => (
                          <tr key={c.id} className="hover:bg-[#FAF8F5]">
                            <td className="p-3 font-semibold text-[#242424]">{c.name}</td>
                            <td className="p-3">{c.city}</td>
                            <td className="p-3">
                              <div>{c.phone}</div>
                              <div className="text-[10px] text-[#242424]/60">{c.email}</div>
                            </td>
                            <td className="p-3 tabular-nums">{c.totalOrders}</td>
                            <td className="p-3 font-semibold tabular-nums">{formatPKR(c.totalSpent)}</td>
                            <td className="p-3 text-[#242424]/60">{c.lastOrderDate}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 5: REVIEWS */}
              {activeTab === 'reviews' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="font-serif text-2xl font-medium text-[#242424]">
                      Customer Reviews & Moderation
                    </h2>
                    <p className="text-xs text-[#242424]/60">
                      Approve, edit, or delete customer testimonials.
                    </p>
                  </div>

                  <div className="space-y-3">
                    {reviews.map((rev) => (
                      <div
                        key={rev.id}
                        className="bg-white border border-[#D8CEC8] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-[#242424] text-xs">
                              {rev.author}
                            </span>
                            <span className="text-[11px] text-[#242424]/60">
                              ({rev.location})
                            </span>
                            <span className="text-[#C5A880] text-xs font-semibold">
                              {'★'.repeat(rev.rating)}
                            </span>
                          </div>
                          <div className="font-serif text-sm font-medium text-[#242424]">
                            "{rev.title}"
                          </div>
                          <p className="text-xs text-[#242424]/75 max-w-2xl">{rev.comment}</p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => toggleReviewApproval(rev.id)}
                            className={`px-3 py-1.5 text-xs font-semibold uppercase tracking-wider cursor-pointer ${
                              rev.approved
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {rev.approved ? 'Approved' : 'Hidden'}
                          </button>
                          <button
                            onClick={() => deleteReview(rev.id)}
                            className="p-1.5 text-rose-600 hover:bg-rose-50"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB: HERO MEDIA (VIDEO & PICTURE) */}
              {activeTab === 'heroMedia' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div>
                      <h2 className="font-serif text-2xl font-medium text-[#242424]">
                        Hero Showcase Media (Picture & Video)
                      </h2>
                      <p className="text-xs text-[#242424]/60">
                        Upload custom picture and video displays for the homepage hero card, and craft descriptive words for your video showcase.
                      </p>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        updateSettings(settingsForm);
                        showToast('Hero showcase media and description saved successfully!');
                      }}
                      className="px-5 py-2.5 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors self-start sm:self-auto cursor-pointer flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Save Showcase Media</span>
                    </button>
                  </div>

                  {/* Active Media Preference Selector */}
                  <div className="bg-white border border-[#D8CEC8] p-5 space-y-3">
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#242424]">
                      Default Hero Display Mode
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <button
                        type="button"
                        onClick={() => setSettingsForm({ ...settingsForm, heroMediaType: 'image' })}
                        className={`p-3 text-left border transition-colors cursor-pointer flex items-start gap-3 ${
                          (settingsForm.heroMediaType || 'image') === 'image'
                            ? 'border-[#242424] bg-[#FAF8F5]'
                            : 'border-[#D8CEC8]/70 hover:border-[#242424]'
                        }`}
                      >
                        <ImageIcon className="w-4 h-4 text-[#C9A6A0] mt-0.5 shrink-0" />
                        <div>
                          <p className="font-medium text-[#242424]">Picture Display Mode</p>
                          <p className="text-[11px] text-[#242424]/60">
                            Presents high-resolution luxury editorial photography on the 3D card.
                          </p>
                        </div>
                      </button>

                      <button
                        type="button"
                        onClick={() => setSettingsForm({ ...settingsForm, heroMediaType: 'video' })}
                        className={`p-3 text-left border transition-colors cursor-pointer flex items-start gap-3 ${
                          settingsForm.heroMediaType === 'video'
                            ? 'border-[#242424] bg-[#FAF8F5]'
                            : 'border-[#D8CEC8]/70 hover:border-[#242424]'
                        }`}
                      >
                        <Film className="w-4 h-4 text-[#C9A6A0] mt-0.5 shrink-0" />
                        <div>
                          <p className="font-medium text-[#242424]">Video Reel Display Mode</p>
                          <p className="text-[11px] text-[#242424]/60">
                            Loops an editorial motion video showcase with sound and play controls.
                          </p>
                        </div>
                      </button>
                    </div>
                  </div>

                  {/* Two Column Grid: Picture Upload Section + Video Upload Section */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* SECTION 1: PICTURE UPLOAD */}
                    <div className="bg-white border border-[#D8CEC8] p-5 space-y-4 text-xs">
                      <div className="flex items-center justify-between pb-2 border-b border-[#D8CEC8]/40">
                        <div className="flex items-center gap-2">
                          <ImageIcon className="w-4 h-4 text-[#C9A6A0]" />
                          <h3 className="font-serif text-base font-medium text-[#242424]">
                            Picture Upload Section
                          </h3>
                        </div>
                        <span className="text-[10px] uppercase tracking-wider text-[#C9A6A0] font-semibold">
                          Hero Photo
                        </span>
                      </div>

                      {/* Photo tabs */}
                      <div className="flex border border-[#D8CEC8] p-0.5 bg-[#FAF8F5]">
                        <button
                          type="button"
                          onClick={() => setHeroImageInputMode('upload')}
                          className={`flex-1 py-1.5 text-center font-medium transition-colors cursor-pointer ${
                            heroImageInputMode === 'upload' ? 'bg-[#242424] text-white' : 'text-[#242424]/70 hover:text-[#242424]'
                          }`}
                        >
                          Drag & Drop File
                        </button>
                        <button
                          type="button"
                          onClick={() => setHeroImageInputMode('gallery')}
                          className={`flex-1 py-1.5 text-center font-medium transition-colors cursor-pointer ${
                            heroImageInputMode === 'gallery' ? 'bg-[#242424] text-white' : 'text-[#242424]/70 hover:text-[#242424]'
                          }`}
                        >
                          Gallery Presets
                        </button>
                        <button
                          type="button"
                          onClick={() => setHeroImageInputMode('url')}
                          className={`flex-1 py-1.5 text-center font-medium transition-colors cursor-pointer ${
                            heroImageInputMode === 'url' ? 'bg-[#242424] text-white' : 'text-[#242424]/70 hover:text-[#242424]'
                          }`}
                        >
                          Image Link URL
                        </button>
                      </div>

                      {/* Upload tab */}
                      {heroImageInputMode === 'upload' && (
                        <div
                          onDragOver={(e) => {
                            e.preventDefault();
                            setIsDraggingHeroImage(true);
                          }}
                          onDragLeave={(e) => {
                            e.preventDefault();
                            setIsDraggingHeroImage(false);
                          }}
                          onDrop={(e) => {
                            e.preventDefault();
                            setIsDraggingHeroImage(false);
                            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                              handleHeroImageFile(e.dataTransfer.files[0]);
                            }
                          }}
                          className={`border-2 border-dashed p-6 text-center transition-colors ${
                            isDraggingHeroImage ? 'border-[#242424] bg-[#FAF8F5]' : 'border-[#D8CEC8] hover:border-[#242424]/50'
                          }`}
                        >
                          <input
                            ref={heroImageInputRef}
                            type="file"
                            accept="image/*"
                            onChange={(e) => {
                              if (e.target.files && e.target.files[0]) {
                                handleHeroImageFile(e.target.files[0]);
                              }
                            }}
                            className="hidden"
                          />
                          <UploadCloud className="w-8 h-8 text-[#C9A6A0] mx-auto mb-2" />
                          <p className="font-medium text-[#242424]">Drag and drop image here</p>
                          <p className="text-[11px] text-[#242424]/60 mt-0.5">Supports PNG, JPG, WEBP (high-res portrait recommended)</p>
                          <button
                            type="button"
                            onClick={() => heroImageInputRef.current?.click()}
                            className="mt-3 px-3.5 py-1.5 border border-[#242424] bg-white text-[#242424] font-medium text-[11px] hover:bg-[#242424] hover:text-white transition-colors cursor-pointer"
                          >
                            Browse Device Files
                          </button>
                        </div>
                      )}

                      {/* Gallery tab */}
                      {heroImageInputMode === 'gallery' && (
                        <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                          <p className="text-[11px] text-[#242424]/60">Select an editorial photograph from the brand archive:</p>
                          <div className="grid grid-cols-2 gap-2">
                            {galleryPresets.map((preset) => (
                              <button
                                key={preset.id}
                                type="button"
                                onClick={() => {
                                  setSettingsForm({ ...settingsForm, heroImage: preset.url });
                                  showToast('Selected image from gallery!');
                                }}
                                className={`group p-1.5 border text-left transition-colors flex items-center gap-2 cursor-pointer ${
                                  settingsForm.heroImage === preset.url ? 'border-[#242424] bg-[#FAF8F5]' : 'border-[#D8CEC8]/70 hover:border-[#242424]'
                                }`}
                              >
                                <img
                                  src={preset.url}
                                  alt={preset.title}
                                  className="w-10 h-10 object-cover shrink-0 rounded-xs"
                                />
                                <div className="min-w-0">
                                  <p className="font-medium text-[11px] text-[#242424] truncate group-hover:text-black">
                                    {preset.title}
                                  </p>
                                  <p className="text-[10px] text-[#242424]/50">{preset.category}</p>
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* URL tab */}
                      {heroImageInputMode === 'url' && (
                        <div className="space-y-1.5">
                          <label className="block text-[11px] font-semibold text-[#242424]">Direct Image URL</label>
                          <input
                            type="text"
                            placeholder="https://images.unsplash.com/..."
                            value={settingsForm.heroImage}
                            onChange={(e) => setSettingsForm({ ...settingsForm, heroImage: e.target.value })}
                            className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                          />
                        </div>
                      )}

                      {/* Current Picture Preview */}
                      <div className="pt-2 border-t border-[#D8CEC8]/40 flex items-center gap-3">
                        <img
                          src={settingsForm.heroImage || '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg'}
                          alt="Hero Preview"
                          className="w-14 h-16 object-cover border border-[#D8CEC8] rounded-xs shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-[#242424] text-[11px] truncate">Current Active Picture</p>
                          <p className="text-[10px] text-[#242424]/60 truncate">{settingsForm.heroImage || 'Default editorial photo'}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setHeroImageInputMode('upload')}
                          className="text-[11px] font-semibold text-[#C9A6A0] hover:underline cursor-pointer"
                        >
                          Change
                        </button>
                      </div>
                    </div>

                    {/* SECTION 2: VIDEO UPLOAD */}
                    <div className="bg-white border border-[#D8CEC8] p-5 space-y-4 text-xs">
                      <div className="flex items-center justify-between pb-2 border-b border-[#D8CEC8]/40">
                        <div className="flex items-center gap-2">
                          <Film className="w-4 h-4 text-[#C9A6A0]" />
                          <h3 className="font-serif text-base font-medium text-[#242424]">
                            Video Upload Section
                          </h3>
                        </div>
                        <span className="text-[10px] uppercase tracking-wider text-[#C9A6A0] font-semibold">
                          Hero Video
                        </span>
                      </div>

                      {/* Video tabs */}
                      <div className="flex border border-[#D8CEC8] p-0.5 bg-[#FAF8F5]">
                        <button
                          type="button"
                          onClick={() => setHeroVideoInputMode('upload')}
                          className={`flex-1 py-1.5 text-center font-medium transition-colors cursor-pointer ${
                            heroVideoInputMode === 'upload' ? 'bg-[#242424] text-white' : 'text-[#242424]/70 hover:text-[#242424]'
                          }`}
                        >
                          Drag & Drop Video
                        </button>
                        <button
                          type="button"
                          onClick={() => setHeroVideoInputMode('presets')}
                          className={`flex-1 py-1.5 text-center font-medium transition-colors cursor-pointer ${
                            heroVideoInputMode === 'presets' ? 'bg-[#242424] text-white' : 'text-[#242424]/70 hover:text-[#242424]'
                          }`}
                        >
                          Video Presets
                        </button>
                        <button
                          type="button"
                          onClick={() => setHeroVideoInputMode('url')}
                          className={`flex-1 py-1.5 text-center font-medium transition-colors cursor-pointer ${
                            heroVideoInputMode === 'url' ? 'bg-[#242424] text-white' : 'text-[#242424]/70 hover:text-[#242424]'
                          }`}
                        >
                          Video URL Link
                        </button>
                      </div>

                      {/* Video Upload Dropzone */}
                      {heroVideoInputMode === 'upload' && (
                        <div
                          onDragOver={(e) => {
                            e.preventDefault();
                            setIsDraggingHeroVideo(true);
                          }}
                          onDragLeave={(e) => {
                            e.preventDefault();
                            setIsDraggingHeroVideo(false);
                          }}
                          onDrop={(e) => {
                            e.preventDefault();
                            setIsDraggingHeroVideo(false);
                            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                              handleHeroVideoFile(e.dataTransfer.files[0]);
                            }
                          }}
                          className={`border-2 border-dashed p-6 text-center transition-colors ${
                            isDraggingHeroVideo ? 'border-[#242424] bg-[#FAF8F5]' : 'border-[#D8CEC8] hover:border-[#242424]/50'
                          }`}
                        >
                          <input
                            ref={heroVideoInputRef}
                            type="file"
                            accept="video/*"
                            onChange={(e) => {
                              if (e.target.files && e.target.files[0]) {
                                handleHeroVideoFile(e.target.files[0]);
                              }
                            }}
                            className="hidden"
                          />
                          <Film className="w-8 h-8 text-[#C9A6A0] mx-auto mb-2" />
                          <p className="font-medium text-[#242424]">Drag and drop video clip here</p>
                          <p className="text-[11px] text-[#242424]/60 mt-0.5">Supports MP4, WEBM, MOV (short luxury motion reel)</p>
                          <button
                            type="button"
                            onClick={() => heroVideoInputRef.current?.click()}
                            className="mt-3 px-3.5 py-1.5 border border-[#242424] bg-white text-[#242424] font-medium text-[11px] hover:bg-[#242424] hover:text-white transition-colors cursor-pointer"
                          >
                            Browse Video Files
                          </button>
                        </div>
                      )}

                      {/* Video presets */}
                      {heroVideoInputMode === 'presets' && (
                        <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                          <p className="text-[11px] text-[#242424]/60">Select an editorial jewellery video loop:</p>
                          <div className="space-y-2">
                            {videoPresets.map((vp) => (
                              <button
                                key={vp.id}
                                type="button"
                                onClick={() => {
                                  setSettingsForm({
                                    ...settingsForm,
                                    heroVideoUrl: vp.url,
                                    heroMediaBadge: vp.badge,
                                    heroMediaHeading: vp.heading,
                                    heroVideoDescription: vp.description,
                                    heroMediaType: 'video'
                                  });
                                  showToast(`Loaded ${vp.title}`);
                                }}
                                className={`w-full p-2.5 border text-left transition-colors flex items-center justify-between cursor-pointer ${
                                  settingsForm.heroVideoUrl === vp.url ? 'border-[#242424] bg-[#FAF8F5]' : 'border-[#D8CEC8]/70 hover:border-[#242424]'
                                }`}
                              >
                                <div className="flex items-center gap-2.5">
                                  <div className="w-7 h-7 rounded-full bg-[#242424] text-white flex items-center justify-center shrink-0">
                                    <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                                  </div>
                                  <div>
                                    <p className="font-medium text-[11px] text-[#242424]">{vp.title}</p>
                                    <p className="text-[10px] text-[#242424]/60 line-clamp-1">{vp.description}</p>
                                  </div>
                                </div>
                                <span className="text-[10px] uppercase font-semibold text-[#C9A6A0] shrink-0 ml-2">Select</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Video URL tab */}
                      {heroVideoInputMode === 'url' && (
                        <div className="space-y-1.5">
                          <label className="block text-[11px] font-semibold text-[#242424]">Direct Video URL (.mp4 / .webm)</label>
                          <input
                            type="text"
                            placeholder="https://assets.mixkit.co/videos/...mp4"
                            value={settingsForm.heroVideoUrl || ''}
                            onChange={(e) => setSettingsForm({ ...settingsForm, heroVideoUrl: e.target.value })}
                            className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                          />
                        </div>
                      )}

                      {/* Current Video Preview */}
                      <div className="pt-2 border-t border-[#D8CEC8]/40 flex items-center gap-3">
                        {settingsForm.heroVideoUrl ? (
                          <video
                            src={settingsForm.heroVideoUrl}
                            autoPlay
                            loop
                            muted
                            playsInline
                            onError={(e) => {
                              (e.currentTarget as HTMLElement).style.display = 'none';
                            }}
                            className="w-14 h-16 object-cover border border-[#D8CEC8] rounded-xs shrink-0 bg-black"
                          />
                        ) : (
                          <div className="w-14 h-16 border border-dashed border-[#D8CEC8] flex items-center justify-center text-[#242424]/40 shrink-0">
                            <Film className="w-5 h-5" />
                          </div>
                        )}
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-[#242424] text-[11px] truncate">Current Active Video</p>
                          <p className="text-[10px] text-[#242424]/60 truncate">{settingsForm.heroVideoUrl || 'No video assigned'}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setHeroVideoInputMode('upload')}
                          className="text-[11px] font-semibold text-[#C9A6A0] hover:underline cursor-pointer"
                        >
                          Change
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* SECTION 3: WORDS DESCRIPTION FOR THIS VIDEO & SHOWCASE */}
                  <div className="bg-white border border-[#D8CEC8] p-5 space-y-4 text-xs">
                    <div className="flex items-center gap-2 pb-2 border-b border-[#D8CEC8]/40">
                      <MessageSquare className="w-4 h-4 text-[#C9A6A0]" />
                      <h3 className="font-serif text-base font-medium text-[#242424]">
                        Words Description & Plaque Details for Video
                      </h3>
                    </div>

                    <div className="space-y-4">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="block font-semibold uppercase tracking-wider text-[#242424]">
                            Words Description for this Video & Media Showcase
                          </label>
                          <span className="text-[10px] text-[#242424]/50">Displays directly on the interactive floating card</span>
                        </div>
                        <textarea
                          rows={3}
                          value={settingsForm.heroVideoDescription || ''}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, heroVideoDescription: e.target.value })
                          }
                          placeholder="e.g. Hand-cast in surgical 316L stainless steel with vacuum 18K gold luster — built to stay radiant through every splash."
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                            Media Plaque Badge / Tag
                          </label>
                          <input
                            type="text"
                            value={settingsForm.heroMediaBadge || ''}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, heroMediaBadge: e.target.value })
                            }
                            placeholder="e.g. Signature Finish or Motion Reel"
                            className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                            Media Plaque Title / Heading
                          </label>
                          <input
                            type="text"
                            value={settingsForm.heroMediaHeading || ''}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, heroMediaHeading: e.target.value })
                            }
                            placeholder="e.g. 18K PVD Liquid Gold"
                            className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Live Preview Box */}
                    <div className="pt-3 border-t border-[#D8CEC8]/40">
                      <p className="text-[11px] uppercase tracking-wider font-semibold text-[#C9A6A0] mb-2">
                        Interactive Card Plaque Preview
                      </p>
                      <div className="p-3 bg-[#FAF8F5] border border-[#D8CEC8] flex items-start justify-between gap-3">
                        <div className="space-y-0.5 min-w-0">
                          <p className="text-[10px] uppercase tracking-widest text-[#C9A6A0] font-semibold flex items-center gap-1.5">
                            <Film className="w-3 h-3 text-[#C9A6A0]" />
                            <span>{settingsForm.heroMediaBadge || 'Signature Finish'}</span>
                          </p>
                          <h4 className="font-serif text-base font-medium text-[#242424] leading-tight">
                            {settingsForm.heroMediaHeading || '18K PVD Liquid Gold'}
                          </h4>
                          <p className="text-[11px] text-[#242424]/75 line-clamp-2 pt-0.5">
                            {settingsForm.heroVideoDescription ||
                              'Pure 316L surgical stainless steel infused with 18K vacuum PVD liquid gold plating. Built to stay radiant through every splash.'}
                          </p>
                        </div>
                        <span className="text-xs font-semibold text-[#242424] border-b border-[#242424] pb-0.5 shrink-0 self-center">
                          Explore &rarr;
                        </span>
                      </div>
                    </div>

                    <div className="pt-3 flex justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          updateSettings(settingsForm);
                          showToast('Hero showcase media and description saved successfully!');
                        }}
                        className="px-6 py-2.5 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors cursor-pointer"
                      >
                        Save Hero Showcase Media
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: WEBSITE PROFILE / SETTINGS */}
              {activeTab === 'settings' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="font-serif text-2xl font-medium text-[#242424]">
                      Brand Profile & Contact Settings
                    </h2>
                    <p className="text-xs text-[#242424]/60">
                      Changes here immediately update the website headers, footers, WhatsApp links, and hero banners.
                    </p>
                  </div>

                  <div className="bg-white border border-[#D8CEC8] p-6 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Business Name (Brand Name) *
                        </label>
                        <input
                          type="text"
                          value={settingsForm.businessName}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, businessName: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          WhatsApp Ordering Number *
                        </label>
                        <input
                          type="text"
                          value={settingsForm.whatsappNumber}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Concierge Phone Number
                        </label>
                        <input
                          type="text"
                          value={settingsForm.phone}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, phone: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Concierge Email Address
                        </label>
                        <input
                          type="email"
                          value={settingsForm.email}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, email: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Instagram Username
                        </label>
                        <input
                          type="text"
                          value={settingsForm.instagramUsername}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, instagramUsername: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Instagram URL
                        </label>
                        <input
                          type="text"
                          value={settingsForm.instagramUrl}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, instagramUrl: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Physical Store Address (Lahore / Karachi)
                        </label>
                        <input
                          type="text"
                          value={settingsForm.address}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, address: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Business Operating Hours
                        </label>
                        <input
                          type="text"
                          value={settingsForm.businessHours}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, businessHours: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>
                    </div>

                    <div className="space-y-4 pt-4 border-t border-[#D8CEC8]/40 text-xs">
                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Brand Story & Description
                        </label>
                        <textarea
                          rows={3}
                          value={settingsForm.brandDescription}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, brandDescription: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Homepage Hero Headline
                        </label>
                        <input
                          type="text"
                          value={settingsForm.heroHeading}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, heroHeading: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                          Homepage Hero Subtitle
                        </label>
                        <textarea
                          rows={2}
                          value={settingsForm.heroSubheading}
                          onChange={(e) =>
                            setSettingsForm({ ...settingsForm, heroSubheading: e.target.value })
                          }
                          className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8] focus:outline-hidden focus:border-[#242424]"
                        />
                      </div>

                      {/* Hero Media Showcase (Picture & Video) Studio Link */}
                      <div className="p-4 bg-[#FAF8F5] border border-[#D8CEC8] space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Film className="w-4 h-4 text-[#C9A6A0]" />
                            <span className="font-semibold uppercase tracking-wider text-[#242424]">
                              Hero Showcase Media (Picture & Video Studio)
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setActiveTab('heroMedia')}
                            className="text-xs font-semibold text-[#C9A6A0] hover:underline cursor-pointer flex items-center gap-1"
                          >
                            <span>Open Media Studio</span>
                            <span>&rarr;</span>
                          </button>
                        </div>
                        <p className="text-[11px] text-[#242424]/70">
                          Configure both video upload and picture upload sections, and customize the words description on the 3D card plaque.
                          Currently set to: <strong className="text-[#242424]">{settingsForm.heroMediaType === 'video' ? 'Video Motion Reel' : 'Editorial Picture'}</strong>.
                        </p>
                        <div className="flex flex-wrap items-center gap-3 pt-1">
                          <button
                            type="button"
                            onClick={() => setActiveTab('heroMedia')}
                            className="px-3.5 py-1.5 bg-[#242424] text-white text-[11px] font-medium hover:bg-black transition-colors cursor-pointer flex items-center gap-1.5"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>Edit Picture, Video & Words Description</span>
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                            Free Shipping Threshold (PKR)
                          </label>
                          <input
                            type="number"
                            value={settingsForm.freeShippingThreshold}
                            onChange={(e) =>
                              setSettingsForm({
                                ...settingsForm,
                                freeShippingThreshold: Number(e.target.value)
                              })
                            }
                            className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8]"
                          />
                        </div>

                        <div>
                          <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                            Standard Courier Fee (PKR)
                          </label>
                          <input
                            type="number"
                            value={settingsForm.standardShippingFee}
                            onChange={(e) =>
                              setSettingsForm({
                                ...settingsForm,
                                standardShippingFee: Number(e.target.value)
                              })
                            }
                            className="w-full px-3 py-2 bg-[#FAF8F5] border border-[#D8CEC8]"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 flex justify-between">
                      <button
                        type="button"
                        onClick={resetSettings}
                        className="px-4 py-2 border border-[#D8CEC8] text-xs uppercase tracking-wider font-medium text-[#242424]/70 hover:text-[#242424]"
                      >
                        Reset to Default
                      </button>

                      <button
                        type="button"
                        onClick={() => updateSettings(settingsForm)}
                        className="px-6 py-2 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors"
                      >
                        Save Settings
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 7: THEME COLORS */}
              {activeTab === 'theme' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="font-serif text-2xl font-medium text-[#242424]">
                      Brand Color System
                    </h2>
                    <p className="text-xs text-[#242424]/60">
                      Customize luxury shades: Warm Ivory, Deep Charcoal, Muted Rose, Soft Taupe, Champagne Gold.
                    </p>
                  </div>

                  <div className="bg-white border border-[#D8CEC8] p-6 space-y-4 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <label className="block font-semibold text-[#242424]">
                          Primary Background (Warm Ivory)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={settingsForm.primaryBgColor}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, primaryBgColor: e.target.value })
                            }
                            className="w-10 h-10 border border-[#D8CEC8] cursor-pointer"
                          />
                          <input
                            type="text"
                            value={settingsForm.primaryBgColor}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, primaryBgColor: e.target.value })
                            }
                            className="w-28 px-2 py-1.5 border border-[#D8CEC8] font-mono text-xs uppercase"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="block font-semibold text-[#242424]">
                          Primary Text (Deep Charcoal)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={settingsForm.textColor}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, textColor: e.target.value })
                            }
                            className="w-10 h-10 border border-[#D8CEC8] cursor-pointer"
                          />
                          <input
                            type="text"
                            value={settingsForm.textColor}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, textColor: e.target.value })
                            }
                            className="w-28 px-2 py-1.5 border border-[#D8CEC8] font-mono text-xs uppercase"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="block font-semibold text-[#242424]">
                          Luxury Accent (Muted Rose)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={settingsForm.accentRoseColor}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, accentRoseColor: e.target.value })
                            }
                            className="w-10 h-10 border border-[#D8CEC8] cursor-pointer"
                          />
                          <input
                            type="text"
                            value={settingsForm.accentRoseColor}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, accentRoseColor: e.target.value })
                            }
                            className="w-28 px-2 py-1.5 border border-[#D8CEC8] font-mono text-xs uppercase"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="block font-semibold text-[#242424]">
                          Secondary Neutral (Soft Taupe)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={settingsForm.taupeColor}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, taupeColor: e.target.value })
                            }
                            className="w-10 h-10 border border-[#D8CEC8] cursor-pointer"
                          />
                          <input
                            type="text"
                            value={settingsForm.taupeColor}
                            onChange={(e) =>
                              setSettingsForm({ ...settingsForm, taupeColor: e.target.value })
                            }
                            className="w-28 px-2 py-1.5 border border-[#D8CEC8] font-mono text-xs uppercase"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label className="block font-semibold text-[#242424]">
                          Subtle Accent (Champagne Gold)
                        </label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={settingsForm.champagneGoldColor}
                            onChange={(e) =>
                              setSettingsForm({
                                ...settingsForm,
                                champagneGoldColor: e.target.value
                              })
                            }
                            className="w-10 h-10 border border-[#D8CEC8] cursor-pointer"
                          />
                          <input
                            type="text"
                            value={settingsForm.champagneGoldColor}
                            onChange={(e) =>
                              setSettingsForm({
                                ...settingsForm,
                                champagneGoldColor: e.target.value
                              })
                            }
                            className="w-28 px-2 py-1.5 border border-[#D8CEC8] font-mono text-xs uppercase"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 flex justify-end">
                      <button
                        type="button"
                        onClick={() => updateSettings(settingsForm)}
                        className="px-6 py-2 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors"
                      >
                        Apply Color Theme
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 8: POLICIES */}
              {activeTab === 'policies' && (
                <div className="space-y-6">
                  <div>
                    <h2 className="font-serif text-2xl font-medium text-[#242424]">
                      Store Policies & Customer Information
                    </h2>
                    <p className="text-xs text-[#242424]/60">
                      Edit return windows, courier instructions, and legal policies.
                    </p>
                  </div>

                  <div className="bg-white border border-[#D8CEC8] p-6 space-y-4 text-xs">
                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                        Shipping & Delivery Policy (across Pakistan)
                      </label>
                      <textarea
                        rows={4}
                        value={settingsForm.shippingPolicy}
                        onChange={(e) =>
                          setSettingsForm({ ...settingsForm, shippingPolicy: e.target.value })
                        }
                        className="w-full p-3 bg-[#FAF8F5] border border-[#D8CEC8] font-mono text-xs"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                        7-Day Returns & Exchange Policy
                      </label>
                      <textarea
                        rows={4}
                        value={settingsForm.returnPolicy}
                        onChange={(e) =>
                          setSettingsForm({ ...settingsForm, returnPolicy: e.target.value })
                        }
                        className="w-full p-3 bg-[#FAF8F5] border border-[#D8CEC8] font-mono text-xs"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                        Privacy Policy
                      </label>
                      <textarea
                        rows={3}
                        value={settingsForm.privacyPolicy}
                        onChange={(e) =>
                          setSettingsForm({ ...settingsForm, privacyPolicy: e.target.value })
                        }
                        className="w-full p-3 bg-[#FAF8F5] border border-[#D8CEC8] font-mono text-xs"
                      />
                    </div>

                    <div className="pt-2 flex justify-end">
                      <button
                        type="button"
                        onClick={() => updateSettings(settingsForm)}
                        className="px-6 py-2 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors"
                      >
                        Save Policies
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </main>
          </div>
        )}

      </div>

      {/* Add / Edit Product Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-[#FAF8F5] max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 border border-[#D8CEC8] shadow-2xl relative">
            <button
              onClick={() => setIsProductModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-[#242424]/60 hover:text-[#242424]"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-serif text-2xl text-[#242424] font-medium mb-1">
              {editingProductId ? 'Edit Product' : 'Add New Product'}
            </h3>
            <p className="text-xs text-[#242424]/60 mb-6">
              Fill in product name, pricing in PKR, material specs, and stock quantities.
            </p>

            <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Product Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Aurelia Herringbone Snake Chain"
                    value={productForm.name}
                    onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                  />
                </div>

                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    SKU Code *
                  </label>
                  <input
                    type="text"
                    required
                    value={productForm.sku}
                    onChange={(e) => setProductForm({ ...productForm, sku: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                  Subtitle / Highlight
                </label>
                <input
                  type="text"
                  placeholder="e.g. Liquid Gold Finish · High Polish 316L Stainless Steel"
                  value={productForm.subtitle}
                  onChange={(e) => setProductForm({ ...productForm, subtitle: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Category *
                  </label>
                  <select
                    value={productForm.category}
                    onChange={(e) =>
                      setProductForm({
                        ...productForm,
                        category: e.target.value as Product['category']
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                  >
                    <option value="Necklaces">Necklaces</option>
                    <option value="Rings">Rings</option>
                    <option value="Bracelets & Bangles">Bracelets & Bangles</option>
                    <option value="Earrings">Earrings</option>
                    <option value="Anklets">Anklets</option>
                    <option value="Gift Sets">Gift Sets</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Collection
                  </label>
                  <input
                    type="text"
                    value={productForm.collection}
                    onChange={(e) => setProductForm({ ...productForm, collection: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Price in PKR *
                  </label>
                  <input
                    type="number"
                    required
                    value={productForm.price}
                    onChange={(e) =>
                      setProductForm({ ...productForm, price: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                  />
                </div>

                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Original Price (Optional)
                  </label>
                  <input
                    type="number"
                    value={productForm.originalPrice || ''}
                    onChange={(e) =>
                      setProductForm({
                        ...productForm,
                        originalPrice: e.target.value ? Number(e.target.value) : undefined
                      })
                    }
                    className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                  />
                </div>

                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                    Stock Quantity *
                  </label>
                  <input
                    type="number"
                    required
                    value={productForm.stock}
                    onChange={(e) =>
                      setProductForm({ ...productForm, stock: Number(e.target.value) })
                    }
                    className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                  Material & Plating
                </label>
                <input
                  type="text"
                  value={productForm.material}
                  onChange={(e) => setProductForm({ ...productForm, material: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                />
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#242424] mb-1">
                  Product Description
                </label>
                <textarea
                  rows={3}
                  value={productForm.description}
                  onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#D8CEC8]"
                />
              </div>

              {/* Product Picture Upload & Gallery Section */}
              <div className="space-y-2 border border-[#D8CEC8] p-4 bg-[#FAF8F5]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#D8CEC8]/60">
                  <div>
                    <label className="block font-semibold uppercase tracking-wider text-[#242424]">
                      Product Picture & Gallery
                    </label>
                    <p className="text-[11px] text-[#242424]/60">
                      Drag & drop a photo, choose from gallery, or upload from your device.
                    </p>
                  </div>

                  {/* Mode switcher tabs */}
                  <div className="flex items-center gap-1 bg-white border border-[#D8CEC8] p-0.5 self-start sm:self-auto">
                    <button
                      type="button"
                      onClick={() => setImageInputMode('upload')}
                      className={`px-2.5 py-1 text-[11px] font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                        imageInputMode === 'upload'
                          ? 'bg-[#242424] text-white'
                          : 'text-[#242424]/70 hover:text-[#242424]'
                      }`}
                    >
                      <UploadCloud className="w-3.5 h-3.5" />
                      <span>Drag & Drop</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setImageInputMode('gallery')}
                      className={`px-2.5 py-1 text-[11px] font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                        imageInputMode === 'gallery'
                          ? 'bg-[#242424] text-white'
                          : 'text-[#242424]/70 hover:text-[#242424]'
                      }`}
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                      <span>Gallery</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setImageInputMode('url')}
                      className={`px-2.5 py-1 text-[11px] font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
                        imageInputMode === 'url'
                          ? 'bg-[#242424] text-white'
                          : 'text-[#242424]/70 hover:text-[#242424]'
                      }`}
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>URL</span>
                    </button>
                  </div>
                </div>

                {/* Hidden File Input */}
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/png, image/jpeg, image/webp, image/gif"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleImageFile(e.target.files[0]);
                    }
                  }}
                />

                {/* 1. Drag & Drop Upload Zone */}
                {imageInputMode === 'upload' && (
                  <div className="space-y-3 pt-1">
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDropImage}
                      onClick={() => fileInputRef.current?.click()}
                      className={`border-2 border-dashed p-6 text-center cursor-pointer transition-all duration-200 ${
                        isDraggingImage
                          ? 'border-[#242424] bg-[#F4EFEB] ring-2 ring-[#C9A6A0]/40 scale-[1.01]'
                          : 'border-[#D8CEC8] bg-white hover:border-[#242424] hover:bg-[#FAF8F5]'
                      }`}
                    >
                      <div className="w-12 h-12 rounded-full bg-[#FAF8F5] border border-[#D8CEC8] text-[#C9A6A0] mx-auto flex items-center justify-center mb-3">
                        <UploadCloud className="w-6 h-6 stroke-[1.5]" />
                      </div>
                      <div className="text-xs font-semibold text-[#242424]">
                        {isDraggingImage ? 'Drop your image here' : 'Drag & drop image here, or browse files'}
                      </div>
                      <p className="text-[11px] text-[#242424]/60 mt-1">
                        Supports high-resolution PNG, JPG, or WEBP from your phone or computer
                      </p>

                      <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-[#242424] text-white text-[11px] uppercase tracking-wider font-semibold hover:bg-black transition-colors">
                        <FolderOpen className="w-3.5 h-3.5" />
                        <span>Upload from Gallery / Files</span>
                      </div>
                    </div>

                    {/* Current Preview if set */}
                    {productForm.images[0] && (
                      <div className="flex items-center gap-3 p-2.5 bg-white border border-[#D8CEC8]">
                        <img
                          src={productForm.images[0]}
                          alt="Product preview"
                          className="w-14 h-16 object-cover bg-[#FAF8F5] border border-[#D8CEC8] shrink-0"
                        />
                        <div className="flex-1 min-w-0 text-xs">
                          <div className="font-semibold text-[#242424] truncate">
                            Selected Product Image
                          </div>
                          <div className="text-[11px] text-[#242424]/60 truncate">
                            {productForm.images[0].startsWith('data:') ? 'Custom uploaded image (Ready)' : productForm.images[0]}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="px-2.5 py-1 text-[11px] font-medium border border-[#D8CEC8] hover:bg-[#FAF8F5] text-[#242424]"
                          >
                            Change
                          </button>
                          <button
                            type="button"
                            onClick={() => setProductForm({ ...productForm, images: [''] })}
                            className="px-2.5 py-1 text-[11px] font-medium text-rose-700 hover:bg-rose-50"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 2. Upload from Gallery Selection Tab */}
                {imageInputMode === 'gallery' && (
                  <div className="space-y-3 pt-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-medium text-[#242424]">Select from Atelier Gallery:</span>
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="text-[11px] text-[#C9A6A0] font-semibold hover:underline flex items-center gap-1"
                      >
                        <Plus className="w-3 h-3" />
                        <span>Upload New to Gallery</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2 max-h-52 overflow-y-auto p-1 bg-white border border-[#D8CEC8]">
                      {galleryPresets.map((preset) => {
                        const isSelected = productForm.images[0] === preset.url;
                        return (
                          <button
                            key={preset.id}
                            type="button"
                            onClick={() => {
                              setProductForm((prev) => ({
                                ...prev,
                                images: [preset.url, ...prev.images.slice(1)]
                              }));
                              showToast(`Selected "${preset.title}"`);
                            }}
                            className={`group relative aspect-square border text-left p-0.5 overflow-hidden transition-all cursor-pointer ${
                              isSelected
                                ? 'border-[#242424] ring-2 ring-[#242424]'
                                : 'border-[#D8CEC8] hover:border-[#242424]/60'
                            }`}
                            title={preset.title}
                          >
                            <img
                              src={preset.url}
                              alt={preset.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                            />
                            {isSelected && (
                              <div className="absolute inset-0 bg-[#242424]/40 flex items-center justify-center">
                                <div className="w-5 h-5 rounded-full bg-white text-[#242424] flex items-center justify-center shadow-xs">
                                  <Check className="w-3 h-3 stroke-[2.5]" />
                                </div>
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                    <p className="text-[11px] text-[#242424]/60">
                      Click any photo above to assign it instantly to this jewellery piece.
                    </p>
                  </div>
                )}

                {/* 3. Direct Image URL Input Tab */}
                {imageInputMode === 'url' && (
                  <div className="space-y-2 pt-1">
                    <label className="block font-semibold uppercase tracking-wider text-[#242424] text-[11px]">
                      Direct Image Web Link
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="https://example.com/jewellery-photo.jpg"
                        value={productForm.images[0] || ''}
                        onChange={(e) =>
                          setProductForm({ ...productForm, images: [e.target.value] })
                        }
                        className="flex-1 px-3 py-2 bg-white border border-[#D8CEC8] text-xs focus:outline-hidden focus:border-[#242424]"
                      />
                      {productForm.images[0] && (
                        <button
                          type="button"
                          onClick={() => setProductForm({ ...productForm, images: [''] })}
                          className="px-3 py-2 text-xs border border-[#D8CEC8] text-rose-700 hover:bg-rose-50"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                    {productForm.images[0] && (
                      <div className="mt-2 flex items-center gap-3 p-2 bg-white border border-[#D8CEC8]">
                        <img
                          src={productForm.images[0]}
                          alt="URL preview"
                          className="w-12 h-14 object-cover bg-[#FAF8F5] border border-[#D8CEC8]"
                          onError={(e) => {
                            (e.target as HTMLElement).style.display = 'none';
                          }}
                        />
                        <span className="text-xs text-[#242424]/70">Preview loaded</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Toggles */}
              <div className="flex flex-wrap gap-4 pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={productForm.isFeatured}
                    onChange={(e) =>
                      setProductForm({ ...productForm, isFeatured: e.target.checked })
                    }
                  />
                  <span>Mark as Featured</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={productForm.isNewArrival}
                    onChange={(e) =>
                      setProductForm({ ...productForm, isNewArrival: e.target.checked })
                    }
                  />
                  <span>Mark as New Arrival</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={productForm.isBestSeller}
                    onChange={(e) =>
                      setProductForm({ ...productForm, isBestSeller: e.target.checked })
                    }
                  />
                  <span>Mark as Best Seller</span>
                </label>
              </div>

              <div className="pt-4 flex justify-end gap-3 border-t border-[#D8CEC8]">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 border border-[#D8CEC8] text-xs uppercase tracking-wider"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#242424] text-white text-xs uppercase tracking-wider font-semibold hover:bg-black transition-colors"
                >
                  {editingProductId ? 'Update Product' : 'Add to Catalog'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
