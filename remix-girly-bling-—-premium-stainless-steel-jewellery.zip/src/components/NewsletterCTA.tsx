import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Check } from 'lucide-react';

export const NewsletterCTA: React.FC = () => {
  const { showToast } = useStore();
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setIsSubscribed(true);
    showToast('Welcome to the Girly Bling circle.');
  };

  return (
    <section className="py-20 bg-[#F4EFEB]/40 border-t border-[#D8CEC8]/40">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold mb-2">
          The Private Circle
        </div>
        <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight mb-3">
          Stay In The Know.
        </h2>
        <p className="text-sm sm:text-base text-[#242424]/70 mb-8 max-w-lg mx-auto">
          Discover new capsule drops, private styling edits, and complimentary nationwide promotions.
        </p>

        {isSubscribed ? (
          <div className="inline-flex items-center gap-2 p-4 bg-[#FAF8F5] border border-[#D8CEC8] text-sm text-[#242424]">
            <Check className="w-4 h-4 text-[#C9A6A0]" />
            <span>Thank you for joining. Look forward to our next editorial dispatch.</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
            <input
              type="email"
              required
              placeholder="Your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1 px-4 py-3 bg-[#FAF8F5] border border-[#D8CEC8] text-xs text-[#242424] placeholder:text-[#242424]/40 focus:outline-hidden focus:border-[#242424]"
            />
            <button
              type="submit"
              className="px-8 py-3 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors whitespace-nowrap cursor-pointer"
            >
              Join Us
            </button>
          </form>
        )}

        <div className="mt-4 text-[11px] text-[#242424]/50">
          We honor your privacy. Unsubscribe at any time with a single click.
        </div>
      </div>
    </section>
  );
};
