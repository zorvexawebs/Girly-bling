import React from 'react';
import { useStore } from '../context/StoreContext';
import { X, Trash2, ShoppingBag, ArrowRight, MessageSquare, Heart } from 'lucide-react';
import { formatPKR } from '../utils/formatters';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateCartQuantity,
    cartSubtotal,
    settings,
    setActivePage,
    generateWhatsAppCartUrl,
    toggleWishlist
  } = useStore();

  if (!isCartOpen) return null;

  const freeThreshold = settings.freeShippingThreshold || 3500;
  const amountNeeded = Math.max(0, freeThreshold - cartSubtotal);
  const progressPercent = Math.min(100, (cartSubtotal / freeThreshold) * 100);
  const shippingFee = cartSubtotal >= freeThreshold ? 0 : settings.standardShippingFee;
  const grandTotal = cartSubtotal + (cart.length > 0 ? shippingFee : 0);

  const handleCheckout = () => {
    setIsCartOpen(false);
    setActivePage('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleWhatsAppCheckout = () => {
    const url = generateWhatsAppCartUrl();
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-[#242424]/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={() => setIsCartOpen(false)} />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FAF8F5] border-l border-[#D8CEC8] shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 border-b border-[#D8CEC8]/40 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#242424]" />
              <h2 className="font-serif text-2xl font-medium text-[#242424]">
                Shopping Bag
              </h2>
              <span className="text-xs text-[#242424]/60 tabular-nums">
                ({cart.reduce((a, b) => a + b.quantity, 0)})
              </span>
            </div>

            <button
              onClick={() => setIsCartOpen(false)}
              aria-label="Close bag"
              className="p-1.5 text-[#242424]/60 hover:text-[#242424] hover:bg-[#D8CEC8]/30 rounded-full transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Meter */}
          {cart.length > 0 && (
            <div className="px-6 py-3 bg-[#F4EFEB] border-b border-[#D8CEC8]/40 text-xs text-[#242424]/80">
              {amountNeeded > 0 ? (
                <div>
                  Add <strong className="text-[#242424]">{formatPKR(amountNeeded)}</strong> more to unlock <strong>FREE Delivery</strong> across Pakistan!
                </div>
              ) : (
                <div className="text-emerald-800 font-medium">
                  🎉 Congratulations! You unlocked FREE Nationwide Delivery!
                </div>
              )}
              <div className="w-full bg-[#D8CEC8] h-1.5 mt-2 rounded-full overflow-hidden">
                <div
                  className="bg-[#C9A6A0] h-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
            </div>
          )}

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {cart.length === 0 ? (
              <div className="py-20 text-center space-y-4">
                <ShoppingBag className="w-12 h-12 text-[#D8CEC8] mx-auto stroke-[1.2]" />
                <h3 className="font-serif text-xl text-[#242424] font-medium">
                  Your bag is currently empty.
                </h3>
                <p className="text-xs text-[#242424]/60 max-w-xs mx-auto">
                  Explore our tarnish-free 18K gold plated stainless steel pieces designed for everyday elegance.
                </p>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    setActivePage('shop');
                  }}
                  className="px-6 py-2.5 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors cursor-pointer"
                >
                  Explore Collection
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={item.id}
                  className="flex gap-4 pb-6 border-b border-[#D8CEC8]/30 last:border-b-0"
                >
                  <img
                    src={item.product.images[0] || '/src/assets/images/product_travertine_jewellery_1790183496193.jpg'}
                    alt={item.product.name}
                    className="w-20 h-24 object-cover bg-[#F4EFEB] shrink-0 border border-[#D8CEC8]/40"
                  />

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="font-serif text-sm font-medium text-[#242424] line-clamp-1">
                          {item.product.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          aria-label="Remove item"
                          className="text-[#242424]/40 hover:text-red-700 transition-colors p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="text-[11px] text-[#242424]/60 mt-0.5">
                        Size: {item.selectedSize}
                      </div>

                      <div className="text-xs font-semibold text-[#242424] mt-1 tabular-nums">
                        {formatPKR(item.product.price)}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      {/* Quantity Stepper */}
                      <div className="flex items-center border border-[#D8CEC8] bg-white">
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                          className="w-6 h-6 flex items-center justify-center text-xs hover:bg-[#D8CEC8]/20"
                        >
                          -
                        </button>
                        <span className="w-8 text-center text-xs font-semibold tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                          className="w-6 h-6 flex items-center justify-center text-xs hover:bg-[#D8CEC8]/20"
                        >
                          +
                        </button>
                      </div>

                      {/* Save to Wishlist */}
                      <button
                        onClick={() => {
                          toggleWishlist(item.product.id);
                        }}
                        className="text-[11px] text-[#242424]/60 hover:text-[#C9A6A0] flex items-center gap-1 cursor-pointer"
                      >
                        <Heart className="w-3.5 h-3.5" />
                        <span>Save</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Actions */}
          {cart.length > 0 && (
            <div className="p-6 bg-[#F4EFEB]/50 border-t border-[#D8CEC8] space-y-4">
              <div className="space-y-1.5 text-xs text-[#242424]/80">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-[#242424] tabular-nums">
                    {formatPKR(cartSubtotal)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Delivery</span>
                  <span>
                    {shippingFee === 0 ? (
                      <span className="text-emerald-800 font-medium">FREE</span>
                    ) : (
                      formatPKR(shippingFee)
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-bold text-[#242424] pt-2 border-t border-[#D8CEC8]/40">
                  <span>Total</span>
                  <span className="tabular-nums">{formatPKR(grandTotal)}</span>
                </div>
              </div>

              <div className="space-y-2 pt-2">
                <button
                  onClick={handleCheckout}
                  className="w-full py-3.5 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={handleWhatsAppCheckout}
                  className="w-full py-2.5 bg-[#25D366]/10 border border-[#25D366]/40 text-[#128C7E] text-xs uppercase tracking-wider font-semibold hover:bg-[#25D366]/20 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Order Entire Bag on WhatsApp</span>
                </button>
              </div>

              <div className="text-center">
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="text-xs text-[#242424]/60 hover:text-[#242424] underline cursor-pointer"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
