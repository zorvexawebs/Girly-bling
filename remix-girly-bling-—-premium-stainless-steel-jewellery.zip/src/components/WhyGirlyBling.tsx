import React from 'react';
import { ShieldCheck, Droplets, Sparkles, Package, Truck, MessageSquare } from 'lucide-react';

export const WhyGirlyBling: React.FC = () => {
  const pillars = [
    {
      icon: ShieldCheck,
      title: '316L Surgical Steel',
      desc: 'Precision crafted from high-grade hypoallergenic stainless steel. Zero nickel, zero discoloration, 100% skin-friendly.'
    },
    {
      icon: Droplets,
      title: '100% Waterproof',
      desc: 'Wear in the shower, at the gym, or in coastal humidity. Advanced 18K PVD vacuum plating will never turn green.'
    },
    {
      icon: Sparkles,
      title: 'Curated Fine Silhouettes',
      desc: 'Every piece is handpicked to bridge timeless Parisian vintage aesthetics with effortless contemporary minimalism.'
    },
    {
      icon: Package,
      title: 'Signature Velvet Box',
      desc: 'Each order arrives in a custom blush rose velvet jewellery box with gold embossing, ready for gifting or storage.'
    },
    {
      icon: Truck,
      title: 'Nationwide COD',
      desc: 'Reliable Cash on Delivery via tracked couriers to Lahore, Karachi, Islamabad, and every city and town in Pakistan.'
    },
    {
      icon: MessageSquare,
      title: 'WhatsApp Concierge',
      desc: 'Friendly, personalized customer assistance for ring sizing, styling recommendations, and quick order tracking.'
    }
  ];

  return (
    <section className="py-20 sm:py-24 bg-[#F4EFEB]/60 border-t border-[#D8CEC8]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="text-xs uppercase tracking-widest text-[#A57E78] font-semibold mb-2">
            The Difference
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
            Why Modern Women Choose Girly Bling
          </h2>
          <p className="mt-3 text-sm sm:text-base text-[#242424]/70">
            A standard of craftsmanship designed for longevity, comfort, and uncompromising everyday elegance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 sm:gap-10">
          {pillars.map((pillar, idx) => {
            const IconComponent = pillar.icon;
            return (
              <div
                key={idx}
                className="bg-[#FAF8F5] p-6 border border-[#D8CEC8]/50 hover:border-[#C9A6A0]/60 transition-all duration-300"
              >
                <div className="w-10 h-10 rounded-full bg-[#F4EFEB] flex items-center justify-center text-[#A57E78] mb-4">
                  <IconComponent className="w-5 h-5 stroke-[1.5]" />
                </div>
                <h3 className="font-serif text-lg font-medium text-[#242424] mb-2">
                  {pillar.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#242424]/75 leading-relaxed">
                  {pillar.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
