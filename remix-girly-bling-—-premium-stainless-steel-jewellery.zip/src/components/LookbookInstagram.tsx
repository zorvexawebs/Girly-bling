import React from 'react';
import { useStore } from '../context/StoreContext';
import { Instagram, ArrowUpRight } from 'lucide-react';

export const LookbookInstagram: React.FC = () => {
  const { settings, openProductDetail } = useStore();

  const galleryItems = [
    {
      img: '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg',
      caption: 'The Golden Hour Layer: Aurelia Herringbone & Medallion Choker',
      productId: 'gb-001'
    },
    {
      img: '/src/assets/images/lookbook_lifestyle_portrait_1790183522124.jpg',
      caption: 'Roman Cable Bangle stacked with Parisian Croissant Ring',
      productId: 'gb-003'
    },
    {
      img: '/src/assets/images/product_travertine_jewellery_1790183496193.jpg',
      caption: 'Still life on organic travertine. 18K PVD waterproof craftsmanship',
      productId: 'gb-002'
    },
    {
      img: '/src/assets/images/brand_craftsmanship_story_1790183510549.jpg',
      caption: 'Hand-packed in signature blush rose velvet. Made for gifting',
      productId: 'gb-005'
    }
  ];

  return (
    <section className="py-20 sm:py-24 bg-[#FAF8F5] border-t border-[#D8CEC8]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header with Instagram CTA */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 pb-4 border-b border-[#D8CEC8]/40 gap-4">
          <div>
            <div className="flex items-center gap-1.5 text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold mb-2">
              <Instagram className="w-3.5 h-3.5" />
              <span>As Seen On You</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
              The Girly Bling Lookbook
            </h2>
          </div>

          <a
            href={settings.instagramUrl || 'https://instagram.com/girlybling.pk'}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#242424] hover:text-[#C9A6A0] transition-colors self-start sm:self-auto"
          >
            <span>Follow {settings.instagramUsername || '@girlybling.pk'}</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          {galleryItems.map((item, idx) => (
            <div
              key={idx}
              onClick={() => openProductDetail(item.productId)}
              className="group relative aspect-[3/4] overflow-hidden bg-[#F4EFEB] cursor-pointer border border-[#D8CEC8]/40 hover:border-[#C9A6A0]"
            >
              <img
                src={item.img}
                alt={item.caption}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transform transition-transform duration-700 ease-out group-hover:scale-105"
                onError={(e) => {
                  e.currentTarget.src = '/src/assets/images/product_travertine_jewellery_1790183496193.jpg';
                }}
              />

              {/* Hover overlay with caption & shop tag */}
              <div className="absolute inset-0 bg-[#242424]/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-4 flex flex-col justify-end text-white">
                <span className="text-[10px] uppercase tracking-widest text-[#C9A6A0] font-semibold mb-1">
                  Tap to Shop
                </span>
                <p className="text-xs font-serif leading-snug line-clamp-2">
                  {item.caption}
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
