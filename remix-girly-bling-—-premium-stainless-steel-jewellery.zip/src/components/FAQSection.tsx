import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { ChevronDown } from 'lucide-react';

export const FAQSection: React.FC = () => {
  const { settings } = useStore();
  const faqs = settings.faqs || [];
  const [openId, setOpenId] = useState<string | null>(faqs[0]?.id || null);

  const toggle = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  const cleanWhatsAppNumber = (settings.whatsappNumber || '+923218492001').replace(/[^0-9]/g, '');

  return (
    <section className="py-20 sm:py-24 bg-[#FAF8F5] border-t border-[#D8CEC8]/40">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-12">
          <div className="text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold mb-2">
            Questions & Answers
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
            Frequently Asked Questions
          </h2>
          <p className="mt-3 text-sm text-[#242424]/70">
            Everything you need to know about our waterproof stainless steel craftsmanship, sizing, and delivery.
          </p>
        </div>

        <div className="divide-y divide-[#D8CEC8]/60 border-t border-b border-[#D8CEC8]/60">
          {faqs.map((faq) => {
            const isOpen = openId === faq.id;
            return (
              <div key={faq.id} className="py-5">
                <button
                  onClick={() => toggle(faq.id)}
                  className="w-full flex items-center justify-between text-left group cursor-pointer"
                  aria-expanded={isOpen}
                >
                  <span className="font-serif text-lg sm:text-xl text-[#242424] font-medium group-hover:text-[#C9A6A0] transition-colors pr-4">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#242424]/60 transform transition-transform duration-200 shrink-0 ${
                      isOpen ? 'rotate-180 text-[#C9A6A0]' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="mt-3 text-sm text-[#242424]/80 leading-relaxed pr-6 animate-in fade-in duration-200">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-8 text-center text-xs text-[#242424]/70">
          Have a different question?{' '}
          <a
            href={`https://wa.me/${cleanWhatsAppNumber}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#C9A6A0] font-semibold underline hover:text-[#242424]"
          >
            Chat directly with our team on WhatsApp
          </a>
        </div>

      </div>
    </section>
  );
};
