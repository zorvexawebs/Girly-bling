import React from 'react';
import { useStore } from '../context/StoreContext';
import { ArrowRight, Sparkles } from 'lucide-react';

export const BrandStory: React.FC = () => {
  const { settings, setActivePage } = useStore();

  return (
    <section className="py-20 sm:py-28 bg-[#FAF8F5] border-t border-[#D8CEC8]/40 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Editorial Image with Subtle Frame */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#F4EFEB] shadow-xl">
              <img
                src="/src/assets/images/brand_craftsmanship_story_1790183510549.jpg"
                alt="Girly Bling Craftsmanship and Luxury Packaging"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-700"
                onError={(e) => {
                  e.currentTarget.src = '/src/assets/images/product_travertine_jewellery_1790183496193.jpg';
                }}
              />
            </div>
            
            {/* Editorial Floating Inset */}
            <div className="absolute -bottom-6 -right-4 sm:-right-8 bg-[#FAF8F5] p-5 border border-[#D8CEC8] shadow-lg max-w-[240px] hidden sm:block">
              <div className="text-[11px] uppercase tracking-widest text-[#C9A6A0] font-semibold mb-1">
                Zero Compromise
              </div>
              <p className="text-xs text-[#242424]/80 leading-relaxed font-serif italic text-base">
                “Jewellery made for real living — from daily chai runs to grand weddings.”
              </p>
            </div>
          </div>

          {/* Editorial Narrative */}
          <div className="lg:col-span-6 space-y-6 lg:pl-6">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>The Girly Bling Philosophy</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-[#242424] font-normal leading-[1.15] tracking-tight">
              Designed To Be Remembered.
            </h2>

            <div className="space-y-4 text-sm sm:text-base text-[#242424]/80 leading-relaxed font-normal">
              <p>
                {settings.brandDescription ||
                  'Girly Bling was founded with a singular conviction: luxury jewellery should not fade after three wears, turn your skin green, or be locked away in a safe.'}
              </p>
              <p>
                We forge every single silhouette in medical-grade 316L stainless steel, bonded with 18K gold through state-of-the-art PVD vacuum vapor deposition. The result is a piece that withstands Pakistan’s summer humidity, daily hand washing, perfumes, and life’s warmest celebrations.
              </p>
            </div>

            {/* Proof Points */}
            <div className="grid grid-cols-2 gap-6 pt-4 border-t border-[#D8CEC8]/40">
              <div>
                <div className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium tabular-nums">
                  100%
                </div>
                <div className="text-xs text-[#242424]/70 mt-1 uppercase tracking-wider">
                  Waterproof & Anti-Tarnish
                </div>
              </div>
              <div>
                <div className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium tabular-nums">
                  316L
                </div>
                <div className="text-xs text-[#242424]/70 mt-1 uppercase tracking-wider">
                  Surgical Grade Steel
                </div>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  setActivePage('about');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#242424] border-b border-[#242424] pb-1 hover:text-[#C9A6A0] hover:border-[#C9A6A0] transition-colors cursor-pointer"
              >
                <span>Read Full Brand Manifesto</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
