import React, { useState } from 'react';
import { X, HelpCircle, Ruler, Sparkles } from 'lucide-react';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'rings' | 'necklaces' | 'bracelets'>('rings');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242424]/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="bg-[#FAF8F5] max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-[#D8CEC8] shadow-2xl relative p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close size guide"
          className="absolute top-4 right-4 p-2 text-[#242424]/60 hover:text-[#242424] bg-[#FAF8F5]/80 rounded-full"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#A57E78] font-semibold mb-1">
          <Ruler className="w-4 h-4" />
          <span>Measurement Guide</span>
        </div>

        <h2 className="font-serif text-2xl sm:text-3xl text-[#242424] font-medium mb-3">
          Jewellery Sizing Guide
        </h2>
        <p className="text-xs sm:text-sm text-[#242424]/75 mb-6">
          Find your exact fit for comfortable everyday wear. All measurements are calibrated to standard Pakistani and international specifications.
        </p>

        {/* Tab switchers */}
        <div className="flex border-b border-[#D8CEC8] mb-6">
          <button
            onClick={() => setActiveTab('rings')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
              activeTab === 'rings'
                ? 'border-b-2 border-[#242424] text-[#242424]'
                : 'text-[#242424]/50 hover:text-[#242424]'
            }`}
          >
            Rings Sizing
          </button>
          <button
            onClick={() => setActiveTab('necklaces')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
              activeTab === 'necklaces'
                ? 'border-b-2 border-[#242424] text-[#242424]'
                : 'text-[#242424]/50 hover:text-[#242424]'
            }`}
          >
            Necklaces & Chains
          </button>
          <button
            onClick={() => setActiveTab('bracelets')}
            className={`pb-2.5 px-4 text-xs font-semibold uppercase tracking-wider transition-colors cursor-pointer ${
              activeTab === 'bracelets'
                ? 'border-b-2 border-[#242424] text-[#242424]'
                : 'text-[#242424]/50 hover:text-[#242424]'
            }`}
          >
            Bracelets & Bangles
          </button>
        </div>

        {/* Tab 1: Rings */}
        {activeTab === 'rings' && (
          <div className="space-y-6">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border border-[#D8CEC8]">
                <thead className="bg-[#F4EFEB] text-[#242424] uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3 border-b border-[#D8CEC8]">Pakistani Size</th>
                    <th className="p-3 border-b border-[#D8CEC8]">US Size</th>
                    <th className="p-3 border-b border-[#D8CEC8]">Inner Diameter</th>
                    <th className="p-3 border-b border-[#D8CEC8]">Circumference</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D8CEC8]/60 text-[#242424]/80 tabular-nums">
                  <tr className="hover:bg-[#F4EFEB]/30">
                    <td className="p-3 font-semibold text-[#242424]">12 - 13</td>
                    <td className="p-3">US 6</td>
                    <td className="p-3">16.5 mm</td>
                    <td className="p-3">51.8 mm</td>
                  </tr>
                  <tr className="hover:bg-[#F4EFEB]/30 bg-[#FAF8F5]">
                    <td className="p-3 font-semibold text-[#242424]">14 - 15</td>
                    <td className="p-3">US 7 (Most Popular)</td>
                    <td className="p-3">17.3 mm</td>
                    <td className="p-3">54.4 mm</td>
                  </tr>
                  <tr className="hover:bg-[#F4EFEB]/30">
                    <td className="p-3 font-semibold text-[#242424]">16 - 17</td>
                    <td className="p-3">US 8</td>
                    <td className="p-3">18.1 mm</td>
                    <td className="p-3">56.9 mm</td>
                  </tr>
                  <tr className="hover:bg-[#F4EFEB]/30 bg-[#FAF8F5]">
                    <td className="p-3 font-semibold text-[#242424]">18 - 19</td>
                    <td className="p-3">US 9</td>
                    <td className="p-3">18.9 mm</td>
                    <td className="p-3">59.5 mm</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="p-4 bg-[#F4EFEB]/60 border border-[#D8CEC8]/50 text-xs text-[#242424]/80 space-y-2">
              <div className="font-semibold text-[#242424] flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-[#A57E78]" />
                <span>How to measure your finger at home:</span>
              </div>
              <ol className="list-decimal pl-4 space-y-1">
                <li>Wrap a thin strip of paper or non-stretchy string around the base of the finger.</li>
                <li>Mark the point where the ends meet with a pen.</li>
                <li>Lay the strip flat against a ruler to measure millimeters (Circumference).</li>
              </ol>
            </div>
          </div>
        )}

        {/* Tab 2: Necklaces */}
        {activeTab === 'necklaces' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-[#F4EFEB]/60 border border-[#D8CEC8]">
                <h4 className="font-serif text-base font-semibold text-[#242424] mb-1">
                  Choker / 38cm - 40cm
                </h4>
                <p className="text-[#242424]/75">
                  Rests tightly around the base of the neck. Ideal for open collar shirts and boatneck blouses.
                </p>
              </div>
              <div className="p-4 bg-[#F4EFEB]/60 border border-[#D8CEC8]">
                <h4 className="font-serif text-base font-semibold text-[#242424] mb-1">
                  Princess / 45cm (Most Common)
                </h4>
                <p className="text-[#242424]/75">
                  Gracefully settles on the collarbone. Perfect length for pendants, everyday chains, and layering.
                </p>
              </div>
              <div className="p-4 bg-[#F4EFEB]/60 border border-[#D8CEC8]">
                <h4 className="font-serif text-base font-semibold text-[#242424] mb-1">
                  Matinee / 50cm
                </h4>
                <p className="text-[#242424]/75">
                  Falls below the collarbone near the upper chest. Exceptional for medallions and winter knits.
                </p>
              </div>
              <div className="p-4 bg-[#F4EFEB]/60 border border-[#D8CEC8]">
                <h4 className="font-serif text-base font-semibold text-[#242424] mb-1">
                  5cm Extender Included
                </h4>
                <p className="text-[#242424]/75">
                  Almost all Girly Bling necklaces include a complimentary 5cm extender link for customized drops.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Bracelets */}
        {activeTab === 'bracelets' && (
          <div className="space-y-4 text-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left border border-[#D8CEC8]">
                <thead className="bg-[#F4EFEB] text-[#242424] uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3 border-b border-[#D8CEC8]">Size</th>
                    <th className="p-3 border-b border-[#D8CEC8]">Wrist Measurement</th>
                    <th className="p-3 border-b border-[#D8CEC8]">Recommended Fit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D8CEC8]/60 text-[#242424]/80">
                  <tr>
                    <td className="p-3 font-semibold text-[#242424]">Small</td>
                    <td className="p-3">14.0 cm – 16.0 cm</td>
                    <td className="p-3">Snug / Petite wrists</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold text-[#242424]">Medium (Standard)</td>
                    <td className="p-3">16.5 cm – 18.0 cm</td>
                    <td className="p-3">Comfort fit for 85% of women</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold text-[#242424]">Adjustable Cuff</td>
                    <td className="p-3">Free Size (15cm - 19cm)</td>
                    <td className="p-3">Flexible open cuff design</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Bottom Helper */}
        <div className="mt-8 pt-4 border-t border-[#D8CEC8] flex items-center justify-between text-xs text-[#242424]/70">
          <span>Still unsure about your size?</span>
          <button
            onClick={() => {
              onClose();
              window.open('https://wa.me/923218492001?text=Hi%20Girly%20Bling%2C%20I%20need%20help%20choosing%20my%20ring%2Fjewellery%20size.', '_blank');
            }}
            className="text-[#A57E78] font-semibold underline hover:text-[#242424] cursor-pointer"
          >
            Ask on WhatsApp
          </button>
        </div>

      </div>
    </div>
  );
};
