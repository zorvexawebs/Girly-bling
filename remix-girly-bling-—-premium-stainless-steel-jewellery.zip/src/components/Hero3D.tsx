import React, { useState, useRef, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { Sparkles, ArrowRight, Droplets, Film, Volume2, VolumeX, Edit2 } from 'lucide-react';

export const Hero3D: React.FC = () => {
  const { settings, setActivePage, isOwnerLoggedIn, setIsDashboardOpen } = useStore();
  const cardRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  // 3D Tilt calculation
  const [tilt, setTilt] = useState({ x: 0, y: 0, lightX: 50, lightY: 50 });
  const [isHovering, setIsHovering] = useState(false);

  // Active media mode: photo or video
  const [mediaMode, setMediaMode] = useState<'image' | 'video'>(
    settings.heroMediaType === 'video' ? 'video' : 'image'
  );
  const [isMuted, setIsMuted] = useState(true);

  // Keep in sync with owner setting updates
  useEffect(() => {
    if (settings.heroMediaType) {
      setMediaMode(settings.heroMediaType);
    }
  }, [settings.heroMediaType]);

  // Safe video playback handling to prevent uncaught NotAllowedError
  useEffect(() => {
    if (mediaMode === 'video' && videoRef.current) {
      videoRef.current.muted = isMuted;
      const playPromise = videoRef.current.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {
          if (videoRef.current) {
            videoRef.current.muted = true;
            setIsMuted(true);
            videoRef.current.play().catch(() => {
              // Suppress browser autoplay refusal
            });
          }
        });
      }
    }
  }, [mediaMode, isMuted, settings.heroVideoUrl]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    // Normalize -1 to 1
    const xNorm = (x / rect.width - 0.5) * 2;
    const yNorm = (y / rect.height - 0.5) * 2;
    
    // Subtle rotation: max 7 degrees
    setTilt({
      x: -yNorm * 6,
      y: xNorm * 6,
      lightX: (x / rect.width) * 100,
      lightY: (y / rect.height) * 100
    });
  };

  const handleMouseLeave = () => {
    setIsHovering(false);
    setTilt({ x: 0, y: 0, lightX: 50, lightY: 50 });
  };

  const handleCardClick = () => {
    setActivePage('shop');
  };

  return (
    <section className="relative overflow-hidden bg-[#FAF8F5] pt-8 pb-16 lg:pt-16 lg:pb-24 border-b border-[#D8CEC8]/30">
      {/* Subtle warm ambient background gradient */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-gradient-to-tr from-[#C9A6A0]/15 via-[#C5A880]/10 to-transparent blur-3xl pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Editorial Text Content (Left, 6 or 7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-6 lg:pr-8">
            {/* Subtle editorial kicker */}
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{settings.heroBadge || 'Effortless Modern Luxury'}</span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-[#242424] leading-[1.1] tracking-tight font-normal text-balance">
              {settings.heroHeading || 'Jewellery That Completes Your Story.'}
            </h1>

            {/* Subheading */}
            <p className="text-base sm:text-lg text-[#242424]/75 font-normal max-w-xl leading-relaxed text-pretty">
              {settings.heroSubheading ||
                'Timeless stainless-steel pieces designed to add effortless elegance to every look. Waterproof, anti-tarnish, and gentle on sensitive skin.'}
            </p>

            {/* CTAs */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={() => {
                  setActivePage('shop');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-8 py-3.5 bg-[#242424] text-white text-xs sm:text-sm uppercase tracking-widest font-semibold rounded-none hover:bg-black transition-all transform active:scale-95 flex items-center gap-2 cursor-pointer shadow-sm"
              >
                <span>Shop Collection</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  const newArrivalsEl = document.getElementById('new-arrivals');
                  if (newArrivalsEl) {
                    newArrivalsEl.scrollIntoView({ behavior: 'smooth' });
                  } else {
                    setActivePage('shop');
                  }
                }}
                className="px-8 py-3.5 border border-[#242424]/30 text-[#242424] text-xs sm:text-sm uppercase tracking-widest font-semibold hover:border-[#242424] hover:bg-[#242424]/5 transition-all cursor-pointer"
              >
                Explore New Arrivals
              </button>
            </div>

            {/* Unboxed trust markers with typographic separators */}
            <div className="pt-6 border-t border-[#D8CEC8]/40 flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-[#242424]/70">
              <div className="flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-[#C9A6A0]" />
                <span className="font-medium">100% Waterproof & Non-Tarnish</span>
              </div>
              <span aria-hidden="true" className="text-[#D8CEC8]">·</span>
              <div className="flex items-center gap-1.5">
                <span className="font-medium">Cash on Delivery Across Pakistan</span>
              </div>
            </div>
          </div>

          {/* 3D-Inspired Visual Presentation (Right, 5 cols) */}
          <div className="lg:col-span-5 flex justify-center">
            <div
              ref={cardRef}
              onMouseEnter={() => setIsHovering(true)}
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              className="relative w-full max-w-[440px] aspect-[4/5] cursor-pointer group"
              style={{
                perspective: '1200px'
              }}
            >
              {/* 3D Transform Container */}
              <div
                onClick={handleCardClick}
                className="w-full h-full relative transition-transform duration-200 ease-out will-change-transform rounded-sm overflow-hidden"
                style={{
                  transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg) translateZ(10px)`,
                  boxShadow: isHovering
                    ? '0 25px 50px -12px rgba(36, 36, 36, 0.22), 0 0 30px rgba(197, 168, 128, 0.15)'
                    : '0 20px 35px -10px rgba(36, 36, 36, 0.14)'
                }}
              >
                {/* Media Element: Picture or Video with identical styling */}
                {mediaMode === 'video' && settings.heroVideoUrl ? (
                  <video
                    ref={videoRef}
                    key={settings.heroVideoUrl}
                    src={settings.heroVideoUrl}
                    autoPlay
                    loop
                    muted={isMuted}
                    playsInline
                    onError={() => {
                      // Gracefully switch to image if video source cannot be loaded
                      setMediaMode('image');
                    }}
                    className="w-full h-full object-cover object-center scale-[1.03] transition-transform duration-700 group-hover:scale-105"
                  />
                ) : (
                  <img
                    src={settings.heroImage || '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg'}
                    alt={settings.heroMediaHeading || 'Girly Bling Luxury Stainless Steel Jewellery Campaign'}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center scale-[1.03] transition-transform duration-700 group-hover:scale-105"
                    onError={(e) => {
                      e.currentTarget.src = '/src/assets/images/product_travertine_jewellery_1790183496193.jpg';
                    }}
                  />
                )}

                {/* Top media mode controls & owner quick edit */}
                <div
                  className="absolute top-4 right-4 z-20 flex items-center gap-2 pointer-events-auto"
                  onClick={(e) => e.stopPropagation()}
                >
                  {/* Photo / Video Switcher */}
                  <div className="flex items-center bg-[#FAF8F5]/90 backdrop-blur-md border border-[#D8CEC8]/80 px-2.5 py-1 text-[10px] uppercase tracking-wider text-[#242424] shadow-xs">
                    <button
                      type="button"
                      onClick={() => setMediaMode('image')}
                      className={`transition-colors cursor-pointer ${
                        mediaMode === 'image'
                          ? 'font-bold text-[#242424] border-b border-[#242424]'
                          : 'text-[#242424]/60 hover:text-[#242424]'
                      }`}
                    >
                      Photo
                    </button>
                    <span aria-hidden="true" className="text-[#D8CEC8] px-1.5">·</span>
                    <button
                      type="button"
                      onClick={() => setMediaMode('video')}
                      className={`transition-colors cursor-pointer flex items-center gap-1 ${
                        mediaMode === 'video'
                          ? 'font-bold text-[#242424] border-b border-[#242424]'
                          : 'text-[#242424]/60 hover:text-[#242424]'
                      }`}
                    >
                      <Film className="w-2.5 h-2.5" />
                      <span>Video</span>
                    </button>

                    {mediaMode === 'video' && (
                      <>
                        <span aria-hidden="true" className="text-[#D8CEC8] px-1.5">·</span>
                        <button
                          type="button"
                          onClick={() => setIsMuted(!isMuted)}
                          title={isMuted ? 'Unmute video sound' : 'Mute video sound'}
                          className="text-[#242424]/70 hover:text-[#242424] cursor-pointer"
                        >
                          {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                        </button>
                      </>
                    )}
                  </div>

                  {/* Owner Portal quick edit button */}
                  {isOwnerLoggedIn && (
                    <button
                      type="button"
                      onClick={() => setIsDashboardOpen(true)}
                      title="Open Owner Media Manager"
                      className="p-1.5 bg-[#242424] text-white hover:bg-black text-[10px] transition-colors flex items-center gap-1 shadow-xs cursor-pointer"
                    >
                      <Edit2 className="w-3 h-3" />
                      <span className="hidden sm:inline uppercase tracking-widest text-[9px] font-semibold">
                        Edit Media
                      </span>
                    </button>
                  )}
                </div>

                {/* Subtle Luxury Specular Light Reflection Layer */}
                <div
                  className="absolute inset-0 pointer-events-none transition-opacity duration-300"
                  style={{
                    opacity: isHovering ? 0.35 : 0.15,
                    background: `radial-gradient(circle at ${tilt.lightX}% ${tilt.lightY}%, rgba(255, 255, 255, 0.8) 0%, rgba(250, 248, 245, 0.2) 35%, transparent 70%)`
                  }}
                />

                {/* Scrim overlay at bottom for contrast */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#242424]/75 via-[#242424]/15 to-transparent pointer-events-none" />

                {/* Floating depth plaque on card with Words Description */}
                <div
                  className="absolute bottom-6 left-6 right-6 p-4 bg-[#FAF8F5]/90 backdrop-blur-md border border-[#D8CEC8]/60 transition-transform duration-300"
                  style={{
                    transform: isHovering ? 'translateZ(30px)' : 'translateZ(10px)'
                  }}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-0.5 min-w-0 flex-1">
                      <p className="text-[11px] uppercase tracking-widest text-[#C9A6A0] font-semibold flex items-center gap-1.5">
                        {mediaMode === 'video' && <Film className="w-3 h-3 text-[#C9A6A0]" />}
                        <span>
                          {settings.heroMediaBadge || (mediaMode === 'video' ? 'Editorial Motion Reel' : 'Signature Finish')}
                        </span>
                      </p>
                      <h4 className="font-serif text-lg font-medium text-[#242424] leading-tight truncate">
                        {settings.heroMediaHeading || '18K PVD Liquid Gold'}
                      </h4>
                      {/* Words description for video or photo added by owner */}
                      <p className="text-[11px] text-[#242424]/75 line-clamp-2 pt-1 font-normal leading-relaxed">
                        {settings.heroVideoDescription ||
                          'Pure 316L surgical stainless steel infused with 18K vacuum PVD liquid gold plating. Built to stay radiant through every splash.'}
                      </p>
                    </div>
                    <span className="text-xs font-semibold text-[#242424] border-b border-[#242424] pb-0.5 shrink-0 self-center">
                      Explore &rarr;
                    </span>
                  </div>
                </div>
              </div>

              {/* Decorative delicate floating corner accent */}
              <div
                className="absolute -top-3 -right-3 w-16 h-16 border-t-2 border-r-2 border-[#C5A880]/50 pointer-events-none transition-transform duration-300"
                style={{
                  transform: `translate(${tilt.y * 1.5}px, ${-tilt.x * 1.5}px)`
                }}
              />
              <div
                className="absolute -bottom-3 -left-3 w-16 h-16 border-b-2 border-l-2 border-[#C9A6A0]/50 pointer-events-none transition-transform duration-300"
                style={{
                  transform: `translate(${-tilt.y * 1.5}px, ${tilt.x * 1.5}px)`
                }}
              />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
