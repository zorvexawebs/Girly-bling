import React from 'react';
import { useStore } from '../context/StoreContext';
import { ProductCard } from './ProductCard';
import { Product } from '../types';
import { Sparkles, ArrowRight } from 'lucide-react';

interface NewArrivalsProps {
  onQuickView: (product: Product) => void;
}

export const NewArrivals: React.FC<NewArrivalsProps> = ({ onQuickView }) => {
  const { products, setActivePage } = useStore();

  const newProducts = products.filter((p) => p.isNewArrival);
  const displayList = newProducts.length > 0 ? newProducts : products.slice(0, 4);

  return (
    <section id="new-arrivals" className="py-16 sm:py-24 bg-[#FAF8F5] border-t border-[#D8CEC8]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 pb-4 border-b border-[#D8CEC8]/40 gap-4">
          <div>
            <div className="flex items-center gap-1.5 text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Just Unveiled</span>
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
              New Arrivals
            </h2>
          </div>

          <button
            onClick={() => {
              setActivePage('shop');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-[#242424] hover:text-[#C9A6A0] transition-colors cursor-pointer self-start sm:self-auto"
          >
            <span>View All New</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {displayList.map((product) => (
            <ProductCard key={product.id} product={product} onQuickView={onQuickView} />
          ))}
        </div>
      </div>
    </section>
  );
};
