import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Search, Heart, ShoppingBag, Menu, X, ShieldCheck } from 'lucide-react';

export const Header: React.FC<{ onOpenSizeGuide?: () => void }> = ({ onOpenSizeGuide }) => {
  const {
    settings,
    cartCount,
    wishlistCount,
    setIsCartOpen,
    setIsWishlistOpen,
    setIsSearchOpen,
    activePage,
    setActivePage,
    setIsDashboardOpen
  } = useStore();

  const [isAnnouncementVisible, setIsAnnouncementVisible] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (page: any) => {
    setActivePage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-md border-b border-[#D8CEC8]/40 transition-colors">
      {/* Slim dismissible announcement banner */}
      {settings.announcementActive && isAnnouncementVisible && (
        <div className="bg-[#242424] text-[#FAF8F5] text-[11px] md:text-xs py-2 px-4 flex items-center justify-between tracking-wide font-normal">
          <div className="flex-1 text-center truncate">
            {settings.announcementText}
          </div>
          <button
            onClick={() => setIsAnnouncementVisible(false)}
            aria-label="Dismiss announcement"
            className="text-[#FAF8F5]/60 hover:text-[#FAF8F5] ml-2 p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Top Navigation Bar — Strict 3-zone contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Zone 1: Single element Brand Wordmark */}
        <div className="flex items-center">
          <button
            onClick={() => handleNavClick('home')}
            className="text-left group cursor-pointer"
            aria-label="Girly Bling Home"
          >
            <span className="font-serif text-2xl sm:text-3xl tracking-tight text-[#242424] font-medium group-hover:text-[#C9A6A0] transition-colors whitespace-nowrap">
              {settings.businessName}
            </span>
          </button>
        </div>

        {/* Zone 2: Clean 4–6 text navigation links */}
        <nav className="hidden lg:flex items-center space-x-7 text-[13px] tracking-wider uppercase font-medium text-[#242424]/80">
          <button
            onClick={() => handleNavClick('home')}
            className={`transition-colors hover:text-[#242424] relative py-1 ${
              activePage === 'home' ? 'text-[#242424] font-semibold after:absolute after:bottom-0 after:left-0 after:w-full after:h-[1.5px] after:bg-[#242424]' : 'text-[#242424]/70'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('shop')}
            className={`transition-colors hover:text-[#242424] relative py-1 ${
              activePage === 'shop' ? 'text-[#242424] font-semibold after:absolute after:bottom-0 after:left-0 after:w-full after:h-[1.5px] after:bg-[#242424]' : 'text-[#242424]/70'
            }`}
          >
            Shop
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className={`transition-colors hover:text-[#242424] relative py-1 ${
              activePage === 'about' ? 'text-[#242424] font-semibold after:absolute after:bottom-0 after:left-0 after:w-full after:h-[1.5px] after:bg-[#242424]' : 'text-[#242424]/70'
            }`}
          >
            About
          </button>
          <button
            onClick={() => handleNavClick('lookbook')}
            className={`transition-colors hover:text-[#242424] relative py-1 ${
              activePage === 'lookbook' ? 'text-[#242424] font-semibold after:absolute after:bottom-0 after:left-0 after:w-full after:h-[1.5px] after:bg-[#242424]' : 'text-[#242424]/70'
            }`}
          >
            Lookbook
          </button>
          <button
            onClick={() => handleNavClick('reviews')}
            className={`transition-colors hover:text-[#242424] relative py-1 ${
              activePage === 'reviews' ? 'text-[#242424] font-semibold after:absolute after:bottom-0 after:left-0 after:w-full after:h-[1.5px] after:bg-[#242424]' : 'text-[#242424]/70'
            }`}
          >
            Reviews
          </button>
          {onOpenSizeGuide && (
            <button
              onClick={onOpenSizeGuide}
              className="text-[#242424]/70 hover:text-[#242424] transition-colors py-1 cursor-pointer"
            >
              Size Guide
            </button>
          )}
          <button
            onClick={() => handleNavClick('contact')}
            className={`transition-colors hover:text-[#242424] relative py-1 ${
              activePage === 'contact' ? 'text-[#242424] font-semibold after:absolute after:bottom-0 after:left-0 after:w-full after:h-[1.5px] after:bg-[#242424]' : 'text-[#242424]/70'
            }`}
          >
            Contact
          </button>
        </nav>

        {/* Zone 3: Interactive primary affordances */}
        <div className="flex items-center space-x-2 sm:space-x-4">
          {/* Search Button */}
          <button
            onClick={() => setIsSearchOpen(true)}
            aria-label="Search jewellery"
            className="p-2 text-[#242424]/80 hover:text-[#242424] hover:bg-[#D8CEC8]/20 rounded-full transition-colors cursor-pointer"
          >
            <Search className="w-5 h-5 stroke-[1.5]" />
          </button>

          {/* Wishlist Button */}
          <button
            onClick={() => setIsWishlistOpen(true)}
            aria-label="Wishlist"
            className="p-2 text-[#242424]/80 hover:text-[#242424] hover:bg-[#D8CEC8]/20 rounded-full transition-colors relative cursor-pointer"
          >
            <Heart className="w-5 h-5 stroke-[1.5]" />
            {wishlistCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-[#C9A6A0] text-white text-[10px] font-semibold rounded-full flex items-center justify-center tabular-nums">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Cart / Bag Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            aria-label="Shopping bag"
            className="p-2 text-[#242424]/80 hover:text-[#242424] hover:bg-[#D8CEC8]/20 rounded-full transition-colors relative cursor-pointer"
          >
            <ShoppingBag className="w-5 h-5 stroke-[1.5]" />
            {cartCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-[#242424] text-white text-[10px] font-semibold rounded-full flex items-center justify-center tabular-nums">
                {cartCount}
              </span>
            )}
          </button>

          {/* Discreet Owner Dashboard Entry */}
          <button
            onClick={() => setIsDashboardOpen(true)}
            aria-label="Owner dashboard"
            title="Owner Portal"
            className="p-2 text-[#242424]/40 hover:text-[#C9A6A0] transition-colors cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
          </button>

          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle mobile menu"
            className="lg:hidden p-2 text-[#242424]/80 hover:text-[#242424] transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FAF8F5] border-b border-[#D8CEC8] px-6 py-6 space-y-4 shadow-lg animate-in fade-in duration-200">
          <div className="flex flex-col space-y-3 text-sm tracking-wider uppercase font-medium text-[#242424]/80">
            <button
              onClick={() => handleNavClick('home')}
              className="text-left py-2 border-b border-[#D8CEC8]/30 hover:text-[#242424]"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('shop')}
              className="text-left py-2 border-b border-[#D8CEC8]/30 hover:text-[#242424]"
            >
              Shop All Jewellery
            </button>
            <button
              onClick={() => handleNavClick('about')}
              className="text-left py-2 border-b border-[#D8CEC8]/30 hover:text-[#242424]"
            >
              Our Story & Craft
            </button>
            <button
              onClick={() => handleNavClick('lookbook')}
              className="text-left py-2 border-b border-[#D8CEC8]/30 hover:text-[#242424]"
            >
              Lookbook
            </button>
            <button
              onClick={() => handleNavClick('reviews')}
              className="text-left py-2 border-b border-[#D8CEC8]/30 hover:text-[#242424]"
            >
              Customer Reviews
            </button>
            {onOpenSizeGuide && (
              <button
                onClick={() => {
                  onOpenSizeGuide();
                  setMobileMenuOpen(false);
                }}
                className="text-left py-2 border-b border-[#D8CEC8]/30 hover:text-[#242424]"
              >
                Size Guide
              </button>
            )}
            <button
              onClick={() => handleNavClick('contact')}
              className="text-left py-2 border-b border-[#D8CEC8]/30 hover:text-[#242424]"
            >
              Contact & WhatsApp
            </button>
            <button
              onClick={() => {
                setIsDashboardOpen(true);
                setMobileMenuOpen(false);
              }}
              className="text-left py-2 text-xs text-[#C9A6A0] font-semibold uppercase tracking-widest pt-2 flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Owner Portal
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
