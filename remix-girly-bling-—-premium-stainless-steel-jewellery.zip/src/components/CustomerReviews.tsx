import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Star, CheckCircle, Plus, X } from 'lucide-react';

export const CustomerReviews: React.FC = () => {
  const { reviews, addReview } = useStore();
  const approvedReviews = reviews.filter((r) => r.approved);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    author: '',
    location: '',
    rating: 5,
    title: '',
    comment: '',
    productName: 'Aurelia Herringbone Snake Chain'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.author || !formData.comment) return;
    addReview({
      author: formData.author,
      location: formData.location || 'Pakistan',
      rating: formData.rating,
      title: formData.title || 'Exceptional Quality',
      comment: formData.comment,
      productName: formData.productName,
      verified: true
    });
    setFormData({
      author: '',
      location: '',
      rating: 5,
      title: '',
      comment: '',
      productName: 'Aurelia Herringbone Snake Chain'
    });
    setIsModalOpen(false);
  };

  return (
    <section className="py-20 sm:py-28 bg-[#F4EFEB]/50 border-t border-[#D8CEC8]/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 pb-4 border-b border-[#D8CEC8]/40 gap-4">
          <div>
            <div className="text-xs uppercase tracking-widest text-[#C9A6A0] font-semibold mb-2">
              Real Experiences
            </div>
            <h2 className="font-serif text-3xl sm:text-4xl text-[#242424] font-medium tracking-tight">
              Loved by Thousands Across Pakistan
            </h2>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#242424] text-white text-xs uppercase tracking-wider font-semibold hover:bg-black transition-colors self-start sm:self-auto cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Write a Review</span>
          </button>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {approvedReviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-[#FAF8F5] p-6 border border-[#D8CEC8]/60 flex flex-col justify-between space-y-4 hover:border-[#C9A6A0]/80 transition-colors"
            >
              <div className="space-y-3">
                {/* 5-Star Rating */}
                <div className="flex items-center gap-1 text-[#C5A880]">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3.5 h-3.5 ${
                        i < rev.rating ? 'fill-current' : 'text-[#D8CEC8]'
                      }`}
                    />
                  ))}
                </div>

                <h3 className="font-serif text-base text-[#242424] font-medium leading-snug">
                  “{rev.title}”
                </h3>

                <p className="text-xs sm:text-sm text-[#242424]/75 leading-relaxed">
                  {rev.comment}
                </p>
              </div>

              {/* Author & Verified Badge */}
              <div className="pt-3 border-t border-[#D8CEC8]/40 text-xs text-[#242424]/70">
                <div className="flex items-center justify-between font-medium text-[#242424]">
                  <span>{rev.author}</span>
                  {rev.verified && (
                    <span className="flex items-center gap-1 text-[11px] text-[#C9A6A0]">
                      <CheckCircle className="w-3 h-3 fill-current text-white" />
                      <span>Verified Buyer</span>
                    </span>
                  )}
                </div>
                {rev.location && (
                  <div className="text-[11px] text-[#242424]/50 mt-0.5">
                    {rev.location} · {rev.productName}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Customer Write Review Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#242424]/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#FAF8F5] max-w-lg w-full p-6 sm:p-8 border border-[#D8CEC8] shadow-2xl relative">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-[#242424]/60 hover:text-[#242424]"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-serif text-2xl text-[#242424] font-medium mb-1">
              Share Your Experience
            </h3>
            <p className="text-xs text-[#242424]/70 mb-6">
              Your honest feedback helps fellow jewellery lovers discover genuine waterproof pieces.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#242424]/80 mb-1">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ayesha Malik"
                  value={formData.author}
                  onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#D8CEC8] text-xs focus:outline-hidden focus:border-[#242424]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424]/80 mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Lahore / Karachi"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D8CEC8] text-xs focus:outline-hidden focus:border-[#242424]"
                  />
                </div>

                <div>
                  <label className="block font-semibold uppercase tracking-wider text-[#242424]/80 mb-1">
                    Rating
                  </label>
                  <select
                    value={formData.rating}
                    onChange={(e) => setFormData({ ...formData, rating: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-white border border-[#D8CEC8] text-xs focus:outline-hidden focus:border-[#242424]"
                  >
                    <option value={5}>5 Stars — Exceeded Expectations</option>
                    <option value={4}>4 Stars — Loved it</option>
                    <option value={3}>3 Stars — Good</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#242424]/80 mb-1">
                  Review Headline
                </label>
                <input
                  type="text"
                  placeholder="e.g. Truly 100% waterproof in Karachi weather!"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#D8CEC8] text-xs focus:outline-hidden focus:border-[#242424]"
                />
              </div>

              <div>
                <label className="block font-semibold uppercase tracking-wider text-[#242424]/80 mb-1">
                  Your Review *
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Tell us about the weight, shine, feel, or delivery..."
                  value={formData.comment}
                  onChange={(e) => setFormData({ ...formData, comment: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#D8CEC8] text-xs focus:outline-hidden focus:border-[#242424]"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-[#D8CEC8] text-[#242424] text-xs uppercase tracking-wider"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-[#242424] text-white text-xs uppercase tracking-wider font-semibold hover:bg-black transition-colors"
                >
                  Submit Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
