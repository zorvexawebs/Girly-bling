import React from 'react';
import { useStore } from '../context/StoreContext';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { formatPKR } from '../utils/formatters';

export const WishlistDrawer: React.FC = () => {
  const {
    wishlist,
    products,
    isWishlistOpen,
    setIsWishlistOpen,
    toggleWishlist,
    addToCart,
    openProductDetail
  } = useStore();

  if (!isWishlistOpen) return null;

  const wishlistedProducts = products.filter((p) => wishlist.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-[#242424]/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="absolute inset-0" onClick={() => setIsWishlistOpen(false)} />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FAF8F5] border-l border-[#D8CEC8] shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 border-b border-[#D8CEC8]/40 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-[#A57E78] fill-current" />
              <h2 className="font-serif text-2xl font-medium text-[#242424]">
                Your Wishlist
              </h2>
              <span className="text-xs text-[#242424]/60 tabular-nums">
                ({wishlistedProducts.length})
              </span>
            </div>

            <button
              onClick={() => setIsWishlistOpen(false)}
              aria-label="Close wishlist"
              className="p-1.5 text-[#242424]/60 hover:text-[#242424] hover:bg-[#D8CEC8]/30 rounded-full transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Wishlist Items List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {wishlistedProducts.length === 0 ? (
              <div className="py-20 text-center space-y-4">
                <Heart className="w-12 h-12 text-[#D8CEC8] mx-auto stroke-[1.2]" />
                <h3 className="font-serif text-xl text-[#242424] font-medium">
                  Your wishlist is waiting for something beautiful.
                </h3>
                <p className="text-xs text-[#242424]/60 max-w-xs mx-auto">
                  Click the heart icon on any piece to save your personal favorites for later.
                </p>
              </div>
            ) : (
              wishlistedProducts.map((product) => (
                <div
                  key={product.id}
                  className="flex gap-4 pb-6 border-b border-[#D8CEC8]/30 last:border-b-0"
                >
                  <img
                    src={product.images[0] || '/src/assets/images/product_travertine_jewellery_1790183496193.jpg'}
                    alt={product.name}
                    className="w-20 h-24 object-cover bg-[#F4EFEB] shrink-0 border border-[#D8CEC8]/40 cursor-pointer"
                    onClick={() => {
                      setIsWishlistOpen(false);
                      openProductDetail(product.id);
                    }}
                  />

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4
                          onClick={() => {
                            setIsWishlistOpen(false);
                            openProductDetail(product.id);
                          }}
                          className="font-serif text-sm font-medium text-[#242424] line-clamp-1 cursor-pointer hover:text-[#A57E78]"
                        >
                          {product.name}
                        </h4>
                        <button
                          onClick={() => toggleWishlist(product.id)}
                          aria-label="Remove from wishlist"
                          className="text-[#242424]/40 hover:text-red-700 transition-colors p-1"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="text-[11px] text-[#242424]/60 mt-0.5">
                        {product.material}
                      </div>

                      <div className="text-xs font-semibold text-[#242424] mt-1 tabular-nums">
                        {formatPKR(product.price)}
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        onClick={() => {
                          const size = product.sizes[0] || 'Standard';
                          addToCart(product, size, 1);
                        }}
                        disabled={product.stockStatus === 'sold_out'}
                        className="w-full py-2 bg-[#242424] text-white text-[11px] uppercase tracking-wider font-semibold hover:bg-black transition-colors flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                      >
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>{product.stockStatus === 'sold_out' ? 'Sold Out' : 'Move to Bag'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          <div className="p-6 bg-[#F4EFEB]/50 border-t border-[#D8CEC8] text-center">
            <button
              onClick={() => setIsWishlistOpen(false)}
              className="text-xs uppercase tracking-wider font-semibold text-[#242424] hover:text-[#A57E78] transition-colors"
            >
              Continue Browsing
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
