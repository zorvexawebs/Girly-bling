import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.warn('Girly Bling captured an interface exception:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.href = '/';
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#FAF8F5] text-[#242424] flex items-center justify-center p-6 antialiased">
          <div className="max-w-md w-full bg-white border border-[#D8CEC8] p-8 text-center space-y-6 shadow-sm">
            <div className="space-y-2">
              <span className="text-[10px] tracking-[0.25em] uppercase font-semibold text-[#C9A6A0]">
                Girly Bling · Everyday Luxury
              </span>
              <h1 className="font-serif text-3xl font-medium text-[#242424]">
                Refining Your Display
              </h1>
              <p className="text-xs text-[#242424]/70 leading-relaxed pt-1">
                We encountered an unexpected glitch while rendering the storefront. Our catalogue and cart are protected.
              </p>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                type="button"
                onClick={this.handleReset}
                className="w-full sm:w-auto px-6 py-2.5 bg-[#242424] text-white text-xs uppercase tracking-widest font-semibold hover:bg-black transition-colors cursor-pointer"
              >
                Reload Boutique
              </button>
              <button
                type="button"
                onClick={() => this.setState({ hasError: false, error: null })}
                className="w-full sm:w-auto px-5 py-2.5 border border-[#242424]/20 text-[#242424] text-xs uppercase tracking-widest font-semibold hover:border-[#242424] transition-colors cursor-pointer"
              >
                Try Again
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
