export const formatPKR = (amount: number | undefined | null): string => {
  if (amount === undefined || amount === null || isNaN(Number(amount))) {
    return 'Rs. 0';
  }
  return `Rs. ${Number(amount).toLocaleString('en-PK')}`;
};

export const formatDate = (dateString: string | undefined | null): string => {
  if (!dateString) return '';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return String(dateString);
    return d.toLocaleDateString('en-PK', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  } catch {
    return String(dateString);
  }
};
