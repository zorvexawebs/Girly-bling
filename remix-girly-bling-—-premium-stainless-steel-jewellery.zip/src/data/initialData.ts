import { Product, StoreSettings, Order, Review, Customer } from '../types';

export const INITIAL_SETTINGS: StoreSettings = {
  businessName: 'Girly Bling',
  tagline: 'Jewellery That Completes Your Story.',
  brandDescription: 'Girly Bling crafts timeless, waterproof, and hypoallergenic 316L stainless-steel jewellery. Designed in Pakistan for modern women who seek effortless luxury without compromise.',
  logoUrl: '',
  whatsappNumber: '+92 321 8492001',
  phone: '+92 321 8492001',
  email: 'concierge@girlybling.pk',
  address: 'Suite 402, Al-Hafeez Heights, Gulberg III, Lahore, Pakistan',
  businessHours: 'Monday – Saturday: 11:00 AM – 9:00 PM PKT',
  instagramUsername: '@girlybling.pk',
  instagramUrl: 'https://instagram.com/girlybling.pk',
  facebookUrl: 'https://facebook.com/girlybling.pk',
  tiktokUrl: 'https://tiktok.com/@girlybling.pk',
  heroHeading: 'Jewellery That Completes Your Story.',
  heroSubheading: 'Timeless stainless-steel pieces designed to add effortless elegance to every look. Waterproof, anti-tarnish, and skin-friendly.',
  heroBadge: 'The Autumn / Winter Capsule Collection',
  heroImage: '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg',
  heroMediaType: 'image',
  heroVideoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-close-up-of-a-woman-wearing-golden-necklaces-42407-large.mp4',
  heroVideoDescription: 'Pure 316L surgical stainless steel infused with 18K vacuum PVD liquid gold plating. Built to stay radiant through every splash.',
  heroMediaBadge: 'Signature Finish',
  heroMediaHeading: '18K PVD Liquid Gold',
  freeShippingThreshold: 3500,
  standardShippingFee: 250,
  announcementText: 'Complimentary Nationwide Shipping in Pakistan on Orders Over Rs. 3,500 · Cash on Delivery Available',
  announcementActive: true,
  bankName: 'Meezan Bank Limited',
  bankTitle: 'Girly Bling Private Ltd',
  bankIban: 'PK42MEZN0001020304050607',
  easypaisaNumber: '0321-8492001 (Title: Girly Bling)',
  jazzcashNumber: '0321-8492001 (Title: Girly Bling)',
  primaryBgColor: '#FAF8F5',
  textColor: '#242424',
  accentRoseColor: '#C9A6A0',
  taupeColor: '#D8CEC8',
  champagneGoldColor: '#C5A880',
  shippingPolicy: `### Delivery Information across Pakistan
We are delighted to offer swift, secure delivery to every city, town, and postal code across Pakistan via premier courier partners (TCS, Leopards, and Call Courier).

- **Standard Delivery Time:** 2 to 4 business days for major cities (Karachi, Lahore, Islamabad, Rawalpindi, Faisalabad, Multan, Peshawar, Sialkot, Gujranwala). Other regional destinations typically arrive in 3 to 5 business days.
- **Shipping Rates:**
  - **Orders over Rs. 3,500:** FREE Complimentary Nationwide Delivery.
  - **Orders below Rs. 3,500:** Flat delivery charge of Rs. 250.
- **Payment Method:** Cash on Delivery (COD) available nationwide. Advance Bank Transfer, JazzCash, and EasyPaisa are also gladly accepted.
- **Tracking:** Once dispatched, an SMS and WhatsApp tracking link will be sent directly to your registered mobile number.`,
  returnPolicy: `### 7-Day Hassle-Free Exchange & Return Policy
At Girly Bling, your complete satisfaction is our foremost priority.

- **Window:** You may request an exchange or return within **7 days** of parcel delivery.
- **Condition:** Items must be in unworn, brand-new condition with original luxury velvet pouch, protective tags, and packaging intact.
- **Damaged / Defective Deliveries:** In the rare case of shipping damage or discrepancy, notify us on WhatsApp (+92 321 8492001) within 24 hours of receipt with unboxing photos for an immediate replacement at zero additional charge.
- **Non-Returnable Items:** Earrings cannot be exchanged for hygiene and health reasons, unless received damaged.`,
  privacyPolicy: `Girly Bling values and respects your personal privacy. We collect only the essential information needed to fulfill your jewellery orders securely (customer name, shipping address, WhatsApp phone number, and email). We never sell, lease, or distribute your private information to third-party advertisers. All order information is safeguarded with modern SSL encryption.`,
  termsPolicy: `By placing an order on Girly Bling, you agree to our standard terms of service. All prices are listed in Pakistani Rupees (PKR) and are inclusive of relevant local taxes. Deliveries are subject to courier route confirmations. We reserve the right to verify high-value Cash on Delivery orders via phone call or WhatsApp prior to dispatch.`,
  faqs: [
    {
      id: 'faq-1',
      category: 'Material & Quality',
      question: 'What material are your jewellery pieces crafted from?',
      answer: 'Every Girly Bling piece is precision-forged from surgical-grade 316L stainless steel, plated with genuine 18K gold using advanced PVD (Physical Vapor Deposition) vacuum plating. This makes our jewellery 100% waterproof, non-tarnish, and hypoallergenic.'
    },
    {
      id: 'faq-2',
      category: 'Everyday Wear',
      question: 'Can I wear Girly Bling jewellery in the shower, gym, or pool?',
      answer: 'Yes, absolutely! Unlike alloy or brass fashion jewellery that turns green, our 316L stainless steel pieces are fully water-resistant. You can wear them while washing hands, showering, working out, or swimming without fear of tarnishing.'
    },
    {
      id: 'faq-3',
      category: 'Shipping & Payment',
      question: 'Do you offer Cash on Delivery (COD) in Pakistan?',
      answer: 'Yes! We offer nationwide Cash on Delivery (COD) to all cities and towns across Pakistan. You can pay the courier rider upon delivery. Orders over Rs. 3,500 qualify for free shipping.'
    },
    {
      id: 'faq-4',
      category: 'Shipping & Payment',
      question: 'How long does delivery take?',
      answer: 'Orders are processed within 24 business hours. Deliveries to Lahore, Karachi, Islamabad, and Rawalpindi take 2 to 3 business days. Deliveries to other cities take 3 to 5 business days.'
    },
    {
      id: 'faq-5',
      category: 'Sizing',
      question: 'How do I determine my correct ring or bracelet size?',
      answer: 'We provide an interactive Size Guide on our website detailing millimeter circumferences and diameters for Pakistani and US standards. Most of our necklaces and bracelets also feature a 5cm extension chain to ensure a tailored fit.'
    },
    {
      id: 'faq-6',
      category: 'Care',
      question: 'How should I care for my stainless steel jewellery?',
      answer: 'Caring for stainless steel is effortless: simply wipe with a soft microfibre cloth after wearing to remove cosmetic residue or fingerprints. Store each piece separately in your provided Girly Bling velvet pouch to prevent surface scratches.'
    }
  ]
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'gb-001',
    name: 'Aurelia Herringbone Snake Chain',
    subtitle: 'Liquid Gold Finish · High Polish 316L Stainless Steel',
    description: 'The iconic Aurelia Herringbone snake chain lays flat against the collarbone with fluid, mirror-like reflection. Vacuum-plated with 18K gold over surgical 316L stainless steel, it is impervious to water, perfumes, and perspiration.',
    price: 2850,
    originalPrice: 3400,
    category: 'Necklaces',
    collection: 'Timeless Essentials',
    material: '316L Surgical Stainless Steel, 18K PVD Gold Plated',
    images: [
      '/src/assets/images/product_travertine_jewellery_1790183496193.jpg',
      '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg',
      '/src/assets/images/lookbook_lifestyle_portrait_1790183522124.jpg'
    ],
    stock: 24,
    stockStatus: 'in_stock',
    sku: 'GB-NK-001',
    sizes: ['40cm + 5cm Extender', '45cm + 5cm Extender'],
    weight: '14.2g',
    tags: ['Waterproof', 'Anti-Tarnish', 'Best Seller', 'Gold'],
    isFeatured: true,
    isNewArrival: false,
    isBestSeller: true,
    rating: 4.9,
    reviewCount: 48,
    careInstructions: 'Water-safe. Rinse gently with fresh water after salt or chlorinated exposure. Dry with a soft cloth.'
  },
  {
    id: 'gb-002',
    name: 'Seraphina Twisted Croissant Ring',
    subtitle: 'Sculptural Parisian Silhouette · Tarnish Free',
    description: 'Inspired by classic Parisian vintage silhouettes, the Seraphina Croissant Ring features elegant fluted ridges that catch the light from every dimension. Engineered for everyday comfort with a tapered smooth inner band.',
    price: 1950,
    originalPrice: 2400,
    category: 'Rings',
    collection: 'Sculptural Modernism',
    material: '316L Surgical Stainless Steel, 18K Gold PVD',
    images: [
      '/src/assets/images/product_travertine_jewellery_1790183496193.jpg',
      '/src/assets/images/brand_craftsmanship_story_1790183510549.jpg'
    ],
    stock: 8,
    stockStatus: 'low_stock',
    sku: 'GB-RG-002',
    sizes: ['US 6 (16.5mm)', 'US 7 (17.3mm)', 'US 8 (18.1mm)'],
    weight: '6.4g',
    tags: ['Ring', 'Croissant', 'Gold', 'Everyday'],
    isFeatured: true,
    isNewArrival: false,
    isBestSeller: true,
    rating: 4.8,
    reviewCount: 39,
    careInstructions: 'Comfort-fit band. Safe for hand sanitizing and washing.'
  },
  {
    id: 'gb-003',
    name: 'Celeste Dual Roman Cable Bangle',
    subtitle: 'Roman Numerals · Double Hinged Luxury Clasp',
    description: 'A striking statement cuff engineered with micro-inlaid cubic zirconia and subtle Roman numeral engraving. Equipped with an ergonomic security clasp for effortless one-handed wearing.',
    price: 3450,
    originalPrice: 4200,
    category: 'Bracelets & Bangles',
    collection: 'Elegance & Heritage',
    material: '316L Stainless Steel, 18K Gold, AAA+ Cubic Zirconia',
    images: [
      '/src/assets/images/lookbook_lifestyle_portrait_1790183522124.jpg',
      '/src/assets/images/product_travertine_jewellery_1790183496193.jpg'
    ],
    stock: 12,
    stockStatus: 'in_stock',
    sku: 'GB-BR-003',
    sizes: ['Small (16cm wrist)', 'Medium (18cm wrist)'],
    weight: '18.5g',
    tags: ['Bangle', 'Roman', 'Zirconia', 'Waterproof'],
    isFeatured: true,
    isNewArrival: true,
    isBestSeller: false,
    rating: 5.0,
    reviewCount: 22,
    careInstructions: 'Security push clasp. Clean stones with soft brush if dust accumulates.'
  },
  {
    id: 'gb-004',
    name: 'Elysian Chunky Teardrop Earrings',
    subtitle: 'Lightweight Hollow Architectural Form · Ultra-Chic',
    description: 'The viral high-fashion teardrop silhouette, engineered as a featherlight hollow casting so you can wear them all day and night with zero earlobe strain. Hypoallergenic surgical steel posts protect sensitive skin.',
    price: 2250,
    originalPrice: 2800,
    category: 'Earrings',
    collection: 'Sculptural Modernism',
    material: '316L Stainless Steel, 18K Gold Plated',
    images: [
      '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg',
      '/src/assets/images/product_travertine_jewellery_1790183496193.jpg'
    ],
    stock: 19,
    stockStatus: 'in_stock',
    sku: 'GB-ER-004',
    sizes: ['One Size (31mm length)'],
    weight: '5.1g per earring',
    tags: ['Earrings', 'Teardrop', 'Lightweight', 'Gold'],
    isFeatured: true,
    isNewArrival: true,
    isBestSeller: true,
    rating: 4.9,
    reviewCount: 57,
    careInstructions: 'Hypoallergenic posts. Wipe posts with alcohol wipe periodically.'
  },
  {
    id: 'gb-005',
    name: 'Mira Green Malachite Clover Pendant',
    subtitle: 'Emerald Green Faux Malachite · Double-Sided Motif',
    description: 'An auspicious lucky clover motif inlaid with deep emerald malachite veining, framed with delicate beaded gold border. Suspended from an adjustable box chain that layers effortlessly.',
    price: 2650,
    originalPrice: 3100,
    category: 'Necklaces',
    collection: 'Lucky Charm',
    material: '316L Stainless Steel, 18K Gold, Synthetic Malachite',
    images: [
      '/src/assets/images/product_travertine_jewellery_1790183496193.jpg',
      '/src/assets/images/brand_craftsmanship_story_1790183510549.jpg'
    ],
    stock: 15,
    stockStatus: 'in_stock',
    sku: 'GB-NK-005',
    sizes: ['42cm + 6cm Extender'],
    weight: '8.2g',
    tags: ['Clover', 'Malachite', 'Green', 'Necklace'],
    isFeatured: false,
    isNewArrival: true,
    isBestSeller: false,
    rating: 4.7,
    reviewCount: 16,
    careInstructions: 'Store in dry velvet pouch. Avoid abrasive cleaners.'
  },
  {
    id: 'gb-006',
    name: 'Lumière Diamond Cut Tennis Bracelet',
    subtitle: 'Bezel Set Brilliant Zircons · 100% Waterproof',
    description: 'A contemporary reinterpretation of the traditional tennis bracelet. Individually set round brilliant stones framed in stainless steel bezel cups that will never catch on knitwear or delicate fabrics.',
    price: 3600,
    originalPrice: 4500,
    category: 'Bracelets & Bangles',
    collection: 'Timeless Essentials',
    material: '316L Stainless Steel, 18K Gold, 3mm AAA Zirconia',
    images: [
      '/src/assets/images/lookbook_lifestyle_portrait_1790183522124.jpg',
      '/src/assets/images/product_travertine_jewellery_1790183496193.jpg'
    ],
    stock: 7,
    stockStatus: 'low_stock',
    sku: 'GB-BR-006',
    sizes: ['16cm + 4cm Extender'],
    weight: '11.0g',
    tags: ['Tennis Bracelet', 'Sparkle', 'Waterproof', 'Gold'],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true,
    rating: 5.0,
    reviewCount: 34,
    careInstructions: 'Secure fold-over safety clasp. Safe in warm water.'
  },
  {
    id: 'gb-007',
    name: 'Solstice Sunburst Medallion Choker',
    subtitle: 'Radiant Celestial Relief · Vintage Coin Detail',
    description: 'Featuring an engraved relief of the midday sun surrounded by celestial rays, this tactile coin medallion symbolizes strength, warmth, and grace. Paired with a delicate paperclip chain.',
    price: 2750,
    originalPrice: 3200,
    category: 'Necklaces',
    collection: 'Celestial Horizon',
    material: '316L Stainless Steel, 18K Gold Plated',
    images: [
      '/src/assets/images/brand_craftsmanship_story_1790183510549.jpg',
      '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg'
    ],
    stock: 20,
    stockStatus: 'in_stock',
    sku: 'GB-NK-007',
    sizes: ['38cm + 7cm Extender'],
    weight: '12.4g',
    tags: ['Sunburst', 'Medallion', 'Coin', 'Necklace'],
    isFeatured: true,
    isNewArrival: true,
    isBestSeller: false,
    rating: 4.8,
    reviewCount: 19,
    careInstructions: 'Wipe with soft cotton or microfiber cloth after exposure to oils.'
  },
  {
    id: 'gb-008',
    name: 'Amara Minimalist Stacking Ring Trio',
    subtitle: 'Set of 3 Textured Bands · Beaded, Twisted & Polished',
    description: 'Three distinct bands crafted to be worn together as an opulent stack or distributed across fingers for subtle everyday sophistication. Engineered with anti-fading durability.',
    price: 2400,
    originalPrice: 2900,
    category: 'Rings',
    collection: 'Timeless Essentials',
    material: '316L Surgical Stainless Steel, 18K Gold PVD',
    images: [
      '/src/assets/images/product_travertine_jewellery_1790183496193.jpg',
      '/src/assets/images/brand_craftsmanship_story_1790183510549.jpg'
    ],
    stock: 0,
    stockStatus: 'sold_out',
    sku: 'GB-RG-008',
    sizes: ['US 6', 'US 7', 'US 8'],
    weight: '4.8g set',
    tags: ['Rings', 'Stack', 'Minimalist', 'Trio'],
    isFeatured: false,
    isNewArrival: false,
    isBestSeller: true,
    rating: 4.9,
    reviewCount: 62,
    careInstructions: 'Solid stainless steel. Will not discolor hands.'
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Ayesha Khan',
    location: 'Lahore, Punjab',
    rating: 5,
    title: 'Wore it in the shower for 3 months — completely zero tarnish!',
    comment: 'I was honestly skeptical about stainless steel jewellery being truly non-tarnish in Lahore humidity. I have worn the Aurelia Herringbone chain daily, during workouts and showers, and the 18K gold luster looks brand new. The velvet box was also so luxurious!',
    productName: 'Aurelia Herringbone Snake Chain',
    verified: true,
    date: '14 September 2026',
    approved: true
  },
  {
    id: 'rev-2',
    author: 'Mahnoor Tariq',
    location: 'Karachi, Sindh',
    rating: 5,
    title: 'Fast COD delivery & immaculate weight and feel',
    comment: 'Ordered via Cash on Delivery and received it in Clifton within 48 hours. The chunky teardrop earrings look like a luxury international designer piece without weighing down my ears at all. Will definitely be ordering the bracelet next!',
    productName: 'Elysian Chunky Teardrop Earrings',
    verified: true,
    date: '02 September 2026',
    approved: true
  },
  {
    id: 'rev-3',
    author: 'Zainab Fatima',
    location: 'Islamabad, F-7',
    rating: 5,
    title: 'Finally skin-friendly jewellery that doesn’t turn green',
    comment: 'I have severe nickel allergies and most artificial jewellery gives me rashes in hours. Girly Bling’s 316L surgical steel is 100% hypoallergenic. The Seraphina ring feels so substantial. 10/10 recommendation!',
    productName: 'Seraphina Twisted Croissant Ring',
    verified: true,
    date: '28 August 2026',
    approved: true
  },
  {
    id: 'rev-4',
    author: 'Hiba Bilal',
    location: 'Rawalpindi',
    rating: 5,
    title: 'Exceptional WhatsApp customer service',
    comment: 'The team was so helpful on WhatsApp with ring sizing measurements. The packaging arrived sealed and beautiful, perfect for gifting to my sister. Thank you Girly Bling!',
    productName: 'Celeste Dual Roman Cable Bangle',
    verified: true,
    date: '19 August 2026',
    approved: true
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'GB-9104',
    customer: {
      name: 'Dr. Fatima Zahra',
      email: 'dr.fatima@gmail.com',
      phone: '+92 300 9876543',
      address: 'House 14-B, Street 3, Sector F-8/2',
      city: 'Islamabad',
      postalCode: '44000',
      notes: 'Please deliver after 2 PM'
    },
    items: [
      {
        productId: 'gb-001',
        name: 'Aurelia Herringbone Snake Chain',
        price: 2850,
        quantity: 1,
        size: '40cm + 5cm Extender',
        image: '/src/assets/images/product_travertine_jewellery_1790183496193.jpg'
      },
      {
        productId: 'gb-004',
        name: 'Elysian Chunky Teardrop Earrings',
        price: 2250,
        quantity: 1,
        size: 'One Size',
        image: '/src/assets/images/hero_jewellery_editorial_1790183483191.jpg'
      }
    ],
    subtotal: 5100,
    shippingFee: 0,
    total: 5100,
    paymentMethod: 'cod',
    paymentStatus: 'pending',
    status: 'Processing',
    trackingNumber: 'TCS-984120938',
    createdAt: '2026-09-22T14:30:00Z'
  },
  {
    id: 'GB-9103',
    customer: {
      name: 'Sara Rehman',
      email: 'sara.rehman@yahoo.com',
      phone: '+92 333 4567890',
      address: 'Apartment 5B, Creek Vista, Phase 8 DHA',
      city: 'Karachi',
      postalCode: '75500',
      notes: 'Call on arrival at the gate'
    },
    items: [
      {
        productId: 'gb-003',
        name: 'Celeste Dual Roman Cable Bangle',
        price: 3450,
        quantity: 1,
        size: 'Small (16cm wrist)',
        image: '/src/assets/images/lookbook_lifestyle_portrait_1790183522124.jpg'
      }
    ],
    subtotal: 3450,
    shippingFee: 250,
    total: 3700,
    paymentMethod: 'bank_transfer',
    paymentStatus: 'paid',
    status: 'Shipped',
    trackingNumber: 'LEO-774019283',
    createdAt: '2026-09-21T09:15:00Z'
  },
  {
    id: 'GB-9102',
    customer: {
      name: 'Mariam Ali',
      email: 'mariam.ali@outlook.com',
      phone: '+92 321 7891234',
      address: '22-Commercial Area, Cavalry Ground',
      city: 'Lahore',
      postalCode: '54000'
    },
    items: [
      {
        productId: 'gb-002',
        name: 'Seraphina Twisted Croissant Ring',
        price: 1950,
        quantity: 2,
        size: 'US 7 (17.3mm)',
        image: '/src/assets/images/product_travertine_jewellery_1790183496193.jpg'
      }
    ],
    subtotal: 3900,
    shippingFee: 0,
    total: 3900,
    paymentMethod: 'cod',
    paymentStatus: 'paid',
    status: 'Delivered',
    trackingNumber: 'TCS-984001928',
    createdAt: '2026-09-18T11:00:00Z'
  }
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: 'cust-1',
    name: 'Dr. Fatima Zahra',
    email: 'dr.fatima@gmail.com',
    phone: '+92 300 9876543',
    city: 'Islamabad',
    totalOrders: 2,
    totalSpent: 8650,
    lastOrderDate: '2026-09-22'
  },
  {
    id: 'cust-2',
    name: 'Sara Rehman',
    email: 'sara.rehman@yahoo.com',
    phone: '+92 333 4567890',
    city: 'Karachi',
    totalOrders: 1,
    totalSpent: 3700,
    lastOrderDate: '2026-09-21'
  },
  {
    id: 'cust-3',
    name: 'Mariam Ali',
    email: 'mariam.ali@outlook.com',
    phone: '+92 321 7891234',
    city: 'Lahore',
    totalOrders: 3,
    totalSpent: 11450,
    lastOrderDate: '2026-09-18'
  }
];
