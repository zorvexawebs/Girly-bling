export interface SourceFile {
  name: string;
  path: string;
  category: 'Configuration' | 'Core' | 'Components' | 'Pages' | 'Docs';
  description: string;
  code: string;
}

export const SOURCE_FILES: SourceFile[] = [
  {
    name: 'README.md',
    path: 'README.md',
    category: 'Docs',
    description: 'Complete documentation, features overview, setup commands, and hosting instructions.',
    code: `# Girly Bling — Everyday Luxury Stainless Steel Jewellery

A modern, high-conversion e-commerce web application for Girly Bling, a luxury waterproof and anti-tarnish stainless-steel jewellery brand based in Pakistan.

## 🌟 Key Features
- Anti-tarnish, 100% waterproof everyday jewellery catalogue
- Real-time 3D tilt hero showcase with motion video reels and high-res photos
- Cash on Delivery (COD), Direct Bank Transfer, and JazzCash/EasyPaisa payments
- 1-Click WhatsApp Ordering (+92 321 8492001)
- Comprehensive Owner Portal with PIN authentication (Default: 1234)
- Live inventory, cart, wishlist, and Pakistani ring size guide

## 🚀 Quick Start
\`\`\`bash
npm install
npm run dev
\`\`\`
Visit http://localhost:3000

## 📦 Build for Production
\`\`\`bash
npm run build
\`\`\`
`
  },
  {
    name: 'package.json',
    path: 'package.json',
    category: 'Configuration',
    description: 'NPM package manifest with dependencies, scripts, and build targets.',
    code: `{
  "name": "girly-bling-store",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port=3000 --host=0.0.0.0",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "tsc --noEmit"
  },
  "dependencies": {
    "react": "^19.0.1",
    "react-dom": "^19.0.1",
    "lucide-react": "^0.546.0",
    "motion": "^12.23.24",
    "vite": "^8.3.0",
    "@tailwindcss/vite": "^4.3.3",
    "@vitejs/plugin-react": "^6.1.1"
  },
  "devDependencies": {
    "@types/node": "^22.14.0",
    "@types/react": "^19.3.0",
    "@types/react-dom": "^19.3.0",
    "tailwindcss": "^4.3.3",
    "typescript": "^7.0.2"
  }
}`
  },
  {
    name: 'vite.config.ts',
    path: 'vite.config.ts',
    category: 'Configuration',
    description: 'Vite bundler configuration with React and Tailwind CSS v4 plugins.',
    code: `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
  ],
  server: {
    port: 3000,
    host: '0.0.0.0',
  }
});`
  },
  {
    name: 'index.html',
    path: 'index.html',
    category: 'Configuration',
    description: 'HTML5 entry point with luxury Google Serif typography & responsive meta tags.',
    code: `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Girly Bling — Waterproof Everyday Luxury Jewellery in Pakistan</title>
    <meta name="description" content="Shop hypoallergenic, anti-tarnish, and 100% waterproof stainless steel jewellery crafted for daily wear in Pakistan. Cash on Delivery nationwide." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  </head>
  <body class="bg-[#FAF8F5] text-[#242424] antialiased selection:bg-[#A57E78]/20 selection:text-[#242424]">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>`
  },
  {
    name: 'src/App.tsx',
    path: 'src/App.tsx',
    category: 'Core',
    description: 'Root application router displaying views (Home, Shop, Detail, Checkout, About, Policies).',
    code: `import React, { useState } from 'react';
import { useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Hero3D } from './components/Hero3D';
import { CuratedCollection } from './components/CuratedCollection';
import { NewArrivals } from './components/NewArrivals';
import { BrandStory } from './components/BrandStory';
import { WhyGirlyBling } from './components/WhyGirlyBling';
import { BestSellers } from './components/BestSellers';
import { MaterialQualitySection } from './components/MaterialQualitySection';
import { LookbookInstagram } from './components/LookbookInstagram';
import { CustomerReviews } from './components/CustomerReviews';
import { TrustSection } from './components/TrustSection';
import { FAQSection } from './components/FAQSection';
import { NewsletterCTA } from './components/NewsletterCTA';
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { SearchModal } from './components/SearchModal';
import { SizeGuideModal } from './components/SizeGuideModal';
import { OwnerDashboardModal } from './components/OwnerDashboardModal';
import { ShopView } from './pages/ShopView';
import { ProductDetailView } from './pages/ProductDetailView';
import { CheckoutView } from './pages/CheckoutView';
import { AboutView } from './pages/AboutView';
import { LookbookView } from './pages/LookbookView';
import { ContactView } from './pages/ContactView';
import { PolicyView } from './pages/PolicyView';

export function App() {
  const { activePage } = useStore();
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col font-sans bg-[#FAF8F5] text-[#242424]">
      <Header onOpenSizeGuide={() => setIsSizeGuideOpen(true)} />

      <main className="flex-1">
        {activePage === 'home' && (
          <>
            <Hero3D />
            <CuratedCollection />
            <BestSellers />
            <WhyGirlyBling />
            <NewArrivals />
            <MaterialQualitySection />
            <BrandStory />
            <LookbookInstagram />
            <CustomerReviews />
            <TrustSection />
            <FAQSection />
            <NewsletterCTA />
          </>
        )}

        {activePage === 'shop' && <ShopView onOpenSizeGuide={() => setIsSizeGuideOpen(true)} />}
        {activePage === 'product' && <ProductDetailView onOpenSizeGuide={() => setIsSizeGuideOpen(true)} />}
        {activePage === 'checkout' && <CheckoutView />}
        {activePage === 'about' && <AboutView />}
        {activePage === 'lookbook' && <LookbookView />}
        {activePage === 'contact' && <ContactView />}
        {['shipping', 'returns', 'privacy', 'terms'].includes(activePage) && (
          <PolicyView policyType={activePage as any} />
        )}
      </main>

      <Footer onOpenSizeGuide={() => setIsSizeGuideOpen(true)} />

      <CartDrawer />
      <WishlistDrawer />
      <SearchModal />
      <SizeGuideModal isOpen={isSizeGuideOpen} onClose={() => setIsSizeGuideOpen(false)} />
      <OwnerDashboardModal />
    </div>
  );
}

export default App;`
  },
  {
    name: 'src/types.ts',
    path: 'src/types.ts',
    category: 'Core',
    description: 'TypeScript interfaces for Products, Orders, Customers, Reviews, and Store Settings.',
    code: `export type ProductCategory = 'All' | 'Rings' | 'Necklaces' | 'Earrings' | 'Bracelets' | 'Anklets';

export interface Product {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: 'Rings' | 'Necklaces' | 'Earrings' | 'Bracelets' | 'Anklets';
  collection: string;
  material: string;
  images: string[];
  stock: number;
  stockStatus: 'in_stock' | 'low_stock' | 'out_of_stock';
  sku: string;
  sizes: string[];
  tags: string[];
  isFeatured: boolean;
  isNewArrival: boolean;
  isBestSeller: boolean;
  rating: number;
  reviewCount: number;
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  size: string;
  quantity: number;
  image: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
  city: string;
  postalCode?: string;
  province?: string;
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  shippingFee: number;
  total: number;
  paymentMethod: 'COD' | 'Bank Transfer' | 'EasyPaisa' | 'JazzCash';
  paymentStatus: 'pending' | 'verified' | 'paid';
  orderStatus: 'pending' | 'confirmed' | 'dispatched' | 'delivered' | 'cancelled';
  createdAt: string;
  paymentProofUrl?: string;
}

export interface StoreSettings {
  businessName: string;
  tagline: string;
  phone: string;
  whatsappNumber: string;
  email: string;
  address: string;
  businessHours: string;
  heroImage: string;
  heroMediaType?: 'image' | 'video';
  heroVideoUrl?: string;
  heroVideoDescription?: string;
  heroMediaBadge?: string;
  heroMediaHeading?: string;
  freeShippingThreshold: number;
  standardShippingFee: number;
  announcementText: string;
  announcementActive: boolean;
  bankName: string;
  bankTitle: string;
  bankIban: string;
  easypaisaNumber: string;
  jazzcashNumber: string;
}`
  },
  {
    name: 'src/components/Hero3D.tsx',
    path: 'src/components/Hero3D.tsx',
    category: 'Components',
    description: 'Interactive cursor-tracking 3D showcase card supporting motion video loops & high-res photography.',
    code: `import React, { useRef, useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { ArrowRight, Sparkles, Shield, Droplets, Volume2, VolumeX, Film, Image as ImageIcon } from 'lucide-react';

export const Hero3D: React.FC = () => {
  const { settings, setActivePage } = useStore();
  const cardRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [mediaMode, setMediaMode] = useState<'image' | 'video'>(settings.heroMediaType || 'image');
  const [isMuted, setIsMuted] = useState(true);

  // Mouse tilt tracking & specular lighting effects
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    setRotateX(-((y - centerY) / centerY) * 12);
    setRotateY(((x - centerX) / centerX) * 12);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotateX(0);
    setRotateY(0);
  };

  return (
    <section className="relative overflow-hidden pt-12 pb-20 lg:pt-16 lg:pb-28 bg-[#FAF8F5]">
      {/* Editorial Grid and Interactive 3D Perspective Card Container */}
    </section>
  );
};`
  }
];
