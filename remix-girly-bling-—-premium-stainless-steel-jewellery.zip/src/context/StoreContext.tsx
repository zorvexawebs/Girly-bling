import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Order, Review, StoreSettings, Customer } from '../types';
import {
  INITIAL_SETTINGS,
  INITIAL_PRODUCTS,
  INITIAL_REVIEWS,
  INITIAL_ORDERS,
  INITIAL_CUSTOMERS
} from '../data/initialData';

interface StoreContextType {
  settings: StoreSettings;
  updateSettings: (newSettings: Partial<StoreSettings>) => void;
  resetSettings: () => void;
  
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => Product;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  duplicateProduct: (id: string) => Product | null;
  
  orders: Order[];
  addOrder: (orderData: Omit<Order, 'id' | 'createdAt'>) => Order;
  updateOrderStatus: (orderId: string, status: Order['status'], paymentStatus?: Order['paymentStatus'], trackingNumber?: string) => void;
  
  reviews: Review[];
  addReview: (review: Omit<Review, 'id' | 'date' | 'approved'>) => void;
  updateReview: (id: string, updates: Partial<Review>) => void;
  deleteReview: (id: string) => void;
  toggleReviewApproval: (id: string) => void;

  customers: Customer[];
  
  cart: CartItem[];
  addToCart: (product: Product, size: string, quantity?: number) => void;
  removeFromCart: (cartItemId: string) => void;
  updateCartQuantity: (cartItemId: string, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  
  wishlist: string[]; // product IDs
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;
  wishlistCount: number;
  isWishlistOpen: boolean;
  setIsWishlistOpen: (open: boolean) => void;

  // Active views / navigation
  activePage: 'home' | 'shop' | 'product' | 'about' | 'lookbook' | 'reviews' | 'contact' | 'size-guide' | 'shipping' | 'returns' | 'privacy' | 'terms' | 'cart' | 'checkout' | 'order-success';
  setActivePage: (page: StoreContextType['activePage']) => void;
  selectedProductId: string | null;
  openProductDetail: (productId: string) => void;
  lastPlacedOrder: Order | null;
  setLastPlacedOrder: (order: Order | null) => void;

  // Search overlay
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Owner dashboard modal / view
  isOwnerLoggedIn: boolean;
  setIsOwnerLoggedIn: (loggedIn: boolean) => void;
  isDashboardOpen: boolean;
  setIsDashboardOpen: (open: boolean) => void;

  // Toast notifications
  toastMessage: string | null;
  showToast: (msg: string) => void;

  // WhatsApp order generator
  generateWhatsAppOrderUrl: (product?: Product, size?: string, quantity?: number) => string;
  generateWhatsAppCartUrl: () => string;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // LocalStorage keys
  const SETTINGS_KEY = 'gb_store_settings_v1';
  const PRODUCTS_KEY = 'gb_products_v1';
  const ORDERS_KEY = 'gb_orders_v1';
  const REVIEWS_KEY = 'gb_reviews_v1';
  const CUSTOMERS_KEY = 'gb_customers_v1';
  const CART_KEY = 'gb_cart_v1';
  const WISHLIST_KEY = 'gb_wishlist_v1';

  // State initialization with localStorage fallback
  const [settings, setSettings] = useState<StoreSettings>(() => {
    try {
      const saved = localStorage.getItem(SETTINGS_KEY);
      if (!saved) return INITIAL_SETTINGS;
      const parsed = JSON.parse(saved);
      return {
        ...INITIAL_SETTINGS,
        ...parsed,
        primaryBgColor: '#FAF8F5',
        textColor: '#242424',
        accentRoseColor: '#C9A6A0',
        taupeColor: '#D8CEC8'
      };
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(PRODUCTS_KEY);
      if (!saved) return INITIAL_PRODUCTS;
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(ORDERS_KEY);
      if (!saved) return INITIAL_ORDERS;
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    try {
      const saved = localStorage.getItem(REVIEWS_KEY);
      if (!saved) return INITIAL_REVIEWS;
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : INITIAL_REVIEWS;
    } catch {
      return INITIAL_REVIEWS;
    }
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    try {
      const saved = localStorage.getItem(CUSTOMERS_KEY);
      if (!saved) return INITIAL_CUSTOMERS;
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : INITIAL_CUSTOMERS;
    } catch {
      return INITIAL_CUSTOMERS;
    }
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_KEY);
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed)
        ? parsed.filter((item) => item && item.product && typeof item.product.price === 'number')
        : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(WISHLIST_KEY);
      if (!saved) return ['gb-001', 'gb-004'];
      const parsed = JSON.parse(saved);
      return Array.isArray(parsed) ? parsed : ['gb-001', 'gb-004'];
    } catch {
      return ['gb-001', 'gb-004'];
    }
  });

  // UI state
  const [activePage, setActivePage] = useState<StoreContextType['activePage']>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isOwnerLoggedIn, setIsOwnerLoggedIn] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Safe localStorage helper to prevent QuotaExceededError or unhandled DOMException crashes
  const safeSetItem = (key: string, value: any) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.warn(`Could not save ${key} to localStorage:`, e);
      if (key === SETTINGS_KEY && value) {
        try {
          // If large base64 data URLs exceed quota, omit base64 fields so core store settings still persist
          const trimmed = { ...value };
          if (typeof trimmed.heroVideoUrl === 'string' && trimmed.heroVideoUrl.startsWith('data:')) {
            trimmed.heroVideoUrl = INITIAL_SETTINGS.heroVideoUrl;
          }
          if (typeof trimmed.heroImage === 'string' && trimmed.heroImage.startsWith('data:')) {
            trimmed.heroImage = INITIAL_SETTINGS.heroImage;
          }
          localStorage.setItem(key, JSON.stringify(trimmed));
        } catch {
          // Ignore
        }
      }
    }
  };

  // Sync state to localStorage safely
  useEffect(() => {
    safeSetItem(SETTINGS_KEY, settings);
    // Apply dynamic theme background and text colors to body if customized
    if (settings.primaryBgColor) {
      document.body.style.backgroundColor = settings.primaryBgColor;
    }
    if (settings.textColor) {
      document.body.style.color = settings.textColor;
    }
    const activeAccent = settings.accentRoseColor === '#A57E78' ? '#C9A6A0' : (settings.accentRoseColor || '#C9A6A0');
    document.documentElement.style.setProperty('--color-rose-muted', activeAccent);
    document.documentElement.style.setProperty('--color-rose-dark', activeAccent);
    if (settings.taupeColor) {
      document.documentElement.style.setProperty('--color-taupe', settings.taupeColor);
    }
  }, [settings]);

  useEffect(() => {
    safeSetItem(PRODUCTS_KEY, products);
  }, [products]);

  useEffect(() => {
    safeSetItem(ORDERS_KEY, orders);
  }, [orders]);

  useEffect(() => {
    safeSetItem(REVIEWS_KEY, reviews);
  }, [reviews]);

  useEffect(() => {
    safeSetItem(CUSTOMERS_KEY, customers);
  }, [customers]);

  useEffect(() => {
    safeSetItem(CART_KEY, cart);
  }, [cart]);

  useEffect(() => {
    safeSetItem(WISHLIST_KEY, wishlist);
  }, [wishlist]);

  // Toast handler
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // Settings methods
  const updateSettings = (newSettings: Partial<StoreSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
    showToast('Store settings updated successfully.');
  };

  const resetSettings = () => {
    setSettings(INITIAL_SETTINGS);
    showToast('Store settings restored to default.');
  };

  // Product methods
  const addProduct = (productData: Omit<Product, 'id'>) => {
    const newId = `gb-${Date.now().toString().slice(-5)}`;
    const newProduct: Product = {
      ...productData,
      id: newId
    };
    setProducts((prev) => [newProduct, ...prev]);
    showToast(`"${newProduct.name}" added to catalogue.`);
    return newProduct;
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
    showToast('Product updated successfully.');
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((item) => item.id !== id));
    showToast('Product deleted.');
  };

  const duplicateProduct = (id: string) => {
    const item = products.find((p) => p.id === id);
    if (!item) return null;
    const duplicated: Product = {
      ...item,
      id: `gb-${Date.now().toString().slice(-5)}`,
      name: `${item.name} (Copy)`,
      sku: `${item.sku}-COPY`
    };
    setProducts((prev) => [duplicated, ...prev]);
    showToast(`Duplicated "${item.name}".`);
    return duplicated;
  };

  // Order methods
  const addOrder = (orderData: Omit<Order, 'id' | 'createdAt'>) => {
    const newOrder: Order = {
      ...orderData,
      id: `GB-${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: new Date().toISOString()
    };
    setOrders((prev) => [newOrder, ...prev]);

    // Update customer registry
    setCustomers((prev) => {
      const existing = prev.find((c) => c.phone === orderData.customer.phone || c.email === orderData.customer.email);
      if (existing) {
        return prev.map((c) =>
          c.id === existing.id
            ? {
                ...c,
                totalOrders: c.totalOrders + 1,
                totalSpent: c.totalSpent + orderData.total,
                lastOrderDate: new Date().toISOString().split('T')[0]
              }
            : c
        );
      } else {
        return [
          {
            id: `cust-${Date.now()}`,
            name: orderData.customer.name,
            email: orderData.customer.email,
            phone: orderData.customer.phone,
            city: orderData.customer.city,
            totalOrders: 1,
            totalSpent: orderData.total,
            lastOrderDate: new Date().toISOString().split('T')[0]
          },
          ...prev
        ];
      }
    });

    // Deduct stock
    setProducts((prev) =>
      prev.map((prod) => {
        const orderedItem = orderData.items.find((i) => i.productId === prod.id);
        if (orderedItem) {
          const newStock = Math.max(0, prod.stock - orderedItem.quantity);
          const newStatus = newStock === 0 ? 'sold_out' : newStock <= 5 ? 'low_stock' : 'in_stock';
          return { ...prod, stock: newStock, stockStatus: newStatus };
        }
        return prod;
      })
    );

    return newOrder;
  };

  const updateOrderStatus = (
    orderId: string,
    status: Order['status'],
    paymentStatus?: Order['paymentStatus'],
    trackingNumber?: string
  ) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status,
              ...(paymentStatus ? { paymentStatus } : {}),
              ...(trackingNumber !== undefined ? { trackingNumber } : {})
            }
          : o
      )
    );
    showToast(`Order ${orderId} status changed to ${status}.`);
  };

  // Review methods
  const addReview = (reviewData: Omit<Review, 'id' | 'date' | 'approved'>) => {
    const newRev: Review = {
      ...reviewData,
      id: `rev-${Date.now()}`,
      date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
      approved: true
    };
    setReviews((prev) => [newRev, ...prev]);
    showToast('Thank you! Your review has been submitted.');
  };

  const updateReview = (id: string, updates: Partial<Review>) => {
    setReviews((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r)));
    showToast('Review updated.');
  };

  const deleteReview = (id: string) => {
    setReviews((prev) => prev.filter((r) => r.id !== id));
    showToast('Review removed.');
  };

  const toggleReviewApproval = (id: string) => {
    setReviews((prev) =>
      prev.map((r) => (r.id === id ? { ...r, approved: !r.approved } : r))
    );
  };

  // Cart methods
  const addToCart = (product: Product, size: string, quantity: number = 1) => {
    if (product.stockStatus === 'sold_out') {
      showToast('This item is currently sold out.');
      return;
    }
    const cartItemId = `${product.id}-${size}`;
    setCart((prev) => {
      const existing = prev.find((item) => item.id === cartItemId);
      if (existing) {
        return prev.map((item) =>
          item.id === cartItemId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        return [...prev, { id: cartItemId, productId: product.id, product, quantity, selectedSize: size }];
      }
    });
    showToast(`Added "${product.name}" (${size}) to your bag.`);
    setIsCartOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== cartItemId));
  };

  const updateCartQuantity = (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(cartItemId);
    } else {
      setCart((prev) =>
        prev.map((item) => (item.id === cartItemId ? { ...item, quantity } : item))
      );
    }
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartCount = cart.reduce((acc, item) => acc + (item?.quantity || 0), 0);
  const cartSubtotal = cart.reduce(
    (acc, item) => acc + (item?.product?.price || 0) * (item?.quantity || 1),
    0
  );

  // Wishlist methods
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Removed from wishlist.');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('Saved to wishlist.');
        return [...prev, productId];
      }
    });
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);
  const wishlistCount = wishlist.length;

  // Product detail view helper
  const openProductDetail = (productId: string) => {
    setSelectedProductId(productId);
    setActivePage('product');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // WhatsApp order generators
  const cleanPhone = (phoneStr?: string) => (phoneStr ? phoneStr.replace(/[^0-9]/g, '') : '923218492001');

  const generateWhatsAppOrderUrl = (product?: Product, size?: string, quantity: number = 1) => {
    const rawNumber = cleanPhone(settings.whatsappNumber || '+923218492001');
    if (product) {
      const message = encodeURIComponent(
        `Hi ${settings.businessName}, I would like to place an order for:\n\n• Product: ${product.name}\n• Price: Rs. ${product.price.toLocaleString()}\n• Size: ${size || product.sizes[0] || 'Standard'}\n• Quantity: ${quantity}\n\nPlease let me know availability and delivery details for Cash on Delivery.`
      );
      return `https://wa.me/${rawNumber}?text=${message}`;
    }
    const defaultMsg = encodeURIComponent(`Hi ${settings.businessName}, I would like to inquire about your jewellery collection.`);
    return `https://wa.me/${rawNumber}?text=${defaultMsg}`;
  };

  const generateWhatsAppCartUrl = () => {
    const rawNumber = cleanPhone(settings.whatsappNumber || '+923218492001');
    if (cart.length === 0) {
      return `https://wa.me/${rawNumber}?text=${encodeURIComponent(`Hi ${settings.businessName}, I would like to browse your jewellery collection.`)}`;
    }
    const itemsList = cart
      .map(
        (item, index) =>
          `${index + 1}. ${item.product.name} (${item.selectedSize}) x ${item.quantity} = Rs. ${(
            item.product.price * item.quantity
          ).toLocaleString()}`
      )
      .join('\n');

    const shipping = cartSubtotal >= settings.freeShippingThreshold ? 0 : settings.standardShippingFee;
    const grandTotal = cartSubtotal + shipping;

    const message = encodeURIComponent(
      `Hi ${settings.businessName}, I would like to order my shopping bag items:\n\n${itemsList}\n\n• Subtotal: Rs. ${cartSubtotal.toLocaleString()}\n• Shipping: ${
        shipping === 0 ? 'FREE' : `Rs. ${shipping}`
      }\n• Grand Total: Rs. ${grandTotal.toLocaleString()}\n\nPlease confirm my order with Cash on Delivery.`
    );
    return `https://wa.me/${rawNumber}?text=${message}`;
  };

  return (
    <StoreContext.Provider
      value={{
        settings,
        updateSettings,
        resetSettings,
        products,
        addProduct,
        updateProduct,
        deleteProduct,
        duplicateProduct,
        orders,
        addOrder,
        updateOrderStatus,
        reviews,
        addReview,
        updateReview,
        deleteReview,
        toggleReviewApproval,
        customers,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartCount,
        cartSubtotal,
        isCartOpen,
        setIsCartOpen,
        wishlist,
        toggleWishlist,
        isInWishlist,
        wishlistCount,
        isWishlistOpen,
        setIsWishlistOpen,
        activePage,
        setActivePage,
        selectedProductId,
        openProductDetail,
        lastPlacedOrder,
        setLastPlacedOrder,
        isSearchOpen,
        setIsSearchOpen,
        searchQuery,
        setSearchQuery,
        isOwnerLoggedIn,
        setIsOwnerLoggedIn,
        isDashboardOpen,
        setIsDashboardOpen,
        toastMessage,
        showToast,
        generateWhatsAppOrderUrl,
        generateWhatsAppCartUrl
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
