export interface Product {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  price: number; // in PKR
  originalPrice?: number;
  category: 'Necklaces' | 'Rings' | 'Bracelets & Bangles' | 'Earrings' | 'Anklets' | 'Gift Sets';
  collection: string;
  material: string;
  images: string[];
  videoUrl?: string;
  stock: number;
  stockStatus: 'in_stock' | 'low_stock' | 'sold_out';
  sku: string;
  sizes: string[];
  weight?: string;
  tags: string[];
  isFeatured: boolean;
  isNewArrival: boolean;
  isBestSeller: boolean;
  rating: number;
  reviewCount: number;
  careInstructions?: string;
}

export interface CartItem {
  id: string; // unique item entry id (productId + size)
  productId: string;
  product: Product;
  quantity: number;
  selectedSize: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate: string;
}

export interface Order {
  id: string;
  customer: {
    name: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    postalCode: string;
    notes?: string;
  };
  items: {
    productId: string;
    name: string;
    price: number;
    quantity: number;
    size: string;
    image: string;
  }[];
  subtotal: number;
  shippingFee: number;
  total: number;
  paymentMethod: 'cod' | 'bank_transfer' | 'easypaisa_jazzcash';
  paymentStatus: 'pending' | 'paid' | 'verification_required';
  status: 'Pending' | 'Confirmed' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  trackingNumber?: string;
  createdAt: string;
}

export interface Review {
  id: string;
  author: string;
  location?: string;
  rating: number;
  title: string;
  comment: string;
  productName?: string;
  verified: boolean;
  date: string;
  customerPhoto?: string;
  approved: boolean;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface StoreSettings {
  businessName: string;
  tagline: string;
  brandDescription: string;
  logoUrl?: string;
  whatsappNumber: string;
  phone: string;
  email: string;
  address: string;
  businessHours: string;
  instagramUsername: string;
  instagramUrl: string;
  facebookUrl: string;
  tiktokUrl: string;
  heroHeading: string;
  heroSubheading: string;
  heroBadge: string;
  heroImage: string;
  heroMediaType?: 'image' | 'video';
  heroVideoUrl?: string;
  heroVideoDescription?: string;
  heroMediaBadge?: string;
  heroMediaHeading?: string;
  freeShippingThreshold: number;
  standardShippingFee: number;
  announcementText: string;
  announcementActive: boolean;
  bankName: string;
  bankTitle: string;
  bankIban: string;
  easypaisaNumber: string;
  jazzcashNumber: string;
  primaryBgColor: string;
  textColor: string;
  accentRoseColor: string;
  taupeColor: string;
  champagneGoldColor: string;
  shippingPolicy: string;
  returnPolicy: string;
  privacyPolicy: string;
  termsPolicy: string;
  faqs: FAQItem[];
}
