import React, { useState } from 'react';
import { useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { Hero3D } from './components/Hero3D';
import { CuratedCollection } from './components/CuratedCollection';
import { BrandStory } from './components/BrandStory';
import { WhyGirlyBling } from './components/WhyGirlyBling';
import { BestSellers } from './components/BestSellers';
import { MaterialQualitySection } from './components/MaterialQualitySection';
import { LookbookInstagram } from './components/LookbookInstagram';
import { CustomerReviews } from './components/CustomerReviews';
import { TrustSection } from './components/TrustSection';
import { FAQSection } from './components/FAQSection';
import { NewsletterCTA } from './components/NewsletterCTA';
import { Footer } from './components/Footer';

// Drawers & Modals
import { CartDrawer } from './components/CartDrawer';
import { WishlistDrawer } from './components/WishlistDrawer';
import { SearchModal } from './components/SearchModal';
import { ProductQuickViewModal } from './components/ProductQuickViewModal';
import { SizeGuideModal } from './components/SizeGuideModal';
import { OwnerDashboardModal } from './components/OwnerDashboardModal';

// Dedicated Full Views
import { ShopView } from './pages/ShopView';
import { ProductDetailView } from './pages/ProductDetailView';
import { CheckoutView } from './pages/CheckoutView';
import { AboutView } from './pages/AboutView';
import { LookbookView } from './pages/LookbookView';
import { ContactView } from './pages/ContactView';
import { PolicyView } from './pages/PolicyView';

// Icons & Types
import { MessageSquare } from 'lucide-react';
import { Product } from './types';

export default function App() {
  const { activePage, toastMessage, settings } = useStore();
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);

  const handleOpenQuickView = (product: Product) => {
    setQuickViewProduct(product);
  };

  const handleCloseQuickView = () => {
    setQuickViewProduct(null);
  };

  const handleOpenSizeGuide = () => {
    setIsSizeGuideOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#242424] antialiased selection:bg-[#C9A6A0]/30 selection:text-[#242424]">
      {/* Universal Luxury Header */}
      <Header />

      {/* Dynamic Main Viewport Container */}
      <main className="flex-1">
        {activePage === 'home' && (
          <>
            <Hero3D />
            <CuratedCollection onQuickView={handleOpenQuickView} />
            <BrandStory />
            <WhyGirlyBling />
            <BestSellers onQuickView={handleOpenQuickView} />
            <MaterialQualitySection />
            <LookbookInstagram />
            <CustomerReviews />
            <TrustSection />
            <FAQSection />
            <NewsletterCTA />
          </>
        )}

        {activePage === 'shop' && (
          <ShopView onQuickView={handleOpenQuickView} />
        )}

        {activePage === 'product' && (
          <ProductDetailView onOpenSizeGuide={handleOpenSizeGuide} />
        )}

        {activePage === 'checkout' && (
          <CheckoutView />
        )}

        {activePage === 'about' && (
          <AboutView />
        )}

        {activePage === 'lookbook' && (
          <LookbookView />
        )}

        {activePage === 'contact' && (
          <ContactView />
        )}

        {(activePage === 'shipping' ||
          activePage === 'returns' ||
          activePage === 'privacy' ||
          activePage === 'terms' ||
          activePage === 'reviews') && (
          <PolicyView type={activePage} />
        )}
      </main>

      {/* Multi-Column Luxury Footer */}
      <Footer onOpenSizeGuide={handleOpenSizeGuide} />

      {/* Floating Concierge WhatsApp Action */}
      <a
        href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}?text=Hi%20${encodeURIComponent(
          settings.businessName
        )}%2C%20I%20have%20an%20enquiry%20regarding%20your%20jewellery.`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="fixed bottom-6 right-6 z-40 bg-[#25D366] text-white p-3.5 rounded-full shadow-xl hover:scale-105 active:scale-95 transition-all duration-300 flex items-center justify-center group"
      >
        <MessageSquare className="w-5 h-5 fill-current" />
        <span className="max-w-0 overflow-hidden whitespace-nowrap group-hover:max-w-xs transition-all duration-300 ease-in-out text-xs font-semibold px-0 group-hover:pl-2">
          Chat on WhatsApp
        </span>
      </a>

      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-6 left-6 z-50 bg-[#242424] text-white px-4 py-3 text-xs uppercase tracking-wider font-semibold shadow-2xl border border-[#383838] animate-in fade-in slide-in-from-bottom-2 duration-200">
          {toastMessage}
        </div>
      )}

      {/* Slide-over Drawers & Modals */}
      <CartDrawer />
      <WishlistDrawer />
      <SearchModal />
      <ProductQuickViewModal
        product={quickViewProduct}
        onClose={handleCloseQuickView}
      />
      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
      />
      <OwnerDashboardModal />
    </div>
  );
}
